# Contrôles Nova v0.9.5

## Vérifications statiques

- Ressources XML analysées.
- IDs ViewBinding de l’accueil et de Nova Support vérifiés.
- Version passée à 0.9.5 (versionCode 22).
- Protocole Nova Support aligné avec Nova Support 0.4.0.
- Rafale : captures en faible latence, sauvegarde chiffrée découplée de la cadence.

## Essais indispensables sur téléphone

1. Tester une rafale de 5 photos à 250, 500 et 1000 ms.
2. Comparer la cadence en mode résolution automatique et maximale.
3. Vérifier le QR d’installation Nova Support.
4. Appairer Nova 0.9.5 avec Nova Support 0.4.0.
5. Démarrer une vidéo support, verrouiller le téléphone-support, puis arrêter depuis Nova.
6. Vérifier le transfert du dernier segment inférieur à la durée de découpage.
7. Tester vidéo avec et sans autorisation microphone.
