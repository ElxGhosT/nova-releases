# Contrôles effectués — Nova 0.9.1 / Nova Support 0.2.0

## Contrôles statiques

- Tous les fichiers XML des deux projets sont syntaxiquement valides.
- Les nouveaux identifiants ViewBinding des écrans Caméra support et Nova Support sont présents.
- `versionCode 18` / `versionName 0.9.1` vérifiés pour Nova.
- `versionCode 2` / `versionName 0.2.0` vérifiés pour Nova Support.
- Le package Nova reste `fr.doudou.nova`.
- Le package secondaire est `fr.doudou.novasupport`.
- `usesCleartextTraffic=false` est activé dans les deux manifestes.
- Aucun client ou serveur HTTP ne subsiste dans le module de caméra support.
- Le serveur est lié à l’adresse IPv4 Wi-Fi privée et filtre le sous-réseau.
- Le secret est stocké via Android Keystore des deux côtés.

## Tests exécutés hors Android

- Interopérabilité HMAC-SHA-256 entre Nova et Nova Support : OK.
- Interopérabilité AES-256-GCM avec nonce utilisé comme AAD : OK.
- Requête complète sur le protocole binaire TCP et déchiffrement d’une trame : OK.
- Refus d’un mauvais secret d’appairage : OK.

## Contrôles restant à faire sur appareils

- Compilation Gradle Android complète.
- Test CameraX du dernier segment vidéo partiel.
- Scan QR avec la caméra du téléphone principal.
- Maintien du flux écran éteint selon le constructeur du téléphone.
- Partage et installation de l’APK signé via Partage à proximité/Bluetooth.
