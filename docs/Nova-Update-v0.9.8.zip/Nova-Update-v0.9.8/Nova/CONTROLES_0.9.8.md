# Contrôles Nova v0.9.8

## Vérifications statiques

- Ressources XML analysées sans erreur.
- IDs ViewBinding du lecteur, de l’accueil, des réglages, de l’écran discret et de Nova Support contrôlés.
- Protocole local synchronisé en version 3 dans les deux projets.
- Photos distantes transférées par blocs de 1 Mio puis chiffrées dans le coffre.
- Commandes caméra, arrêt distant, relance réseau et mouvement présentes des deux côtés.
- Détection de mouvement sans tampon ni pré-enregistrement.

## Essais recommandés

1. Photo distante arrière puis avant, ouverture plein écran depuis le coffre.
2. Plusieurs déplacements successifs après zoom photo et vidéo.
3. Retardateurs 3 s à 1 min en photo et vidéo, avec et sans service armé.
4. Rafale à 250/500/1000 ms sur chaque téléphone compatible.
5. Flash photo, torche vidéo et mode nuit expérimental arrière.
6. Changement de caméra distante répété sans rescanner le QR.
7. Démarrer une vidéo distante, quitter le réseau, revenir, vérifier l’état puis arrêter.
8. Détection de mouvement avec plusieurs sensibilités et transfert du segment produit.
9. Arrêt complet des services à distance et via le widget Nova Support.
