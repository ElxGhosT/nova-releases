# Contrôles effectués — Nova 0.8.3

## Contrôles réussis dans l’archive

- Tous les fichiers XML du manifeste et des ressources sont bien formés.
- Toutes les nouvelles ressources locales référencées existent.
- Tous les identifiants requis par `ActivityDiscreetBinding` sont présents.
- La syntaxe Kotlin modifiée ne présente pas d’erreur de parsing détectable.
- `versionCode` est passé à `16` et `versionName` à `0.8.3`.
- Le package Android reste `fr.doudou.nova`, ce qui permet une mise à jour sans désinstallation.
- Le diff avec la v0.8.2.4 est limité aux fichiers documentés dans `CHANGELOG.md`.

## Validation restant à effectuer sur Android

L’environnement de génération utilisé ici ne contient pas le SDK Android 36. La compilation Gradle complète, l’installation et les tests CameraX réels doivent donc être effectués dans Android Studio avec `VALIDATION.md`.
