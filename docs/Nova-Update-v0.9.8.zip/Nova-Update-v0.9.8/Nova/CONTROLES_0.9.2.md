# Contrôles Nova v0.9.2

## Vérifications réalisées

- Réécriture de `MediaViewerActivity` pour la navigation séquentielle dans le dossier courant.
- Ajout du composant `ZoomableFrameLayout` pour le zoom/pan photo et vidéo.
- Mise à jour du modèle `MediaItem` avec l'état `protectedFromDeletion`.
- Adaptation du coffre pour refuser la suppression des médias protégés.
- Mise à jour de la vue `activity_media_viewer.xml` et des IDs ViewBinding associés.
- Version Android passée à `0.9.2` (`versionCode 19`).

## Essais recommandés sur appareil

1. Ouvrir plusieurs photos/vidéos d'un même dossier puis glisser gauche/droite.
2. Tester le zoom pincé et le déplacement dans une photo puis dans une vidéo.
3. Vérifier le mode immersif par appui simple.
4. Tester le double appui photo (zoom) et vidéo (seek ±5 s / zoom centre).
5. Capturer une image depuis une vidéo puis vérifier sa présence dans le coffre.
6. Protéger un média, tenter sa suppression, puis le déverrouiller et recommencer.
7. Vérifier la reprise d'une vidéo à la dernière position lue.
8. Tester les vitesses `0,5×`, `1×`, `1,5×`, `2×`.
9. Vérifier l'affichage `Ajuster / Remplir` sur photo et vidéo.
