# Architecture Nova Support

## Installation initiale

Le QR code sert à l’appairage, pas au transport de l’APK. L’APK est partagé localement par la feuille de partage Android. Cette décision évite d’exposer un serveur HTTP, même temporaire.

## Appairage

Format QR :

`nova-support://pair?v=1&host=<IPv4 privée>&port=8787&secret=<20 caractères>`

Le QR doit être traité comme un secret : il n’est affiché que sur l’écran du téléphone-support et l’activité interdit les captures d’écran côté Nova.

## Transport

- TCP local port 8787 ;
- en-tête magique `NOVA` ;
- version 1 ;
- nonce client de 16 octets ;
- authentification HMAC-SHA-256 ;
- réponse AES-256-GCM liée au nonce par AAD ;
- taille maximale 3 Mio ;
- timeouts courts ;
- aucune commande distante de démarrage de caméra.

## Périmètre de sécurité

La caméra doit être démarrée visiblement sur Nova Support. La notification de service et l’indicateur système restent actifs. Le protocole ne doit pas être exposé par redirection de port, VPN public ou proxy inverse.
