# Validation Nova 0.9.3

## Installation et migration

- [ ] Compilation Android Studio terminée sans erreur.
- [ ] Mise à jour installée par-dessus la v0.9.2 sans désinstaller Nova.
- [ ] Le PIN, les réglages et les médias du coffre sont conservés.
- [ ] Android affiche la version `0.9.3`.


## Lecteur média 0.9.3

- [ ] La bande de miniatures affiche les médias du dossier courant.
- [ ] Toucher une miniature ouvre le bon média et met à jour le compteur.
- [ ] Swipe gauche/droite et boutons précédent/suivant mettent à jour la miniature sélectionnée.
- [ ] Rotation 90°, 180°, 270° et retour à 0° fonctionnent pour les photos et vidéos.
- [ ] Le zoom et le déplacement restent utilisables après rotation du média.
- [ ] L’orientation physique du téléphone change lorsque le verrouillage est désactivé.
- [ ] L’orientation actuelle reste fixe lorsque le verrouillage est activé.
- [ ] Les états du lecteur sont conservés après recréation de l’écran.

## Capture Nova Support vers le coffre

- [ ] Le bouton **Photo support** enregistre une image dans le dossier Images du coffre.
- [ ] La photo est identifiée comme provenant de Nova Support.
- [ ] La rafale support respecte le nombre et l’intervalle configurés dans Nova.
- [ ] Les photos d’une même rafale utilisent le même groupe.
- [ ] Le bouton **Ouvrir le coffre Nova** ouvre le coffre sans perdre l’appairage enregistré.
- [ ] Aucune page Web ni URL publique n’est créée pour ces nouvelles fonctions.

## Correctif du découpage vidéo

- [ ] Durée totale 12 min, découpage 5 min : segments proches de 5 min, 5 min et 2 min présents.
- [ ] Arrêt manuel à 2 min avec découpage 5 min : le segment de 2 min est présent.
- [ ] Arrêt manuel quelques secondes après le début : le MP4 lisible est conservé.
- [ ] Durée totale exactement 10 min, découpage 5 min : aucun troisième micro-segment n’est créé.
- [ ] Le dernier segment est lisible dans le coffre après chiffrement.
- [ ] Le mode Double conserve les deux derniers segments lorsqu’ils sont valides.
- [ ] Un fichier réellement corrompu ou sans piste vidéo est rejeté proprement.

## Nova Support et QR

- [ ] Nova Support 0.2.0 est installée avec le package `fr.doudou.novasupport`.
- [ ] Les deux téléphones sont connectés au même Wi-Fi privé.
- [ ] Nova Support affiche une adresse IPv4 locale, un secret de 20 caractères et un QR code.
- [ ] Le scanner Nova remplit automatiquement l’adresse et le secret.
- [ ] La connexion démarre après le scan du bon QR code.
- [ ] Un QR modifié ou un ancien secret est refusé.
- [ ] Régénérer le secret invalide l’ancien appairage.
- [ ] La caméra avant et la caméra arrière fonctionnent séparément.
- [ ] La notification et l’indicateur caméra Android restent visibles.

## Sécurité réseau

- [ ] Ouvrir `http://adresse:8787` dans un navigateur ne retourne aucune page.
- [ ] Le port répond uniquement au protocole binaire Nova.
- [ ] Un appareil hors du sous-réseau Wi-Fi est refusé.
- [ ] Nova Support ne démarre pas la liaison sur une adresse publique ou mobile.
- [ ] La coupure du Wi-Fi produit une erreur sans plantage.
- [ ] Aucun port n’est ouvert sur le routeur et aucune redirection UPnP n’est créée.
- [ ] Le secret n’apparaît pas en clair dans les préférences Android après migration.

## Partage local de l’APK

- [ ] L’APK signé est copié avec `INTEGRER_NOVA_SUPPORT.cmd`.
- [ ] Le bouton **Partager l’APK Nova Support** ouvre la feuille de partage Android.
- [ ] Le transfert fonctionne avec Partage à proximité ou Bluetooth.
- [ ] Android demande une confirmation visible avant l’installation.
- [ ] Sans APK intégré, Nova affiche une explication au lieu de planter.

## Régressions

- [ ] Rafale, widget, tuile rapide et Volume − restent fonctionnels.
- [ ] Le zoom 0,6× reste sélectionné après armement.
- [ ] Le double aperçu ne présente pas d’écran noir persistant.
- [ ] Le coffre, l’import et le lecteur vidéo restent fonctionnels.
