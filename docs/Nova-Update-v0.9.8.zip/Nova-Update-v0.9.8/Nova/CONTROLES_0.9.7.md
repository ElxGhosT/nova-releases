# Contrôles Nova v0.9.7

- Version passée à `0.9.7` (`versionCode 24`).
- Lecture des QR d’appairage v1, v2 et v3.
- Connexion WifiNetworkSpecifier adaptée aux réseaux WPA2 et WPA3.
- Ajout du bouton de nouvelle tentative sur l’écran Nova Support.
- Vérification syntaxique du layout et des identifiants ViewBinding.
