# Nova 0.9.3 — projet Android Studio

Nova est une application Android de capture privée destinée à un usage légitime sur tes propres appareils et dans le respect du droit à l’image. Android conserve ses protections : la notification de service et l’indicateur d’utilisation de la caméra restent visibles lorsque la caméra est active.


## Lecteur média 0.9.3

Le lecteur plein écran ajoute une bande de miniatures, la sélection directe d’un média, la rotation temporaire par pas de 90° et le verrouillage de l’orientation actuelle. Les fonctions de la v0.9.2 restent disponibles : swipe, zoom photo/vidéo, capture d’image depuis une vidéo, mode immersif, vitesse de lecture, reprise de position et protection contre la suppression.

## Intégration du coffre avec Nova Support

Depuis l’écran **Caméra support**, Nova peut désormais enregistrer l’image distante directement dans le coffre chiffré. Une rafale distante réutilise le nombre de photos et l’intervalle définis dans les réglages Nova. Les médias sont identifiés comme provenant de **Nova Support** et restent privés tant qu’ils ne sont pas rendus visibles manuellement.

## Correctif vidéo 0.9.1

Le dernier segment d’un enregistrement est désormais conservé même lorsqu’il est plus court que la durée de découpage choisie.

L’ancienne logique rejetait automatiquement un MP4 lorsque CameraX terminait avec certains codes d’erreur, alors que le fichier partiel pouvait être lisible. Nova vérifie maintenant le conteneur réel avec `MediaMetadataRetriever` :

- fichier présent et non vide ;
- piste vidéo lisible ;
- durée réelle supérieure à 300 ms.

Si ces contrôles passent, le segment est chiffré et ajouté au coffre, y compris après un arrêt manuel ou à la fin d’une durée totale non multiple de 5 minutes.

## Nova Support 0.2.0

L’application secondaire s’appelle maintenant **Nova Support** et utilise le package séparé `fr.doudou.novasupport`.

### Appairage par QR code

1. Installer et ouvrir Nova Support sur le téléphone-support.
2. Connecter les deux téléphones au même Wi-Fi privé.
3. Démarrer la caméra dans Nova Support.
4. Dans Nova, ouvrir **Caméra support** puis toucher **Scanner le QR code**.
5. Scanner le QR affiché par Nova Support.

Le QR contient uniquement l’adresse Wi-Fi locale, le port, la version du protocole et un secret aléatoire de 20 caractères. Ce secret est protégé sur chaque téléphone par une clé non exportable de l’Android Keystore.

### Liaison sans serveur Web

La v0.9.1 n’utilise plus HTTP pour la caméra support :

- protocole binaire Nova sur socket TCP ;
- socket lié uniquement à l’adresse IPv4 du Wi-Fi privé ;
- refus des clients hors du sous-réseau local ;
- authentification HMAC-SHA-256 avec nonce aléatoire ;
- chiffrement AES-256-GCM de chaque image ;
- aucun chemin Web, aucune page accessible dans un navigateur ;
- `usesCleartextTraffic=false` dans les deux applications ;
- aucun cloud, aucune redirection de port et aucune écoute sur les données mobiles.

## Installation de Nova Support depuis le téléphone principal

Un QR code seul ne peut pas contenir un APK complet. Une installation par QR nécessiterait un lien de téléchargement, donc un serveur HTTP temporaire, ce qui a volontairement été exclu.

La solution retenue est le partage local Android :

1. compiler et signer `Nova-Support.apk` ;
2. lancer `INTEGRER_NOVA_SUPPORT.cmd chemin\\vers\\Nova-Support.apk` dans le projet Nova ;
3. reconstruire Nova ;
4. dans **Caméra support**, toucher **Partager l’APK Nova Support** ;
5. utiliser Partage à proximité, Bluetooth ou un autre moyen local proposé par Android.

Android demandera toujours une confirmation visible sur le téléphone-support et, selon le moyen utilisé, l’autorisation d’installer des applications inconnues. Une installation silencieuse n’est pas utilisée.

## Rafale 0.9

Le mode Rafale configurable reste disponible avec 2 à 20 déclenchements et un intervalle de 250 ms, 500 ms ou 1 seconde. Il s’applique au bouton principal, au widget, à la tuile rapide et à Volume −.

## Mise à jour sans perdre les médias

Le package principal reste `fr.doudou.nova`. La version passe à `0.9.3` avec le `versionCode 20`.

1. Ne désinstalle pas Nova et n’efface pas ses données.
2. Décompresse l’archive dans un nouveau dossier.
3. Exécute `PREPARER_PROJET.cmd` si nécessaire.
4. Ouvre `Nova` dans Android Studio.
5. Installe la mise à jour par-dessus la version existante.

Nova Support ayant un nouveau package, l’ancien prototype **Nova Camera** peut coexister. Après validation de Nova Support, l’ancien prototype peut être désinstallé manuellement.

## État de validation

Les XML, les références ViewBinding, le protocole cryptographique commun, les noms de package et les contrôles réseau ont été vérifiés statiquement. La compilation Android complète et les essais CameraX doivent encore être effectués sur les téléphones réels avec `VALIDATION.md`.

## Appairage Nova Support v3 (v0.9.7)

Pour un Réseau direct Nova, rejoins d’abord le Wi-Fi avec le QR standard affiché par Nova Support. Scanne ensuite le QR d’appairage dans l’écran Nova Support de Nova. Les anciens QR combinés restent compatibles et disposent d’un bouton **Réessayer la connexion directe**.

## Nova v0.9.8 — contrôle distant stabilisé

- Les photos Nova Support sont capturées en haute résolution et transférées dans le coffre.
- Les modes Normal, Retardé et Rafale sont sélectionnables sous le bouton principal.
- Le retardateur est disponible en 3 s, 5 s, 10 s, 30 s et 1 min.
- Le flash photo, la torche vidéo et un mode nuit expérimental arrière sont accessibles dans les réglages.
- L’écran Nova Support permet de choisir la caméra, relancer la liaison, arrêter les services et configurer la détection de mouvement.
- Une vidéo distante continue localement sans Nova et ses segments sont récupérés lors de la reconnexion.
- La détection de mouvement ne possède aucun pré-enregistrement dans cette version.
