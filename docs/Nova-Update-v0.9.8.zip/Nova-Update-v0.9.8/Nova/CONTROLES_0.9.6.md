# Contrôles Nova v0.9.6

## Modifications

- Ajout de la connexion au **Réseau direct Nova** créé par Nova Support.
- Lecture du QR d’appairage v2 avec SSID, mot de passe, adresse locale et secret.
- Demande de connexion Wi-Fi par l’interface officielle Android, sans ouverture Web.
- Liaison du processus Nova au réseau direct pendant la session distante.
- Déconnexion propre du réseau direct depuis le bouton Déconnecter.
- Ajout des autorisations Wi-Fi de proximité compatibles Android 13+.
- Correction du verrouillage : Nova redirige immédiatement vers l’écran PIN/biométrie au retour si la session a expiré.

## Tests recommandés

1. Créer un Réseau direct Nova sur Nova Support.
2. Scanner le QR depuis Nova et accepter la fenêtre Android de connexion Wi-Fi.
3. Vérifier l’aperçu, la photo, la rafale et la vidéo distante.
4. Changer d’application au-delà du délai de verrouillage, puis revenir dans Nova sans toucher l’écran.
5. Vérifier que l’écran de déverrouillage apparaît immédiatement.
