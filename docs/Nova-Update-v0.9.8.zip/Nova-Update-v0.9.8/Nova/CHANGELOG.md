# Nova v0.9.8

- Photos Nova Support désormais prises en haute résolution puis transférées par blocs chiffrés dans le coffre.
- Correction du lecteur zoomable : la position reste stable entre plusieurs gestes de déplacement.
- Sélecteur principal **Normal / Retardé / Rafale** et retardateurs 3 s, 5 s, 10 s, 30 s et 1 min.
- L’écran discret n’est accessible que lorsque les raccourcis externes sont actifs.
- Dans l’écran discret, **Maison** déclenche l’action sélectionnée et **Documents** affiche brièvement le mode actif.
- Flash photo Désactivé/Auto/Activé, torche vidéo et mode nuit expérimental sur la caméra arrière.
- Sélection distante caméra avant/arrière sans interrompre le serveur réseau.
- Reconnexion automatique renforcée après un changement de caméra ou un refus temporaire du port.
- Commandes distantes pour relancer la liaison ou arrêter tous les services Nova Support.
- Une vidéo distante continue localement si Nova quitte le réseau ; son état et ses segments sont récupérés à la reconnexion.
- Détection de mouvement simple, sans pré-enregistrement, avec sensibilité et durée réglables.
- Affichage de la batterie, du stockage libre, du flash et de la caméra active du téléphone-support.

## Historique v0.9.7

- Compatibilité avec le QR d’appairage Nova Support v3.
- Le QR d’appairage ne transporte plus le mot de passe Wi-Fi.
- Prise en charge des réseaux directs WPA3 en plus de WPA2.
- Ajout du bouton **Réessayer la connexion directe** pour les anciens QR combinés.
- Messages de diagnostic plus clairs lors d’un refus ou d’une expiration de connexion.

## Historique v0.9.6

- Connexion automatique au Réseau direct Nova par QR code.
- Compatibilité Android 13+ pour les autorisations Wi-Fi de proximité.
- Liaison réseau locale dédiée, sans cloud ni page Web.
- Correction du verrouillage au retour dans l’application après expiration de session.

## Historique v0.9.5

- Interface sombre modernisée avec liserés verts.
- Rafale optimisée pour réduire les délais inutiles.
- Commandes photo, rafale et vidéo de Nova Support.
