@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo Preparation du projet Nova...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap-gradle-wrapper.ps1"
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" (
    echo La preparation a echoue. Fais une capture de cette fenetre et envoie-la moi.
) else (
    echo La preparation est terminee.
)
echo Appuie sur une touche pour fermer cette fenetre...
pause >nul
exit /b %RESULT%
