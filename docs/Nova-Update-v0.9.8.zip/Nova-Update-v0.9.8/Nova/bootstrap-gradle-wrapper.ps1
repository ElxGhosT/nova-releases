$ErrorActionPreference = "Stop"

# Evite les textes corrompus dans l'ancienne console Windows.
try {
    [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
    $OutputEncoding = [Console]::OutputEncoding
} catch {
    # La preparation peut continuer meme si la console refuse l'UTF-8.
}

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Version = "9.4.1"
$MinimumJavaMajor = 17
$DistributionUrl = "https://services.gradle.org/distributions/gradle-$Version-bin.zip"
$ExpectedSha256 = "2ab2958f2a1e51120c326cad6f385153bb11ee93b3c216c5fccebfdfbb7ec6cb"
$TempRoot = Join-Path $ProjectRoot ".gradle-bootstrap"
$ZipPath = Join-Path $TempRoot "gradle-$Version-bin.zip"
$ExtractRoot = Join-Path $TempRoot "extracted"
$GradleBat = Join-Path $ExtractRoot "gradle-$Version\bin\gradle.bat"

function Get-JavaMajorVersion([string]$JavaHome) {
    if ([string]::IsNullOrWhiteSpace($JavaHome)) {
        return $null
    }

    $JavaExe = Join-Path $JavaHome "bin\java.exe"
    if (-not (Test-Path $JavaExe -PathType Leaf)) {
        return $null
    }

    try {
        # java -version ecrit volontairement sa version sur stderr. Avec
        # Windows PowerShell 5.1 et ErrorActionPreference=Stop, l'operateur
        # 2>&1 peut transformer cette sortie normale en erreur PowerShell.
        # ProcessStartInfo capture donc stdout/stderr sans faux echec.
        $StartInfo = New-Object System.Diagnostics.ProcessStartInfo
        $StartInfo.FileName = $JavaExe
        $StartInfo.Arguments = "-version"
        $StartInfo.UseShellExecute = $false
        $StartInfo.CreateNoWindow = $true
        $StartInfo.RedirectStandardOutput = $true
        $StartInfo.RedirectStandardError = $true

        $Process = New-Object System.Diagnostics.Process
        $Process.StartInfo = $StartInfo
        [void]$Process.Start()
        $StandardOutput = $Process.StandardOutput.ReadToEnd()
        $StandardError = $Process.StandardError.ReadToEnd()
        $Process.WaitForExit()

        $VersionText = "$StandardOutput`n$StandardError"
        $Match = [regex]::Match($VersionText, '(?:openjdk|java)\s+version\s+"([^"]+)"', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
        if (-not $Match.Success) {
            # Repli pour d'autres distributions Java.
            $Match = [regex]::Match($VersionText, 'version\s+"([^"]+)"', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
        }
        if (-not $Match.Success) {
            return $null
        }

        $VersionString = $Match.Groups[1].Value
        if ($VersionString.StartsWith("1.")) {
            return [int]($VersionString.Split('.')[1])
        }

        $MajorMatch = [regex]::Match($VersionString, '^\d+')
        if (-not $MajorMatch.Success) {
            return $null
        }

        return [int]$MajorMatch.Value
    }
    catch {
        return $null
    }
}
function Add-JavaCandidate([System.Collections.Generic.List[string]]$List, [string]$Path) {
    if (-not [string]::IsNullOrWhiteSpace($Path)) {
        $List.Add($Path)
    }
}

function Add-AndroidStudioJavaCandidates([System.Collections.Generic.List[string]]$Candidates) {
    # 1) Android Studio actuellement ouvert : c'est le moyen le plus fiable si
    # l'utilisateur l'a installe dans un dossier ou un disque personnalise.
    try {
        Get-Process -Name "studio64" -ErrorAction SilentlyContinue | ForEach-Object {
            $StudioExe = $_.Path
            if ($StudioExe) {
                $StudioBin = Split-Path $StudioExe -Parent
                $StudioHome = Split-Path $StudioBin -Parent
                Add-JavaCandidate $Candidates (Join-Path $StudioHome "jbr")
            }
        }
    } catch {
        # Continue avec les autres methodes.
    }

    # 2) Entrees d'installation Windows.
    $UninstallRoots = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*"
    )

    foreach ($RegistryRoot in $UninstallRoots) {
        try {
            Get-ItemProperty -Path $RegistryRoot -ErrorAction SilentlyContinue |
                Where-Object { $_.DisplayName -like "*Android Studio*" } |
                ForEach-Object {
                    if ($_.InstallLocation) {
                        Add-JavaCandidate $Candidates (Join-Path $_.InstallLocation "jbr")
                    }

                    if ($_.DisplayIcon) {
                        $IconPath = ([string]$_.DisplayIcon).Trim('"') -replace ',\d+$', ''
                        if (Test-Path $IconPath) {
                            $Bin = Split-Path $IconPath -Parent
                            $Home = Split-Path $Bin -Parent
                            Add-JavaCandidate $Candidates (Join-Path $Home "jbr")
                        }
                    }
                }
        } catch {
            # Continue avec les autres methodes.
        }
    }

    # 3) Raccourcis du menu Demarrer.
    try {
        $WshShell = New-Object -ComObject WScript.Shell
        $ShortcutRoots = @(
            (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"),
            (Join-Path $env:ProgramData "Microsoft\Windows\Start Menu\Programs")
        )

        foreach ($ShortcutRoot in $ShortcutRoots) {
            if (-not (Test-Path $ShortcutRoot)) { continue }

            Get-ChildItem -Path $ShortcutRoot -Filter "*.lnk" -Recurse -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -like "*Android Studio*" } |
                ForEach-Object {
                    $Target = $WshShell.CreateShortcut($_.FullName).TargetPath
                    if ($Target -and (Test-Path $Target)) {
                        $Bin = Split-Path $Target -Parent
                        $Home = Split-Path $Bin -Parent
                        Add-JavaCandidate $Candidates (Join-Path $Home "jbr")
                    }
                }
        }
    } catch {
        # Continue avec les autres methodes.
    }

    # 4) Emplacements habituels.
    Add-JavaCandidate $Candidates (Join-Path $env:ProgramFiles "Android\Android Studio\jbr")
    Add-JavaCandidate $Candidates (Join-Path $env:ProgramFiles "Android Studio\jbr")
    Add-JavaCandidate $Candidates (Join-Path $env:LOCALAPPDATA "Programs\Android Studio\jbr")
    Add-JavaCandidate $Candidates (Join-Path $env:LOCALAPPDATA "Google\AndroidStudio\jbr")
    if (${env:ProgramFiles(x86)}) {
        Add-JavaCandidate $Candidates (Join-Path ${env:ProgramFiles(x86)} "Android\Android Studio\jbr")
        Add-JavaCandidate $Candidates (Join-Path ${env:ProgramFiles(x86)} "Android Studio\jbr")
    }
}

function Select-JavaHomeManually {
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $Dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $Dialog.Description = "Selectionne le dossier Android Studio (contenant jbr), ou directement le dossier jbr."
        $Dialog.ShowNewFolderButton = $false

        if ($Dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
            return $null
        }

        $Selected = $Dialog.SelectedPath
        $DirectMajor = Get-JavaMajorVersion $Selected
        if ($null -ne $DirectMajor -and $DirectMajor -ge $MinimumJavaMajor) {
            return [PSCustomObject]@{ Home = $Selected; Major = $DirectMajor }
        }

        $Jbr = Join-Path $Selected "jbr"
        $JbrMajor = Get-JavaMajorVersion $Jbr
        if ($null -ne $JbrMajor -and $JbrMajor -ge $MinimumJavaMajor) {
            return [PSCustomObject]@{ Home = $Jbr; Major = $JbrMajor }
        }
    } catch {
        # Le selecteur graphique n'est pas indispensable.
    }

    return $null
}

function Find-CompatibleJava {
    $Candidates = New-Object 'System.Collections.Generic.List[string]'

    Add-AndroidStudioJavaCandidates $Candidates

    # Variables courantes, seulement si elles pointent vers Java 17 ou plus recent.
    Add-JavaCandidate $Candidates $env:STUDIO_GRADLE_JDK
    Add-JavaCandidate $Candidates $env:STUDIO_JDK
    Add-JavaCandidate $Candidates $env:JDK_HOME
    Add-JavaCandidate $Candidates $env:JAVA_HOME

    # Installations JDK courantes sous Windows.
    $SearchRoots = @(
        (Join-Path $env:ProgramFiles "Eclipse Adoptium"),
        (Join-Path $env:ProgramFiles "Microsoft"),
        (Join-Path $env:ProgramFiles "Java"),
        (Join-Path $env:ProgramFiles "Zulu"),
        (Join-Path $env:ProgramFiles "Amazon Corretto")
    )

    foreach ($Root in $SearchRoots) {
        if ($Root -and (Test-Path $Root)) {
            Get-ChildItem -Path $Root -Directory -ErrorAction SilentlyContinue |
                Sort-Object Name -Descending |
                ForEach-Object {
                    Add-JavaCandidate $Candidates $_.FullName
                    # Certaines distributions rangent le JDK un niveau plus bas.
                    Get-ChildItem -Path $_.FullName -Directory -ErrorAction SilentlyContinue |
                        ForEach-Object { Add-JavaCandidate $Candidates $_.FullName }
                }
        }
    }

    # Java actuellement visible dans PATH, en dernier recours.
    $JavaCommand = Get-Command java.exe -ErrorAction SilentlyContinue
    if ($JavaCommand) {
        $JavaHomeFromPath = Split-Path (Split-Path $JavaCommand.Source -Parent) -Parent
        Add-JavaCandidate $Candidates $JavaHomeFromPath
    }

    $Seen = @{}
    foreach ($Candidate in $Candidates) {
        try {
            $Normalized = [System.IO.Path]::GetFullPath($Candidate).TrimEnd('\')
        }
        catch {
            continue
        }

        $Key = $Normalized.ToLowerInvariant()
        if ($Seen.ContainsKey($Key)) {
            continue
        }
        $Seen[$Key] = $true

        $Major = Get-JavaMajorVersion $Normalized
        if ($null -eq $Major) {
            continue
        }

        if ($Major -ge $MinimumJavaMajor) {
            return [PSCustomObject]@{
                Home = $Normalized
                Major = $Major
            }
        }

        Write-Host "Java $Major ignore (trop ancien) : $Normalized" -ForegroundColor DarkYellow
    }

    Write-Host "Le JDK d'Android Studio n'a pas ete localise automatiquement." -ForegroundColor Yellow
    Write-Host "Une fenetre va te demander de selectionner le dossier Android Studio ou son sous-dossier jbr." -ForegroundColor Yellow
    return Select-JavaHomeManually
}

function Download-File([string]$Url, [string]$Destination) {
    Write-Host "Telechargement de Gradle $Version (environ 140 Mo)..." -ForegroundColor Cyan

    try {
        Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $Destination -MaximumRedirection 10
        return
    }
    catch {
        Write-Host "Le telechargement PowerShell a echoue. Nouvelle tentative avec curl..." -ForegroundColor Yellow
    }

    $Curl = Get-Command curl.exe -ErrorAction SilentlyContinue
    if (-not $Curl) {
        throw "Impossible de telecharger Gradle. Verifie la connexion Internet puis recommence."
    }

    & $Curl.Source -L --fail --retry 3 --retry-delay 2 -o $Destination $Url
    if ($LASTEXITCODE -ne 0) {
        throw "curl n'a pas reussi a telecharger Gradle (code $LASTEXITCODE)."
    }
}

try {
    Write-Host "Preparation du projet Nova..." -ForegroundColor Cyan

    $CompatibleJava = Find-CompatibleJava
    if ($null -eq $CompatibleJava) {
        throw "Aucun JDK Java 17 ou plus recent n'a ete selectionne. Relance le script et choisis le dossier d'installation d'Android Studio, ou directement son dossier jbr."
    }

    $env:JAVA_HOME = $CompatibleJava.Home
    $env:JDK_HOME = $CompatibleJava.Home
    $env:STUDIO_GRADLE_JDK = $CompatibleJava.Home
    $env:Path = "$($CompatibleJava.Home)\bin;$env:Path"
    Write-Host "Java selectionne : version $($CompatibleJava.Major) - $($CompatibleJava.Home)" -ForegroundColor Green

    New-Item -ItemType Directory -Force -Path $TempRoot | Out-Null
    Remove-Item $ZipPath -Force -ErrorAction SilentlyContinue
    Remove-Item $ExtractRoot -Recurse -Force -ErrorAction SilentlyContinue

    Download-File -Url $DistributionUrl -Destination $ZipPath

    Write-Host "Verification du telechargement..." -ForegroundColor Cyan
    $ActualSha256 = (Get-FileHash -Path $ZipPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($ActualSha256 -ne $ExpectedSha256) {
        throw "Le fichier Gradle telecharge est incomplet ou invalide. SHA-256 obtenu : $ActualSha256"
    }

    Write-Host "Extraction de Gradle..." -ForegroundColor Cyan
    Expand-Archive -Path $ZipPath -DestinationPath $ExtractRoot -Force

    if (-not (Test-Path $GradleBat)) {
        throw "Le programme Gradle n'a pas ete trouve apres extraction."
    }

    Write-Host "Creation du Gradle Wrapper officiel..." -ForegroundColor Cyan
    & $GradleBat --no-daemon -p $ProjectRoot wrapper --gradle-version $Version --distribution-type bin
    if ($LASTEXITCODE -ne 0) {
        throw "Gradle n'a pas reussi a creer le Wrapper (code $LASTEXITCODE)."
    }

    $WrapperJar = Join-Path $ProjectRoot "gradle\wrapper\gradle-wrapper.jar"
    $GradlewBat = Join-Path $ProjectRoot "gradlew.bat"
    if (-not (Test-Path $WrapperJar) -or -not (Test-Path $GradlewBat)) {
        throw "Les fichiers Gradle Wrapper n'ont pas ete crees correctement."
    }

    Write-Host "Verification finale du Wrapper..." -ForegroundColor Cyan
    & $GradlewBat --no-daemon --version
    if ($LASTEXITCODE -ne 0) {
        throw "Le Wrapper a ete cree, mais sa verification a echoue."
    }

    Write-Host ""
    Write-Host "Projet pret ! Ouvre maintenant le dossier Nova dans Android Studio." -ForegroundColor Green
}
catch {
    Write-Host ""
    Write-Host "La preparation a echoue : $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
finally {
    Remove-Item $TempRoot -Recurse -Force -ErrorAction SilentlyContinue
}
