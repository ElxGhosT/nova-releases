Pour permettre le bouton « Partager l’APK Nova Support », place ici un APK signé nommé :
nova-support.apk

Le script INTEGRER_NOVA_SUPPORT.cmd automatise cette copie.
