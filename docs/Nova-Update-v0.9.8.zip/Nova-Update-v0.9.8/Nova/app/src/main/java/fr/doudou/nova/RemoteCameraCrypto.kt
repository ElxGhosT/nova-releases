package fr.doudou.nova

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object RemoteCameraCrypto {
    private const val PAYLOAD_VERSION: Byte = 3
    private const val IV_LENGTH = 12
    private val secureRandom = SecureRandom()

    fun normalizeCode(value: String): String = value
        .uppercase()
        .filter { it.isLetterOrDigit() }

    fun newRequestNonce(): ByteArray = ByteArray(RemoteCameraProtocol.NONCE_BYTES).also(secureRandom::nextBytes)

    fun authTag(code: String, requestNonce: ByteArray, command: Int, payload: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(deriveKey(code, "auth-v2"), "HmacSHA256"))
        mac.update("NOVA_SUPPORT_REQUEST_V2".toByteArray(Charsets.US_ASCII))
        mac.update(requestNonce)
        mac.update(command.toByte())
        mac.update(payload)
        return mac.doFinal()
    }

    fun decryptPayload(payload: ByteArray, code: String, requestNonce: ByteArray, command: Int): ByteArray {
        require(payload.size > 1 + IV_LENGTH + 16) { "Trame distante trop courte" }
        require(payload[0] == PAYLOAD_VERSION) { "Version de trame distante incompatible" }
        val iv = payload.copyOfRange(1, 1 + IV_LENGTH)
        val encrypted = payload.copyOfRange(1 + IV_LENGTH, payload.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(
            Cipher.DECRYPT_MODE,
            SecretKeySpec(deriveKey(code, "payload-v2"), "AES"),
            GCMParameterSpec(128, iv)
        )
        cipher.updateAAD(requestNonce)
        cipher.updateAAD(command.toByte().let { byteArrayOf(it) })
        return cipher.doFinal(encrypted)
    }

    fun constantTimeEquals(left: ByteArray, right: ByteArray): Boolean =
        MessageDigest.isEqual(left, right)

    private fun deriveKey(code: String, purpose: String): ByteArray =
        MessageDigest.getInstance("SHA-256")
            .digest("nova-support-$purpose:${normalizeCode(code)}".toByteArray(Charsets.UTF_8))
}
