package fr.doudou.nova

import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import fr.doudou.nova.databinding.ActivityMediaVaultBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MediaVaultActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMediaVaultBinding
    private lateinit var adapter: MediaAdapter
    private lateinit var vault: MediaVault
    private var folderEntries: List<Pair<MediaFolder, Int>> = emptyList()
    private var currentFolderId: String = FOLDER_IMAGES
    private var pendingImportedUris: List<Uri> = emptyList()

    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        importSelectedMedia(uris)
    }

    private val deleteRequestLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        val message = if (result.resultCode == Activity.RESULT_OK) {
            "Les originaux autorisés ont été retirés de la galerie."
        } else {
            "Les originaux restent dans la galerie. Les copies privées sont conservées dans Nova."
        }
        pendingImportedUris = emptyList()
        AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK", null).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!SecuritySession.isUnlocked()) {
            startActivity(Intent(this, GateActivity::class.java).apply {
                putExtra(GateActivity.EXTRA_DESTINATION, GateActivity.DESTINATION_MEDIA)
            })
            finish()
            return
        }
        SecuritySession.unlock(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        binding = ActivityMediaVaultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        vault = MediaVault(this)
        adapter = MediaAdapter(
            vault = vault,
            items = emptyList(),
            onClick = { item ->
                startActivity(Intent(this, MediaViewerActivity::class.java).apply {
                    putExtra(MediaViewerActivity.EXTRA_MEDIA_ID, item.id)
                })
            },
            onSelectionChanged = ::updateSelectionUi
        )
        binding.mediaRecycler.layoutManager = GridLayoutManager(this, 2)
        binding.mediaRecycler.adapter = adapter

        binding.vaultBackButton.setOnClickListener { handleBack() }
        binding.newFolderButton.setOnClickListener { showNewFolderDialog() }
        binding.importMediaButton.setOnClickListener { startImport() }
        binding.selectMediaButton.setOnClickListener { adapter.beginSelection() }
        binding.selectAllButton.setOnClickListener { adapter.selectAll() }
        binding.moveSelectedButton.setOnClickListener {
            val selected = adapter.selectedItems()
            if (selected.isNotEmpty()) showMoveDialog(selected)
        }
        binding.deleteSelectedButton.setOnClickListener {
            val selected = adapter.selectedItems()
            if (selected.isNotEmpty()) confirmDeleteSelected(selected)
        }
        binding.cancelSelectionButton.setOnClickListener { adapter.clearSelection() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = handleBack()
        })
        setupFolderSpinner()
    }

    override fun onResume() {
        super.onResume()
        if (!SecuritySession.isUnlocked()) {
            startActivity(Intent(this, GateActivity::class.java).apply {
                putExtra(GateActivity.EXTRA_DESTINATION, GateActivity.DESTINATION_MEDIA)
            })
            finish()
            return
        }
        SecuritySession.unlock(this)
        refresh()
    }

    private fun handleBack() {
        if (::adapter.isInitialized && adapter.isSelectionMode()) {
            adapter.clearSelection()
        } else {
            finish()
        }
    }

    private fun setupFolderSpinner(selectFolderId: String = currentFolderId) {
        folderEntries = vault.flattenedFolders()
        val labels = folderEntries.map { (folder, depth) ->
            "${"   ".repeat(depth)}${if (folder.system) "●" else "↳"} ${folder.name}"
        }
        binding.folderSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            labels
        )
        binding.folderSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (::adapter.isInitialized && adapter.isSelectionMode()) adapter.clearSelection()
                currentFolderId = folderEntries.getOrNull(position)?.first?.id ?: FOLDER_IMAGES
                binding.vaultTitle.text = vault.folderName(currentFolderId)
                refresh()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        val selectedIndex = folderEntries.indexOfFirst { it.first.id == selectFolderId }.coerceAtLeast(0)
        binding.folderSpinner.setSelection(selectedIndex)
    }

    private fun refresh() {
        if (!::adapter.isInitialized) return
        val items = vault.list(currentFolderId)
        adapter.submit(items)
        binding.vaultCount.text = items.size.toString()
        binding.selectMediaButton.isEnabled = items.isNotEmpty()
        binding.vaultEmptyText.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        binding.mediaRecycler.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun updateSelectionUi(selected: List<MediaItem>) {
        if (!::adapter.isInitialized) return
        val active = adapter.isSelectionMode()
        binding.normalActionBar.visibility = if (active) View.GONE else View.VISIBLE
        binding.selectionBar.visibility = if (active) View.VISIBLE else View.GONE
        binding.folderSpinner.isEnabled = !active
        binding.selectedCountText.text = when (selected.size) {
            0 -> "0 sélectionné"
            1 -> "1 sélectionné"
            else -> "${selected.size} sélectionnés"
        }
        binding.moveSelectedButton.isEnabled = selected.isNotEmpty()
        binding.deleteSelectedButton.isEnabled = selected.isNotEmpty()
    }

    private fun showMoveDialog(items: List<MediaItem>) {
        val entries = vault.flattenedFolders()
        val labels = entries.map { (folder, depth) ->
            "${"   ".repeat(depth)}${if (folder.system) "●" else "↳"} ${folder.name}"
        }.toTypedArray()
        val currentIndex = if (items.map { it.folderId }.distinct().size == 1) {
            entries.indexOfFirst { it.first.id == items.first().folderId }.coerceAtLeast(0)
        } else {
            entries.indexOfFirst { it.first.id == currentFolderId }.coerceAtLeast(0)
        }
        var selectedIndex = currentIndex
        AlertDialog.Builder(this)
            .setTitle(if (items.size == 1) "Déplacer le média" else "Déplacer ${items.size} médias")
            .setSingleChoiceItems(labels, currentIndex) { _, which -> selectedIndex = which }
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Déplacer") { _, _ ->
                val destination = entries.getOrNull(selectedIndex)?.first ?: return@setPositiveButton
                binding.vaultProgress.visibility = View.VISIBLE
                lifecycleScope.launch {
                    val result = runCatching {
                        withContext(Dispatchers.IO) { vault.move(items, destination.id) }
                    }
                    binding.vaultProgress.visibility = View.GONE
                    result.onSuccess {
                        adapter.clearSelection()
                        refresh()
                    }.onFailure { error ->
                        AlertDialog.Builder(this@MediaVaultActivity)
                            .setMessage(error.message ?: "Déplacement impossible.")
                            .setPositiveButton("OK", null)
                            .show()
                    }
                }
            }
            .show()
    }

    private fun confirmDeleteSelected(items: List<MediaItem>) {
        AlertDialog.Builder(this)
            .setTitle(if (items.size == 1) "Supprimer ce média ?" else "Supprimer ${items.size} médias ?")
            .setMessage("La suppression des fichiers privés sélectionnés est définitive.")
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Supprimer") { _, _ ->
                binding.vaultProgress.visibility = View.VISIBLE
                lifecycleScope.launch {
                    val result = runCatching {
                        withContext(Dispatchers.IO) { vault.delete(items) }
                    }
                    binding.vaultProgress.visibility = View.GONE
                    result.onSuccess {
                        adapter.clearSelection()
                        refresh()
                    }.onFailure { error ->
                        AlertDialog.Builder(this@MediaVaultActivity)
                            .setMessage(error.message ?: "Suppression impossible.")
                            .setPositiveButton("OK", null)
                            .show()
                    }
                }
            }
            .show()
    }

    private fun showNewFolderDialog() {
        val input = EditText(this).apply {
            hint = "Nom du sous-dossier"
            maxLines = 1
        }
        val padding = (20 * resources.displayMetrics.density).toInt()
        input.setPadding(padding, 0, padding, 0)
        val parentName = vault.folderName(currentFolderId)
        AlertDialog.Builder(this)
            .setTitle("Nouveau dossier dans $parentName")
            .setView(input)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Créer") { _, _ ->
                runCatching { vault.createFolder(input.text.toString(), currentFolderId) }
                    .onSuccess { folder -> setupFolderSpinner(folder.id) }
                    .onFailure { error ->
                        AlertDialog.Builder(this)
                            .setMessage(error.message ?: "Impossible de créer le dossier.")
                            .setPositiveButton("OK", null)
                            .show()
                    }
            }
            .show()
    }

    private fun startImport() {
        if (!isOtherFolder(currentFolderId)) {
            currentFolderId = FOLDER_OTHER
            setupFolderSpinner(FOLDER_OTHER)
        }
        importLauncher.launch(arrayOf("image/*", "video/*"))
    }

    private fun isOtherFolder(folderId: String): Boolean {
        if (folderId == FOLDER_OTHER) return true
        val byId = vault.folders().associateBy { it.id }
        var current = byId[folderId]
        while (current != null) {
            if (current.parentId == FOLDER_OTHER) return true
            current = current.parentId?.let(byId::get)
        }
        return false
    }

    private fun importSelectedMedia(uris: List<Uri>) {
        binding.vaultProgress.visibility = View.VISIBLE
        binding.importMediaButton.isEnabled = false
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                val successes = mutableListOf<Uri>()
                val errors = mutableListOf<String>()
                uris.forEach { uri ->
                    runCatching { vault.importUri(uri, currentFolderId) }
                        .onSuccess { successes += uri }
                        .onFailure { errors += (it.message ?: "Import impossible") }
                }
                successes to errors
            }
            binding.vaultProgress.visibility = View.GONE
            binding.importMediaButton.isEnabled = true
            refresh()
            val successes = result.first
            val errors = result.second
            if (successes.isNotEmpty()) {
                pendingImportedUris = successes
                val message = buildString {
                    append("${successes.size} média(s) copié(s) et chiffré(s) dans Nova.")
                    if (errors.isNotEmpty()) append("\n${errors.size} échec(s).")
                    append("\n\nRetirer maintenant les originaux de la galerie ? Android affichera une confirmation système.")
                }
                AlertDialog.Builder(this@MediaVaultActivity)
                    .setTitle("Import terminé")
                    .setMessage(message)
                    .setNegativeButton("Conserver les originaux", null)
                    .setPositiveButton("Retirer les originaux") { _, _ -> requestOriginalDeletion() }
                    .show()
            } else {
                AlertDialog.Builder(this@MediaVaultActivity)
                    .setMessage(errors.joinToString("\n").ifBlank { "Aucun média n’a été importé." })
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }

    private fun requestOriginalDeletion() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            showManualDeletionMessage()
            return
        }
        val mediaUris = pendingImportedUris.mapNotNull(::toMediaStoreUri).distinct()
        if (mediaUris.isEmpty()) {
            showManualDeletionMessage()
            return
        }
        runCatching {
            val request = MediaStore.createDeleteRequest(contentResolver, mediaUris)
            deleteRequestLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
        }.onFailure { showManualDeletionMessage() }
    }

    private fun toMediaStoreUri(uri: Uri): Uri? {
        if (uri.authority == MediaStore.AUTHORITY) return uri
        if (!DocumentsContract.isDocumentUri(this, uri) ||
            uri.authority != "com.android.providers.media.documents"
        ) return null

        val documentId = runCatching { DocumentsContract.getDocumentId(uri) }.getOrNull() ?: return null
        val parts = documentId.split(':', limit = 2)
        if (parts.size != 2) return null
        val numericId = parts[1].toLongOrNull() ?: return null
        val base = when (parts[0]) {
            "image" -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            "video" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            else -> return null
        }
        return ContentUris.withAppendedId(base, numericId)
    }

    private fun showManualDeletionMessage() {
        pendingImportedUris = emptyList()
        AlertDialog.Builder(this)
            .setMessage(
                "Les copies privées sont bien dans Nova, mais Android n’autorise pas Nova à supprimer automatiquement ces originaux. Supprime-les manuellement dans Galerie pour qu’ils n’y apparaissent plus."
            )
            .setPositiveButton("OK", null)
            .show()
    }

    override fun onDestroy() {
        if (::adapter.isInitialized) adapter.close()
        super.onDestroy()
    }
}
