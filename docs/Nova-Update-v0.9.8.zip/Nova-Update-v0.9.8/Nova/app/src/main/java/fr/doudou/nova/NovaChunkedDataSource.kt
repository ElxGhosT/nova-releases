package fr.doudou.nova

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import java.io.File
import java.io.IOException
import kotlin.math.min

/** Source Media3 qui déchiffre uniquement les blocs demandés par ExoPlayer. */
@UnstableApi
class NovaChunkedDataSource(
    private val encryptedFile: File
) : BaseDataSource(false) {

    private var reader: VaultCrypto.ChunkReader? = null
    private var opened = false
    private var sourceUri: Uri? = null
    private var readPosition = 0L
    private var bytesRemaining = 0L
    private var cachedChunkIndex = -1
    private var cachedChunk = ByteArray(0)

    @Throws(IOException::class)
    override fun open(dataSpec: DataSpec): Long {
        transferInitializing(dataSpec)
        val created = try {
            VaultCrypto.openChunkedReader(encryptedFile)
        } catch (error: Throwable) {
            throw IOException("Impossible d'ouvrir la vidéo privée.", error)
        }

        if (dataSpec.position < 0L || dataSpec.position > created.originalLength) {
            created.close()
            throw IOException("Position vidéo invalide : ${dataSpec.position}.")
        }

        reader = created
        sourceUri = dataSpec.uri
        readPosition = dataSpec.position
        val available = created.originalLength - readPosition
        bytesRemaining = if (dataSpec.length == C.LENGTH_UNSET.toLong()) {
            available
        } else {
            min(available, dataSpec.length)
        }
        cachedChunkIndex = -1
        cachedChunk = ByteArray(0)
        opened = true
        transferStarted(dataSpec)
        return bytesRemaining
    }

    @Throws(IOException::class)
    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (bytesRemaining == 0L) return C.RESULT_END_OF_INPUT
        val activeReader = reader ?: throw IOException("La source vidéo n'est pas ouverte.")

        val chunkIndex = (readPosition / activeReader.chunkSize.toLong()).toInt()
        if (chunkIndex != cachedChunkIndex) {
            cachedChunk = try {
                activeReader.readChunk(chunkIndex)
            } catch (error: Throwable) {
                throw IOException("Impossible de déchiffrer la vidéo privée.", error)
            }
            cachedChunkIndex = chunkIndex
        }

        val offsetInChunk = (readPosition % activeReader.chunkSize.toLong()).toInt()
        val availableInChunk = cachedChunk.size - offsetInChunk
        if (availableInChunk <= 0) return C.RESULT_END_OF_INPUT
        val bytesToCopy = min(length.toLong(), min(bytesRemaining, availableInChunk.toLong())).toInt()
        System.arraycopy(cachedChunk, offsetInChunk, buffer, offset, bytesToCopy)
        readPosition += bytesToCopy.toLong()
        bytesRemaining -= bytesToCopy.toLong()
        bytesTransferred(bytesToCopy)
        return bytesToCopy
    }

    override fun getUri(): Uri? = sourceUri

    override fun close() {
        sourceUri = null
        reader?.close()
        reader = null
        cachedChunkIndex = -1
        cachedChunk = ByteArray(0)
        if (opened) {
            opened = false
            transferEnded()
        }
    }

    class Factory(private val encryptedFile: File) : DataSource.Factory {
        override fun createDataSource(): DataSource = NovaChunkedDataSource(encryptedFile)
    }
}
