package fr.doudou.nova

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build

object DirectNetworkConnector {
    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var boundNetwork: Network? = null

    fun isConnected(): Boolean = boundNetwork != null

    @SuppressLint("MissingPermission")
    fun connect(
        context: Context,
        ssid: String,
        password: String,
        security: String,
        onAvailable: () -> Unit,
        onError: (String) -> Unit
    ) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            onError("Le Réseau direct Nova nécessite Android 10 ou une version plus récente.")
            return
        }
        disconnect()
        val manager = context.applicationContext.getSystemService(ConnectivityManager::class.java)
        connectivityManager = manager

        val specifierBuilder = WifiNetworkSpecifier.Builder().setSsid(ssid)
        if (password.isNotBlank() && !security.equals("OPEN", ignoreCase = true)) {
            if (security.contains("WPA3", ignoreCase = true)) {
                specifierBuilder.setWpa3Passphrase(password)
            } else {
                specifierBuilder.setWpa2Passphrase(password)
            }
        }
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .setNetworkSpecifier(specifierBuilder.build())
            .build()

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                boundNetwork = network
                manager.bindProcessToNetwork(network)
                onAvailable()
            }

            override fun onLost(network: Network) {
                if (boundNetwork == network) {
                    boundNetwork = null
                    manager.bindProcessToNetwork(null)
                }
            }

            override fun onUnavailable() {
                boundNetwork = null
                manager.bindProcessToNetwork(null)
                onError(
                    "Connexion refusée ou expirée. Scanne le QR Wi-Fi standard de Nova Support, " +
                        "ou vérifie le mot de passe puis appuie sur Réessayer."
                )
            }
        }
        networkCallback = callback
        runCatching { manager.requestNetwork(request, callback, 30_000) }
            .onFailure {
                networkCallback = null
                onError(it.message ?: "Impossible de demander la connexion Wi-Fi directe.")
            }
    }

    fun disconnect() {
        val manager = connectivityManager
        val callback = networkCallback
        if (manager != null && callback != null) {
            runCatching { manager.unregisterNetworkCallback(callback) }
        }
        runCatching { manager?.bindProcessToNetwork(null) }
        connectivityManager = null
        networkCallback = null
        boundNetwork = null
    }
}
