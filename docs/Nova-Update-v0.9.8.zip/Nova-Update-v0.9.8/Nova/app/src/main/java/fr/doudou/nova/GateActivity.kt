package fr.doudou.nova

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import fr.doudou.nova.databinding.ActivityGateBinding

class GateActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGateBinding
    private var setupMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)

        if (SecuritySession.isUnlocked()) {
            openDestination()
            return
        }

        binding = ActivityGateBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupMode = !SecurityStore.hasPin(this)
        renderMode()
        setupActions()

        if (!setupMode && AppPrefs.biometricEnabled(this) && biometricAvailable()) {
            binding.biometricButton.visibility = View.VISIBLE
            binding.root.postDelayed({ showBiometricPrompt() }, 250L)
        } else {
            binding.biometricButton.visibility = View.GONE
        }
    }

    private fun renderMode() {
        if (setupMode) {
            binding.gateSubtitle.text = "Crée un PIN pour protéger les médias privés"
            binding.pinConfirmLayout.visibility = View.VISIBLE
            binding.unlockButton.text = "Créer le PIN"
            binding.biometricButton.visibility = View.GONE
        } else {
            binding.gateSubtitle.text = "Déverrouillage sécurisé"
            binding.pinConfirmLayout.visibility = View.GONE
            binding.unlockButton.text = "Déverrouiller"
        }
    }

    private fun setupActions() {
        binding.unlockButton.setOnClickListener {
            binding.gateMessage.text = ""
            val pinText = binding.pinInput.text?.toString().orEmpty()
            if (setupMode) {
                val confirmation = binding.pinConfirmInput.text?.toString().orEmpty()
                when {
                    pinText.length < 6 -> binding.gateMessage.text = "Le PIN doit contenir au moins 6 chiffres."
                    pinText.any { !it.isDigit() } -> binding.gateMessage.text = "Utilise uniquement des chiffres."
                    pinText != confirmation -> binding.gateMessage.text = "Les deux PIN ne correspondent pas."
                    else -> {
                        SecurityStore.setPin(this, pinText.toCharArray())
                        SecuritySession.unlock(this)
                        openDestination()
                    }
                }
            } else {
                if (SecurityStore.verifyPin(this, pinText.toCharArray())) {
                    SecuritySession.unlock(this)
                    openDestination()
                } else {
                    binding.gateMessage.text = "PIN incorrect."
                    binding.pinInput.text?.clear()
                }
            }
        }

        binding.biometricButton.setOnClickListener { showBiometricPrompt() }
    }

    private fun biometricAvailable(): Boolean {
        return BiometricManager.from(this).canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG
        ) == BiometricManager.BIOMETRIC_SUCCESS
    }

    private fun showBiometricPrompt() {
        if (!biometricAvailable() || isFinishing) return
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(
            this,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(
                    result: BiometricPrompt.AuthenticationResult
                ) {
                    SecuritySession.unlock(this@GateActivity)
                    openDestination()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    if (errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON &&
                        errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                        errorCode != BiometricPrompt.ERROR_CANCELED
                    ) {
                        binding.gateMessage.text = errString
                    }
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Nova")
            .setSubtitle("Déverrouiller les fonctions privées")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .setNegativeButtonText("Utiliser le PIN Nova")
            .build()
        prompt.authenticate(info)
    }

    private fun openDestination() {
        val destination = intent.getStringExtra(EXTRA_DESTINATION)
        val target = when (destination) {
            DESTINATION_QUICK -> QuickCaptureActivity::class.java
            DESTINATION_MEDIA -> MediaVaultActivity::class.java
            DESTINATION_SETTINGS -> SettingsActivity::class.java
            DESTINATION_REMOTE -> RemoteCameraActivity::class.java
            else -> MainActivity::class.java
        }
        startActivity(Intent(this, target).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        })
        finish()
    }

    companion object {
        const val EXTRA_DESTINATION = "destination"
        const val DESTINATION_QUICK = "quick"
        const val DESTINATION_MEDIA = "media"
        const val DESTINATION_SETTINGS = "settings"
        const val DESTINATION_REMOTE = "remote"
    }
}
