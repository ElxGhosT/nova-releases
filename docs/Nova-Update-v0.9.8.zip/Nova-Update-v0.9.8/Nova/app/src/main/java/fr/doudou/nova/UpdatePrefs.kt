package fr.doudou.nova

import android.content.Context

object UpdatePrefs {
    private const val PREFS = "nova_updates"
    private const val KEY_BASE_URL = "base_url"
    private const val KEY_AUTO_CHECK = "auto_check"
    private const val KEY_LAST_CHECK = "last_check"
    private const val KEY_LAST_NOTIFIED_VERSION = "last_notified_version"

    fun baseUrl(context: Context): String = context
        .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_BASE_URL, BuildConfig.NOVA_UPDATE_BASE_URL)
        .orEmpty()
        .trim()
        .trimEnd('/')

    fun setBaseUrl(context: Context, value: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_BASE_URL, value.trim().trimEnd('/'))
            .apply()
    }

    fun autoCheck(context: Context): Boolean = context
        .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getBoolean(KEY_AUTO_CHECK, false)

    fun setAutoCheck(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_AUTO_CHECK, enabled)
            .apply()
    }

    fun shouldAutoCheck(context: Context, now: Long = System.currentTimeMillis()): Boolean {
        if (!autoCheck(context) || !baseUrl(context).startsWith("https://")) return false
        val last = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getLong(KEY_LAST_CHECK, 0L)
        return now - last >= AUTO_CHECK_INTERVAL_MS
    }

    fun markAutoCheck(context: Context, now: Long = System.currentTimeMillis()) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putLong(KEY_LAST_CHECK, now)
            .apply()
    }

    fun lastNotifiedVersion(context: Context): Long = context
        .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getLong(KEY_LAST_NOTIFIED_VERSION, 0L)

    fun markNotifiedVersion(context: Context, versionCode: Long) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putLong(KEY_LAST_NOTIFIED_VERSION, versionCode)
            .apply()
    }

    private const val AUTO_CHECK_INTERVAL_MS = 24L * 60L * 60L * 1000L
}
