package fr.doudou.nova

import androidx.camera.core.Preview
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface CaptureState {
    data object Idle : CaptureState
    data object Starting : CaptureState
    data class Armed(val cameraMode: String, val dualVideoAvailable: Boolean) : CaptureState
    data class Recording(
        val sessionDurationMs: Long,
        val segmentDurationMs: Long,
        val segmentIndex: Int,
        val bytes: Long,
        val streamCount: Int,
        val photoDuringVideoAvailable: Boolean
    ) : CaptureState
    data object Stopping : CaptureState
    data class PhotoSaved(val count: Int) : CaptureState
    data class Error(val message: String) : CaptureState
}

object CaptureStateStore {
    private val mutableState = MutableStateFlow<CaptureState>(CaptureState.Idle)
    val state = mutableState.asStateFlow()

    fun update(value: CaptureState) {
        mutableState.value = value
    }
}

object PreviewBridge {
    private var backPreview: Preview? = null
    private var frontPreview: Preview? = null
    private var backProvider: Preview.SurfaceProvider? = null
    private var frontProvider: Preview.SurfaceProvider? = null

    @Synchronized
    fun attachProviders(
        back: Preview.SurfaceProvider?,
        front: Preview.SurfaceProvider?
    ) {
        backProvider = back
        frontProvider = front
        backPreview?.setSurfaceProvider(backProvider)
        frontPreview?.setSurfaceProvider(frontProvider)
    }

    @Synchronized
    fun publishPreviews(back: Preview?, front: Preview?) {
        backPreview = back
        frontPreview = front
        backPreview?.setSurfaceProvider(backProvider)
        frontPreview?.setSurfaceProvider(frontProvider)
    }

    @Synchronized
    fun clearPreviews() {
        backPreview?.setSurfaceProvider(null)
        frontPreview?.setSurfaceProvider(null)
        backPreview = null
        frontPreview = null
    }
}

sealed interface CaptureEvent {
    data class PhotoSaved(val count: Int) : CaptureEvent
    data class VideoSaved(val count: Int, val segmentIndex: Int = 1) : CaptureEvent
    data class Error(val message: String) : CaptureEvent
}

object CaptureEventStore {
    private val mutableEvents = MutableSharedFlow<CaptureEvent>(extraBufferCapacity = 16)
    val events = mutableEvents.asSharedFlow()

    fun emit(event: CaptureEvent) {
        mutableEvents.tryEmit(event)
    }
}
