package fr.doudou.nova

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import fr.doudou.nova.databinding.ActivityRemoteCameraBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.net.ConnectException
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.min

class RemoteCameraActivity : AppCompatActivity() {

    private data class RemoteVideoStatus(
        val requested: Boolean,
        val active: Boolean,
        val segmentIndex: Int,
        val durationMs: Long,
        val pendingSegments: Int,
        val message: String
    )

    private data class DirectPairing(
        val ssid: String,
        val password: String,
        val security: String,
        val host: String,
        val port: Int,
        val secret: String
    )

    private data class RemoteSegmentInfo(
        val id: Long,
        val size: Long,
        val durationMs: Long,
        val displayName: String
    )

    private data class RemotePhotoInfo(
        val id: Long,
        val size: Long,
        val displayName: String,
        val lens: String
    )

    private data class RemoteCapabilities(
        val currentLens: String,
        val hasBack: Boolean,
        val hasFront: Boolean,
        val hasFlash: Boolean,
        val recording: Boolean,
        val serverRunning: Boolean,
        val motionEnabled: Boolean,
        val motionSensitivity: Int,
        val motionDurationMs: Long,
        val batteryPercent: Int,
        val availableBytes: Long
    )

    private lateinit var binding: ActivityRemoteCameraBinding
    private lateinit var vault: MediaVault
    private var pollingJob: Job? = null
    private var statusJob: Job? = null
    private var transferJob: Job? = null
    private var captureJob: Job? = null
    private var controlJob: Job? = null
    private var activeEndpoint: Pair<String, Int>? = null
    private var activeCode: String = ""
    private var latestFrameBytes: ByteArray? = null
    private var remoteVideoStatus = RemoteVideoStatus(false, false, 0, 0L, 0, "")
    private var remoteCapabilities: RemoteCapabilities? = null
    private var pendingDirectPairing: DirectPairing? = null
    private var usingDirectNetwork = false
    private var suppressMotionUi = false
    private var connectionEstablished = false

    private val wifiPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) connectPendingDirectNetwork()
        else binding.statusText.text = "Autorisation Wi-Fi refusée : connexion directe impossible."
    }

    private val qrScanner = registerForActivityResult(ScanContract()) { result ->
        val content = result.contents ?: return@registerForActivityResult
        runCatching { applyPairingQr(content) }
            .onSuccess {
                if (pendingDirectPairing == null) {
                    binding.statusText.text = "QR code reconnu — connexion locale en cours"
                    connect()
                }
            }
            .onFailure { error ->
                binding.statusText.text = "QR code Nova Support invalide : ${error.message}"
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        binding = ActivityRemoteCameraBinding.inflate(layoutInflater)
        setContentView(binding.root)
        vault = MediaVault(this)

        binding.addressInput.setText(AppPrefs.remoteCameraAddress(this))
        binding.codeInput.setText(AppPrefs.remoteCameraCode(this))
        binding.scanQrButton.setOnClickListener { scanPairingQr() }
        binding.retryDirectConnectionButton.setOnClickListener { requestDirectNetworkPermission() }
        binding.connectButton.setOnClickListener { connect() }
        binding.disconnectButton.setOnClickListener { disconnect("Déconnecté") }
        binding.shareSupportButton.setOnClickListener { showSupportInstallQr() }
        binding.remoteCaptureButton.setOnClickListener { captureSingleSupportPhoto() }
        binding.remoteBurstButton.setOnClickListener { captureSupportBurst() }
        binding.remoteVideoButton.setOnClickListener { toggleRemoteVideo() }
        binding.remoteBackLensButton.setOnClickListener { requestRemoteLens(RemoteCameraProtocol.LENS_BACK) }
        binding.remoteFrontLensButton.setOnClickListener { requestRemoteLens(RemoteCameraProtocol.LENS_FRONT) }
        binding.restartRemoteNetworkButton.setOnClickListener { restartRemoteNetwork() }
        binding.stopRemoteServicesButton.setOnClickListener { confirmStopRemoteServices() }
        binding.remoteMotionSwitch.setOnCheckedChangeListener { _, checked ->
            if (!suppressMotionUi) sendMotionConfig(enabled = checked)
        }
        binding.remoteMotionSensitivitySeek.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val sensitivity = progress + 10
                    binding.remoteMotionSensitivityLabel.text = "Sensibilité : $sensitivity %"
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit

                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    sendMotionConfig(sensitivity = (seekBar?.progress ?: 45) + 10)
                }
            }
        )
        binding.remoteMotionDurationButton.setOnClickListener { chooseMotionDuration() }
        binding.openVaultButton.setOnClickListener {
            startActivity(Intent(this, MediaVaultActivity::class.java))
        }
        binding.remoteBackButton.setOnClickListener { finish() }

        renderMotionPrefs()
        updateCaptureButtons()
        renderRemoteVideoStatus()
    }

    override fun onResume() {
        super.onResume()
        binding.remoteBurstButton.text = "Rafale support (${AppPrefs.burstCount(this)})"
        activeEndpoint?.let { endpoint ->
            if (activeCode.isNotBlank()) startConnectionLoops(endpoint.first, endpoint.second, activeCode)
        }
    }

    private fun scanPairingQr() {
        qrScanner.launch(
            ScanOptions()
                .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                .setPrompt("Scanne le QR code d’appairage affiché par Nova Support")
                .setBeepEnabled(false)
                .setOrientationLocked(true)
                .setBarcodeImageEnabled(false)
        )
    }

    private fun applyPairingQr(raw: String) {
        val uri = Uri.parse(raw.trim())
        require(uri.scheme == PAIR_SCHEME && uri.host == PAIR_HOST) { "format non reconnu" }
        val version = uri.getQueryParameter("v")?.toIntOrNull() ?: 1
        require(version in 1..3) { "version incompatible" }
        val host = uri.getQueryParameter("host").orEmpty()
        val port = uri.getQueryParameter("port")?.toIntOrNull() ?: DEFAULT_PORT
        val secret = RemoteCameraCrypto.normalizeCode(uri.getQueryParameter("secret").orEmpty())
        require(host.isNotBlank()) { "adresse absente" }
        require(port in 1..65535) { "port incorrect" }
        require(secret.length >= 20) { "secret incomplet" }
        binding.addressInput.setText("$host:$port")
        binding.codeInput.setText(secret)
        AppPrefs.setRemoteCameraAddress(this, "$host:$port")
        AppPrefs.setRemoteCameraCode(this, secret)

        if (version >= 2 && uri.getQueryParameter("mode") == "direct") {
            val ssid = uri.getQueryParameter("ssid").orEmpty()
            val password = uri.getQueryParameter("password").orEmpty()
            val security = uri.getQueryParameter("security").orEmpty().ifBlank { "WPA2" }
            require(ssid.isNotBlank()) { "nom du réseau direct absent" }
            pendingDirectPairing = DirectPairing(ssid, password, security, host, port, secret)
            binding.retryDirectConnectionButton.visibility = View.VISIBLE
            requestDirectNetworkPermission()
        } else {
            pendingDirectPairing = null
            usingDirectNetwork = false
            binding.retryDirectConnectionButton.visibility = View.GONE
        }
    }

    private fun requestDirectNetworkPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            binding.statusText.text = "Le Réseau direct Nova nécessite Android 10 ou plus récent."
            return
        }
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.NEARBY_WIFI_DEVICES
        } else {
            Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            connectPendingDirectNetwork()
        } else {
            wifiPermissionLauncher.launch(permission)
        }
    }

    private fun connectPendingDirectNetwork() {
        val pairing = pendingDirectPairing ?: return
        binding.statusText.text = "Android va demander la connexion au réseau ${pairing.ssid}…"
        DirectNetworkConnector.connect(
            context = this,
            ssid = pairing.ssid,
            password = pairing.password,
            security = pairing.security,
            onAvailable = {
                runOnUiThread {
                    usingDirectNetwork = true
                    binding.retryDirectConnectionButton.visibility = View.GONE
                    pendingDirectPairing = null
                    activeEndpoint = pairing.host to pairing.port
                    activeCode = pairing.secret
                    latestFrameBytes = null
                    binding.statusText.text = "Réseau direct connecté — ouverture de Nova Support…"
                    lifecycleScope.launch {
                        delay(850L)
                        startConnectionLoops(pairing.host, pairing.port, pairing.secret)
                    }
                }
            },
            onError = { message ->
                runOnUiThread {
                    binding.retryDirectConnectionButton.visibility = View.VISIBLE
                    binding.statusText.text = message
                }
            }
        )
    }

    private fun connect() {
        val endpoint = parseEndpoint(binding.addressInput.text?.toString().orEmpty())
        val code = RemoteCameraCrypto.normalizeCode(binding.codeInput.text?.toString().orEmpty())
        when {
            endpoint == null -> binding.addressInput.error = "Adresse locale privée invalide"
            code.length < 20 -> binding.codeInput.error = "Secret d’appairage incomplet"
            else -> {
                val (host, port) = endpoint
                AppPrefs.setRemoteCameraAddress(this, "$host:$port")
                AppPrefs.setRemoteCameraCode(this, code)
                activeEndpoint = endpoint
                activeCode = code
                latestFrameBytes = null
                connectionEstablished = false
                startConnectionLoops(host, port, code)
            }
        }
    }

    private fun startConnectionLoops(host: String, port: Int, code: String) {
        startPolling(host, port, code)
        startStatusLoop(host, port, code)
    }

    private fun startPolling(host: String, port: Int, code: String) {
        pollingJob?.cancel()
        binding.statusText.text = "Connexion locale à $host:$port…"
        updateCaptureButtons()
        pollingJob = lifecycleScope.launch {
            var consecutiveErrors = 0
            while (isActive) {
                runCatching {
                    withContext(Dispatchers.IO) {
                        sendCommand(host, port, code, RemoteCameraProtocol.COMMAND_FRAME)
                    }
                }.onSuccess { bytes ->
                    consecutiveErrors = 0
                    connectionEstablished = true
                    latestFrameBytes = bytes
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let(binding.remoteImage::setImageBitmap)
                    if (!remoteVideoStatus.active && transferJob?.isActive != true && captureJob?.isActive != true) {
                        binding.statusText.text = "Connecté · aperçu local chiffré"
                    }
                    updateCaptureButtons()
                }.onFailure { error ->
                    consecutiveErrors += 1
                    connectionEstablished = false
                    if (consecutiveErrors == 1 || consecutiveErrors % 5 == 0) {
                        val detail = if (error is ConnectException || error.message?.contains("ECONNREFUSED") == true) {
                            "Service distant indisponible · reconnexion automatique…"
                        } else {
                            "Connexion interrompue : ${error.message}"
                        }
                        binding.statusText.text = detail
                    }
                }
                val pause = if (consecutiveErrors == 0) 350L else min(2_000L, 350L + consecutiveErrors * 180L)
                delay(pause)
            }
        }
    }

    private fun startStatusLoop(host: String, port: Int, code: String) {
        statusJob?.cancel()
        statusJob = lifecycleScope.launch {
            var tick = 0
            while (isActive) {
                runCatching {
                    withContext(Dispatchers.IO) {
                        parseVideoStatus(sendCommand(host, port, code, RemoteCameraProtocol.COMMAND_VIDEO_STATUS))
                    }
                }.onSuccess { status ->
                    remoteVideoStatus = status
                    renderRemoteVideoStatus()
                    if (status.pendingSegments > 0 && transferJob?.isActive != true) {
                        transferJob = lifecycleScope.launch { transferAvailableSegments(host, port, code) }
                    }
                }
                if (tick % 2 == 0) refreshRemoteCapabilities(host, port, code)
                tick += 1
                delay(1_000L)
            }
        }
    }

    private suspend fun refreshRemoteCapabilities(host: String, port: Int, code: String) {
        runCatching {
            withContext(Dispatchers.IO) {
                parseCapabilities(sendCommand(host, port, code, RemoteCameraProtocol.COMMAND_CAPABILITIES))
            }
        }.onSuccess { capabilities ->
            remoteCapabilities = capabilities
            renderCapabilities(capabilities)
            renderMotionCapabilities(capabilities)
            updateCaptureButtons()
        }
    }

    private fun parseCapabilities(payload: ByteArray): RemoteCapabilities {
        val input = DataInputStream(ByteArrayInputStream(payload))
        return RemoteCapabilities(
            currentLens = input.readUTF(),
            hasBack = input.readBoolean(),
            hasFront = input.readBoolean(),
            hasFlash = input.readBoolean(),
            recording = input.readBoolean(),
            serverRunning = input.readBoolean(),
            motionEnabled = input.readBoolean(),
            motionSensitivity = input.readInt(),
            motionDurationMs = input.readLong(),
            batteryPercent = input.readInt(),
            availableBytes = input.readLong()
        )
    }

    private fun renderCapabilities(value: RemoteCapabilities) {
        binding.remoteBackLensButton.isEnabled = value.hasBack && !value.recording
        binding.remoteFrontLensButton.isEnabled = value.hasFront && !value.recording
        binding.remoteBackLensButton.alpha = if (value.currentLens == AppPrefs.MODE_BACK || value.currentLens == "BACK") 1f else 0.62f
        binding.remoteFrontLensButton.alpha = if (value.currentLens == AppPrefs.MODE_FRONT || value.currentLens == "FRONT") 1f else 0.62f
        val lens = if (value.currentLens.equals("FRONT", true)) "avant" else "arrière"
        val battery = if (value.batteryPercent >= 0) "${value.batteryPercent}%" else "inconnue"
        val free = formatBytes(value.availableBytes)
        binding.remoteCapabilitiesText.text =
            "Caméra $lens · flash ${if (value.hasFlash) "disponible" else "absent"} · batterie $battery · libre $free"
    }

    private fun renderMotionCapabilities(value: RemoteCapabilities) {
        suppressMotionUi = true
        binding.remoteMotionSwitch.isChecked = value.motionEnabled
        binding.remoteMotionSensitivitySeek.progress = (value.motionSensitivity - 10).coerceIn(0, 85)
        binding.remoteMotionSensitivityLabel.text = "Sensibilité : ${value.motionSensitivity} %"
        binding.remoteMotionDurationButton.text = "Durée après mouvement : ${formatMotionDuration(value.motionDurationMs)}"
        suppressMotionUi = false
        AppPrefs.setRemoteMotionEnabled(this, value.motionEnabled)
        AppPrefs.setRemoteMotionSensitivity(this, value.motionSensitivity)
        AppPrefs.setRemoteMotionDurationMs(this, value.motionDurationMs)
    }

    private fun renderMotionPrefs() {
        suppressMotionUi = true
        val sensitivity = AppPrefs.remoteMotionSensitivity(this)
        binding.remoteMotionSwitch.isChecked = AppPrefs.remoteMotionEnabled(this)
        binding.remoteMotionSensitivitySeek.progress = (sensitivity - 10).coerceIn(0, 85)
        binding.remoteMotionSensitivityLabel.text = "Sensibilité : $sensitivity %"
        binding.remoteMotionDurationButton.text =
            "Durée après mouvement : ${formatMotionDuration(AppPrefs.remoteMotionDurationMs(this))}"
        suppressMotionUi = false
    }

    private fun captureSingleSupportPhoto() {
        val endpoint = activeEndpoint
        val code = activeCode
        if (endpoint == null || code.isBlank()) {
            binding.statusText.text = "Connecte d’abord Nova Support."
            return
        }
        if (captureJob?.isActive == true) return
        captureJob = lifecycleScope.launch {
            setCaptureBusy(true)
            val result = runCatching {
                if (AppPrefs.captureActionMode(this@RemoteCameraActivity) == AppPrefs.ACTION_MODE_DELAYED) {
                    runRemoteCountdown("Photo support")
                }
                captureAndTransferPhoto(endpoint.first, endpoint.second, code, UUID.randomUUID().toString())
            }
            result.onSuccess { created ->
                binding.statusText.text = "Photo haute qualité enregistrée : ${created.displayName}"
            }.onFailure { error ->
                binding.statusText.text = "Capture distante impossible : ${error.message}"
            }
            setCaptureBusy(false)
        }
    }

    private fun captureSupportBurst() {
        val endpoint = activeEndpoint
        val code = activeCode
        if (endpoint == null || code.isBlank()) {
            binding.statusText.text = "Connecte d’abord Nova Support."
            return
        }
        if (captureJob?.isActive == true) return
        val count = AppPrefs.burstCount(this)
        val intervalMs = AppPrefs.burstIntervalMs(this)
        captureJob = lifecycleScope.launch {
            setCaptureBusy(true)
            val groupId = UUID.randomUUID().toString()
            var saved = 0
            var lastError: Throwable? = null
            repeat(count) { index ->
                binding.statusText.text = "Rafale haute qualité ${index + 1}/$count…"
                val started = SystemClock.elapsedRealtime()
                runCatching {
                    captureAndTransferPhoto(endpoint.first, endpoint.second, code, groupId)
                }.onSuccess { saved += 1 }.onFailure { lastError = it }
                if (index < count - 1) {
                    val elapsed = SystemClock.elapsedRealtime() - started
                    delay((intervalMs - elapsed).coerceAtLeast(0L))
                }
            }
            binding.statusText.text = when {
                saved == count -> "Rafale terminée · $saved photos haute qualité."
                saved > 0 -> "Rafale partielle · $saved/$count. ${lastError?.message.orEmpty()}"
                else -> "Rafale impossible : ${lastError?.message ?: "aucune photo reçue"}"
            }
            setCaptureBusy(false)
        }
    }

    private suspend fun captureAndTransferPhoto(
        host: String,
        port: Int,
        code: String,
        groupId: String
    ): MediaItem {
        val info = withContext(Dispatchers.IO) {
            parsePhotoInfo(
                sendCommand(
                    host,
                    port,
                    code,
                    RemoteCameraProtocol.COMMAND_PHOTO_CAPTURE,
                    requestPayload = byteArrayOf(remoteFlashMode().toByte()),
                    timeoutMs = 20_000
                )
            )
        }
        val directory = File(cacheDir, "remote_support_photo").apply { mkdirs() }
        val target = File(directory, "photo_${info.id}.jpg")
        target.delete()
        var offset = 0L
        try {
            target.outputStream().buffered().use { output ->
                while (offset < info.size) {
                    val chunk = withContext(Dispatchers.IO) {
                        requestPhotoChunk(host, port, code, info.id, offset)
                    }
                    require(chunk.isNotEmpty()) { "Photo interrompue à $offset octets" }
                    output.write(chunk)
                    offset += chunk.size
                    val progress = ((offset * 100L) / info.size.coerceAtLeast(1L)).toInt()
                    binding.statusText.text = "Transfert photo Nova Support · $progress %"
                }
            }
            require(target.length() == info.size) { "Taille de photo incorrecte" }
            val created = withContext(Dispatchers.IO) {
                vault.addPlainMedia(
                    plainFile = target,
                    kind = MEDIA_PHOTO,
                    camera = AppPrefs.MODE_SUPPORT,
                    groupId = groupId,
                    folderId = FOLDER_IMAGES,
                    source = MEDIA_SOURCE_CAPTURED,
                    preferredDisplayName = info.displayName,
                    preferredMimeType = "image/jpeg"
                )
            }
            withContext(Dispatchers.IO) { deleteRemotePhoto(host, port, code, info.id) }
            return created
        } catch (error: Throwable) {
            target.delete()
            throw error
        }
    }

    private fun parsePhotoInfo(payload: ByteArray): RemotePhotoInfo {
        val input = DataInputStream(ByteArrayInputStream(payload))
        return RemotePhotoInfo(
            id = input.readLong(),
            size = input.readLong(),
            displayName = input.readUTF(),
            lens = input.readUTF()
        )
    }

    private fun requestPhotoChunk(
        host: String,
        port: Int,
        code: String,
        id: Long,
        offset: Long
    ): ByteArray {
        val request = ByteArrayOutputStream().use { bytes ->
            DataOutputStream(bytes).use { output ->
                output.writeLong(id)
                output.writeLong(offset)
                output.writeInt(RemoteCameraProtocol.PHOTO_CHUNK_BYTES)
            }
            bytes.toByteArray()
        }
        val response = sendCommand(
            host,
            port,
            code,
            RemoteCameraProtocol.COMMAND_PHOTO_CHUNK,
            request,
            timeoutMs = 12_000
        )
        val input = DataInputStream(ByteArrayInputStream(response))
        require(input.readLong() == id) { "Photo distante inattendue" }
        require(input.readLong() == offset) { "Décalage photo inattendu" }
        val length = input.readInt()
        require(length in 0..RemoteCameraProtocol.PHOTO_CHUNK_BYTES) { "Bloc photo invalide" }
        return ByteArray(length).also(input::readFully)
    }

    private fun deleteRemotePhoto(host: String, port: Int, code: String, id: Long) {
        val payload = ByteArrayOutputStream().use { bytes ->
            DataOutputStream(bytes).use { it.writeLong(id) }
            bytes.toByteArray()
        }
        sendCommand(host, port, code, RemoteCameraProtocol.COMMAND_PHOTO_DELETE, payload)
    }

    private fun toggleRemoteVideo() {
        val endpoint = activeEndpoint
        val code = activeCode
        if (endpoint == null || code.isBlank()) {
            binding.statusText.text = "Connecte d’abord Nova Support."
            return
        }
        if (controlJob?.isActive == true) return
        controlJob = lifecycleScope.launch {
            binding.remoteVideoButton.isEnabled = false
            val command = if (remoteVideoStatus.requested || remoteVideoStatus.active) {
                RemoteCameraProtocol.COMMAND_VIDEO_STOP
            } else {
                RemoteCameraProtocol.COMMAND_VIDEO_START
            }
            val payload = if (command == RemoteCameraProtocol.COMMAND_VIDEO_START) {
                buildVideoStartPayload()
            } else {
                ByteArray(0)
            }
            runCatching {
                if (command == RemoteCameraProtocol.COMMAND_VIDEO_START &&
                    AppPrefs.captureActionMode(this@RemoteCameraActivity) == AppPrefs.ACTION_MODE_DELAYED
                ) {
                    runRemoteCountdown("Vidéo support")
                }
                withContext(Dispatchers.IO) {
                    parseVideoStatus(sendCommand(endpoint.first, endpoint.second, code, command, payload))
                }
            }.onSuccess {
                remoteVideoStatus = it
                renderRemoteVideoStatus()
                binding.statusText.text = if (command == RemoteCameraProtocol.COMMAND_VIDEO_START) {
                    "Vidéo démarrée sur Nova Support. Tu peux quitter ce réseau : l’enregistrement continue localement."
                } else {
                    "Arrêt demandé · finalisation du dernier segment…"
                }
            }.onFailure { error ->
                binding.statusText.text = "Commande vidéo impossible : ${error.message}"
            }
            binding.remoteVideoButton.isEnabled = true
        }
    }

    private fun buildVideoStartPayload(): ByteArray = ByteArrayOutputStream().use { bytes ->
        DataOutputStream(bytes).use { output ->
            val quality = when (AppPrefs.quality(this)) {
                AppPrefs.QUALITY_HD, AppPrefs.QUALITY_SD -> RemoteCameraProtocol.QUALITY_HD
                else -> RemoteCameraProtocol.QUALITY_FHD
            }
            output.writeByte(quality)
            output.writeBoolean(AppPrefs.audioEnabled(this))
            output.writeLong(AppPrefs.videoSegmentDurationMs(this))
            output.writeBoolean(AppPrefs.videoTorchEnabled(this))
        }
        bytes.toByteArray()
    }



    private suspend fun runRemoteCountdown(label: String) {
        var remaining = AppPrefs.captureDelayMs(this)
        while (remaining > 0L) {
            val seconds = ((remaining + 999L) / 1_000L).coerceAtLeast(1L)
            binding.statusText.text = "$label dans ${if (seconds >= 60L) "1 min" else "$seconds s"}…"
            val step = min(1_000L, remaining)
            delay(step)
            remaining -= step
        }
    }

    private fun remoteFlashMode(): Int = when (AppPrefs.flashMode(this)) {
        AppPrefs.FLASH_AUTO -> RemoteCameraProtocol.FLASH_AUTO
        AppPrefs.FLASH_ON -> RemoteCameraProtocol.FLASH_ON
        else -> RemoteCameraProtocol.FLASH_OFF
    }

    private fun parseVideoStatus(payload: ByteArray): RemoteVideoStatus {
        val input = DataInputStream(ByteArrayInputStream(payload))
        return RemoteVideoStatus(
            requested = input.readBoolean(),
            active = input.readBoolean(),
            segmentIndex = input.readInt(),
            durationMs = input.readLong(),
            pendingSegments = input.readInt(),
            message = input.readUTF()
        )
    }

    private fun renderRemoteVideoStatus() {
        val status = remoteVideoStatus
        binding.remoteVideoButton.text = if (status.requested || status.active) {
            "Arrêter la vidéo support"
        } else {
            "Démarrer la vidéo support"
        }
        binding.remoteVideoStatusText.text = when {
            status.active -> "ENREGISTREMENT · segment ${status.segmentIndex} · ${formatDuration(status.durationMs)}${if (status.pendingSegments > 0) " · ${status.pendingSegments} à transférer" else ""}"
            status.requested -> "Démarrage ou finalisation en cours…"
            status.pendingSegments > 0 -> "${status.pendingSegments} segment(s) en attente de transfert"
            status.message.isNotBlank() -> status.message
            else -> "Vidéo distante arrêtée"
        }
    }

    private fun requestRemoteLens(lens: Int) {
        val endpoint = activeEndpoint ?: return
        val code = activeCode.takeIf { it.isNotBlank() } ?: return
        if (controlJob?.isActive == true) return
        controlJob = lifecycleScope.launch {
            setRemoteControlsEnabled(false)
            val label = if (lens == RemoteCameraProtocol.LENS_FRONT) "avant" else "arrière"
            binding.statusText.text = "Passage à la caméra $label…"
            runCatching {
                withContext(Dispatchers.IO) {
                    sendCommand(
                        endpoint.first,
                        endpoint.second,
                        code,
                        RemoteCameraProtocol.COMMAND_CAMERA_SET,
                        byteArrayOf(lens.toByte()),
                        timeoutMs = 8_000
                    )
                }
            }.onSuccess {
                latestFrameBytes = null
                delay(900L)
                refreshRemoteCapabilities(endpoint.first, endpoint.second, code)
                binding.statusText.text = "Caméra $label sélectionnée · reconnexion automatique de l’aperçu."
            }.onFailure { error ->
                binding.statusText.text = "Changement de caméra impossible : ${error.message}"
            }
            setRemoteControlsEnabled(true)
        }
    }

    private fun restartRemoteNetwork() {
        val endpoint = activeEndpoint ?: return
        val code = activeCode.takeIf { it.isNotBlank() } ?: return
        if (controlJob?.isActive == true) return
        controlJob = lifecycleScope.launch {
            binding.statusText.text = "Relance de la liaison distante…"
            runCatching {
                withContext(Dispatchers.IO) {
                    sendCommand(endpoint.first, endpoint.second, code, RemoteCameraProtocol.COMMAND_NETWORK_RESTART)
                }
            }.onSuccess {
                delay(900L)
                startConnectionLoops(endpoint.first, endpoint.second, code)
            }.onFailure { error ->
                binding.statusText.text = "Relance impossible : ${error.message}"
            }
        }
    }

    private fun confirmStopRemoteServices() {
        if (activeEndpoint == null || activeCode.isBlank()) return
        AlertDialog.Builder(this)
            .setTitle("Arrêter Nova Support ?")
            .setMessage("La caméra, la vidéo, le serveur local et le réseau direct seront arrêtés sur le téléphone-support.")
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Tout arrêter") { _, _ -> stopRemoteServices() }
            .show()
    }

    private fun stopRemoteServices() {
        val endpoint = activeEndpoint ?: return
        val code = activeCode.takeIf { it.isNotBlank() } ?: return
        controlJob = lifecycleScope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    sendCommand(endpoint.first, endpoint.second, code, RemoteCameraProtocol.COMMAND_SERVICE_STOP)
                }
            }
            delay(350L)
            disconnect("Services Nova Support arrêtés à distance")
        }
    }

    private fun chooseMotionDuration() {
        val values = longArrayOf(10_000L, 20_000L, 30_000L, 60_000L, 120_000L, 300_000L)
        val labels = arrayOf("10 secondes", "20 secondes", "30 secondes", "1 minute", "2 minutes", "5 minutes")
        val current = AppPrefs.remoteMotionDurationMs(this)
        val selected = values.indexOfFirst { it == current }.coerceAtLeast(2)
        AlertDialog.Builder(this)
            .setTitle("Durée après le dernier mouvement")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                sendMotionConfig(durationMs = values[which])
                dialog.dismiss()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun sendMotionConfig(
        enabled: Boolean = binding.remoteMotionSwitch.isChecked,
        sensitivity: Int = binding.remoteMotionSensitivitySeek.progress + 10,
        durationMs: Long = AppPrefs.remoteMotionDurationMs(this)
    ) {
        if (suppressMotionUi) return
        val endpoint = activeEndpoint
        val code = activeCode
        if (endpoint == null || code.isBlank()) {
            AppPrefs.setRemoteMotionEnabled(this, enabled)
            AppPrefs.setRemoteMotionSensitivity(this, sensitivity)
            AppPrefs.setRemoteMotionDurationMs(this, durationMs)
            renderMotionPrefs()
            binding.statusText.text = "Connecte Nova Support pour appliquer la détection."
            return
        }
        controlJob?.cancel()
        controlJob = lifecycleScope.launch {
            val payload = ByteArrayOutputStream().use { bytes ->
                DataOutputStream(bytes).use { output ->
                    output.writeBoolean(enabled)
                    output.writeInt(sensitivity)
                    output.writeLong(durationMs)
                }
                bytes.toByteArray()
            }
            runCatching {
                withContext(Dispatchers.IO) {
                    sendCommand(endpoint.first, endpoint.second, code, RemoteCameraProtocol.COMMAND_MOTION_CONFIG, payload)
                }
            }.onSuccess {
                AppPrefs.setRemoteMotionEnabled(this@RemoteCameraActivity, enabled)
                AppPrefs.setRemoteMotionSensitivity(this@RemoteCameraActivity, sensitivity)
                AppPrefs.setRemoteMotionDurationMs(this@RemoteCameraActivity, durationMs)
                binding.statusText.text = if (enabled) {
                    "Détection active · sans pré-enregistrement · vidéo ${formatMotionDuration(durationMs)} après mouvement."
                } else {
                    "Détection de mouvement désactivée."
                }
                refreshRemoteCapabilities(endpoint.first, endpoint.second, code)
            }.onFailure { error ->
                binding.statusText.text = "Réglage du mouvement impossible : ${error.message}"
            }
        }
    }

    private suspend fun transferAvailableSegments(host: String, port: Int, code: String) {
        while (true) {
            val info = runCatching {
                withContext(Dispatchers.IO) {
                    parseSegmentInfo(sendCommand(host, port, code, RemoteCameraProtocol.COMMAND_SEGMENT_INFO))
                }
            }.getOrElse {
                binding.statusText.text = "Transfert vidéo en attente : ${it.message}"
                return
            } ?: return

            val pendingDir = File(cacheDir, "remote_support_video").apply { mkdirs() }
            val target = File(pendingDir, "segment_${info.id}.mp4")
            target.delete()
            var offset = 0L
            runCatching {
                target.outputStream().buffered().use { output ->
                    while (offset < info.size) {
                        val chunk = withContext(Dispatchers.IO) {
                            requestSegmentChunk(host, port, code, info.id, offset)
                        }
                        require(chunk.isNotEmpty()) { "Segment interrompu à $offset octets" }
                        output.write(chunk)
                        offset += chunk.size
                        val progress = ((offset * 100L) / info.size.coerceAtLeast(1L)).toInt()
                        binding.statusText.text = "Transfert vidéo Nova Support · $progress %"
                    }
                }
                require(target.length() == info.size) { "Taille de segment incorrecte" }
                val created = withContext(Dispatchers.IO) {
                    vault.addPlainMedia(
                        plainFile = target,
                        kind = MEDIA_VIDEO,
                        camera = AppPrefs.MODE_SUPPORT,
                        groupId = UUID.randomUUID().toString(),
                        folderId = FOLDER_VIDEOS,
                        source = MEDIA_SOURCE_CAPTURED,
                        preferredDisplayName = info.displayName,
                        preferredMimeType = "video/mp4"
                    )
                }
                withContext(Dispatchers.IO) { deleteRemoteSegment(host, port, code, info.id) }
                binding.statusText.text = "Vidéo support enregistrée dans le coffre : ${created.displayName}"
            }.onFailure { error ->
                target.delete()
                binding.statusText.text = "Échec du transfert vidéo : ${error.message}"
                return
            }
        }
    }

    private fun parseSegmentInfo(payload: ByteArray): RemoteSegmentInfo? {
        val input = DataInputStream(ByteArrayInputStream(payload))
        if (!input.readBoolean()) return null
        return RemoteSegmentInfo(
            id = input.readLong(),
            size = input.readLong(),
            durationMs = input.readLong(),
            displayName = input.readUTF()
        )
    }

    private fun requestSegmentChunk(
        host: String,
        port: Int,
        code: String,
        id: Long,
        offset: Long
    ): ByteArray {
        val request = ByteArrayOutputStream().use { bytes ->
            DataOutputStream(bytes).use { output ->
                output.writeLong(id)
                output.writeLong(offset)
                output.writeInt(RemoteCameraProtocol.VIDEO_CHUNK_BYTES)
            }
            bytes.toByteArray()
        }
        val response = sendCommand(
            host,
            port,
            code,
            RemoteCameraProtocol.COMMAND_SEGMENT_CHUNK,
            request,
            timeoutMs = 12_000
        )
        val input = DataInputStream(ByteArrayInputStream(response))
        require(input.readLong() == id) { "Segment distant inattendu" }
        require(input.readLong() == offset) { "Décalage distant inattendu" }
        val length = input.readInt()
        require(length in 0..RemoteCameraProtocol.VIDEO_CHUNK_BYTES) { "Bloc distant invalide" }
        return ByteArray(length).also(input::readFully)
    }

    private fun deleteRemoteSegment(host: String, port: Int, code: String, id: Long) {
        val payload = ByteArrayOutputStream().use { bytes ->
            DataOutputStream(bytes).use { it.writeLong(id) }
            bytes.toByteArray()
        }
        sendCommand(host, port, code, RemoteCameraProtocol.COMMAND_SEGMENT_DELETE, payload)
    }

    private fun setCaptureBusy(busy: Boolean) {
        binding.remoteCaptureButton.isEnabled = !busy && activeEndpoint != null
        binding.remoteBurstButton.isEnabled = !busy && activeEndpoint != null
        binding.connectButton.isEnabled = !busy
        binding.disconnectButton.isEnabled = !busy
    }

    private fun setRemoteControlsEnabled(enabled: Boolean) {
        binding.remoteBackLensButton.isEnabled = enabled && remoteCapabilities?.hasBack == true
        binding.remoteFrontLensButton.isEnabled = enabled && remoteCapabilities?.hasFront == true
        binding.restartRemoteNetworkButton.isEnabled = enabled && activeEndpoint != null
        binding.stopRemoteServicesButton.isEnabled = enabled && activeEndpoint != null
    }

    private fun updateCaptureButtons() {
        val connected = activeEndpoint != null
        binding.remoteCaptureButton.isEnabled = connected && captureJob?.isActive != true
        binding.remoteBurstButton.isEnabled = connected && captureJob?.isActive != true
        binding.remoteVideoButton.isEnabled = connected && controlJob?.isActive != true
        binding.restartRemoteNetworkButton.isEnabled = connected && controlJob?.isActive != true
        binding.stopRemoteServicesButton.isEnabled = connected && controlJob?.isActive != true
        binding.remoteMotionSwitch.isEnabled = connected
        binding.remoteMotionSensitivitySeek.isEnabled = connected
        binding.remoteMotionDurationButton.isEnabled = connected
    }

    private fun sendCommand(
        host: String,
        port: Int,
        code: String,
        command: Int,
        requestPayload: ByteArray = ByteArray(0),
        timeoutMs: Int = 4_000
    ): ByteArray {
        require(requestPayload.size <= RemoteCameraProtocol.MAX_REQUEST_BYTES) { "Commande trop volumineuse" }
        val nonce = RemoteCameraCrypto.newRequestNonce()
        val auth = RemoteCameraCrypto.authTag(code, nonce, command, requestPayload)
        Socket().use { socket ->
            socket.connect(InetSocketAddress(host, port), timeoutMs)
            socket.soTimeout = timeoutMs
            val output = DataOutputStream(socket.getOutputStream())
            output.writeInt(RemoteCameraProtocol.MAGIC)
            output.writeByte(RemoteCameraProtocol.VERSION)
            output.writeByte(command)
            output.writeByte(nonce.size)
            output.write(nonce)
            output.writeInt(requestPayload.size)
            output.write(requestPayload)
            output.writeByte(auth.size)
            output.write(auth)
            output.flush()

            val input = DataInputStream(socket.getInputStream())
            require(input.readInt() == RemoteCameraProtocol.MAGIC) { "réponse distante invalide" }
            require(input.readUnsignedByte() == RemoteCameraProtocol.VERSION) { "version distante incompatible" }
            val status = input.readUnsignedByte()
            val length = input.readInt()
            require(length in 0..RemoteCameraProtocol.MAX_PAYLOAD_BYTES) { "réponse trop volumineuse" }
            val payload = ByteArray(length).also(input::readFully)
            return when (status) {
                RemoteCameraProtocol.STATUS_OK -> RemoteCameraCrypto.decryptPayload(payload, code, nonce, command)
                RemoteCameraProtocol.STATUS_UNAUTHORIZED -> error("appairage refusé")
                RemoteCameraProtocol.STATUS_NOT_READY -> error(payload.toString(Charsets.UTF_8).ifBlank { "caméra ou fichier en préparation" })
                RemoteCameraProtocol.STATUS_FORBIDDEN -> error("réseau non autorisé")
                RemoteCameraProtocol.STATUS_BUSY -> error(payload.toString(Charsets.UTF_8).ifBlank { "Nova Support est occupée" })
                else -> error(payload.toString(Charsets.UTF_8).ifBlank { "requête refusée" })
            }
        }
    }

    private fun parseEndpoint(raw: String): Pair<String, Int>? {
        val cleaned = raw.trim()
            .removePrefix("http://")
            .removePrefix("https://")
            .substringBefore('/')
        if (cleaned.isBlank()) return null
        val host = cleaned.substringBeforeLast(':', cleaned).trim().removePrefix("[").removeSuffix("]")
        val port = if (cleaned.contains(':')) cleaned.substringAfterLast(':').toIntOrNull() else DEFAULT_PORT
        if (host.isBlank() || port == null || port !in 1..65535) return null
        if (!isPrivateIpv4(host)) return null
        return host to port
    }

    private fun isPrivateIpv4(host: String): Boolean {
        val parts = host.split('.').mapNotNull { it.toIntOrNull() }
        if (parts.size != 4 || parts.any { it !in 0..255 }) return false
        return when {
            parts[0] == 10 -> true
            parts[0] == 172 && parts[1] in 16..31 -> true
            parts[0] == 192 && parts[1] == 168 -> true
            else -> false
        }
    }

    private fun showSupportInstallQr() {
        val configuredBase = UpdatePrefs.baseUrl(this)
        val base = configuredBase.takeIf { it.startsWith("https://") }
            ?: "https://elxghost.github.io/nova-releases"
        val installUrl = "${base.trimEnd('/')}/support/"
        val content = layoutInflater.inflate(R.layout.dialog_install_support, null)
        content.findViewById<ImageView>(R.id.supportInstallQr)
            .setImageBitmap(createQrBitmap(installUrl, 760))
        content.findViewById<TextView>(R.id.supportInstallUrl).text = installUrl

        AlertDialog.Builder(this)
            .setView(content)
            .setNegativeButton("Fermer", null)
            .setNeutralButton("Partager le lien") { _, _ ->
                val share = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, installUrl)
                }
                startActivity(Intent.createChooser(share, "Partager Nova Support"))
            }
            .setPositiveButton("Ouvrir la page") { _, _ ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(installUrl)))
            }
            .show()
    }

    private fun createQrBitmap(content: String, size: Int): Bitmap {
        val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size)
        val pixels = IntArray(size * size)
        for (y in 0 until size) {
            for (x in 0 until size) {
                pixels[y * size + x] = if (matrix[x, y]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
            }
        }
        return Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).apply {
            setPixels(pixels, 0, size, 0, 0, size, size)
        }
    }

    private fun formatDuration(durationMs: Long): String {
        val total = durationMs / 1000L
        return String.format(Locale.FRANCE, "%02d:%02d", total / 60L, total % 60L)
    }

    private fun formatMotionDuration(durationMs: Long): String = when {
        durationMs >= 60_000L && durationMs % 60_000L == 0L -> "${durationMs / 60_000L} min"
        else -> "${durationMs / 1_000L} s"
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 0L) return "inconnu"
        val giga = bytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
        return String.format(Locale.FRANCE, "%.1f Go", giga)
    }

    private fun disconnect(message: String) {
        if (usingDirectNetwork || DirectNetworkConnector.isConnected()) {
            DirectNetworkConnector.disconnect()
        }
        usingDirectNetwork = false
        pendingDirectPairing = null
        pollingJob?.cancel()
        statusJob?.cancel()
        transferJob?.cancel()
        captureJob?.cancel()
        controlJob?.cancel()
        pollingJob = null
        statusJob = null
        transferJob = null
        captureJob = null
        controlJob = null
        activeEndpoint = null
        activeCode = ""
        latestFrameBytes = null
        connectionEstablished = false
        remoteCapabilities = null
        remoteVideoStatus = RemoteVideoStatus(false, false, 0, 0L, 0, "")
        binding.statusText.text = message
        binding.remoteImage.setImageDrawable(null)
        binding.remoteCapabilitiesText.text = "Capacités distantes non chargées"
        updateCaptureButtons()
        renderRemoteVideoStatus()
    }

    override fun onStop() {
        pollingJob?.cancel()
        statusJob?.cancel()
        transferJob?.cancel()
        captureJob?.cancel()
        controlJob?.cancel()
        pollingJob = null
        statusJob = null
        transferJob = null
        captureJob = null
        controlJob = null
        super.onStop()
    }

    companion object {
        private const val DEFAULT_PORT = 8787
        private const val PAIR_SCHEME = "nova-support"
        private const val PAIR_HOST = "pair"
    }
}
