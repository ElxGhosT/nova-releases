package fr.doudou.nova

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper

class NovaApplication : Application(), Application.ActivityLifecycleCallbacks {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var startedActivityCount = 0
    private var gateLaunchInProgress = false

    private val lockRunnable = Runnable {
        if (startedActivityCount == 0) {
            SecuritySession.lock()
            MediaVault(this).clearDecryptedCache()
        }
    }

    override fun onCreate() {
        super.onCreate()
        registerActivityLifecycleCallbacks(this)
        MediaVault(this).clearDecryptedCache()
        FileCleanup.clearPending(cacheDir)
        AppPrefs.setServiceActive(this, false)
        AppPrefs.setRecordingActive(this, false)
        CaptureStateStore.update(CaptureState.Idle)
        WidgetUpdater.updateAll(this)
    }

    override fun onActivityStarted(activity: Activity) {
        startedActivityCount += 1
        mainHandler.removeCallbacks(lockRunnable)
        enforceLockIfNeeded(activity)
    }

    override fun onActivityResumed(activity: Activity) {
        if (activity is GateActivity) {
            gateLaunchInProgress = false
        } else {
            enforceLockIfNeeded(activity)
        }
    }

    private fun enforceLockIfNeeded(activity: Activity) {
        if (activity is GateActivity || SecuritySession.isUnlocked() || gateLaunchInProgress) return
        gateLaunchInProgress = true
        val destination = when (activity) {
            is MediaVaultActivity, is MediaViewerActivity -> GateActivity.DESTINATION_MEDIA
            is SettingsActivity, is UpdatesActivity -> GateActivity.DESTINATION_SETTINGS
            is QuickCaptureActivity -> GateActivity.DESTINATION_QUICK
            is RemoteCameraActivity -> GateActivity.DESTINATION_REMOTE
            else -> null
        }
        mainHandler.post {
            if (activity.isFinishing || activity.isDestroyed) {
                gateLaunchInProgress = false
                return@post
            }
            activity.startActivity(Intent(activity, GateActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                destination?.let { putExtra(GateActivity.EXTRA_DESTINATION, it) }
            })
            activity.finish()
        }
    }

    override fun onActivityStopped(activity: Activity) {
        startedActivityCount = (startedActivityCount - 1).coerceAtLeast(0)
        if (startedActivityCount != 0 || activity.isChangingConfigurations) return

        val configuredDelay = AppPrefs.lockTimeoutMs(this)
        val delay = if (configuredDelay <= 1L) 500L else configuredDelay
        mainHandler.removeCallbacks(lockRunnable)
        mainHandler.postDelayed(lockRunnable, delay)
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit
    override fun onActivityPaused(activity: Activity) = Unit
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
    override fun onActivityDestroyed(activity: Activity) = Unit
}

private object FileCleanup {
    fun clearPending(cacheDir: java.io.File) {
        java.io.File(cacheDir, "nova_pending").listFiles()?.forEach { it.delete() }
    }
}
