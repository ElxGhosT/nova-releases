package fr.doudou.nova

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object SecurityStore {
    private const val FILE = "nova_security"
    private const val KEY_HASH = "pin_hash"
    private const val KEY_SALT = "pin_salt"
    private const val ITERATIONS = 120_000
    private const val KEY_LENGTH = 256

    private fun prefs(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun hasPin(context: Context): Boolean =
        prefs(context).contains(KEY_HASH) && prefs(context).contains(KEY_SALT)

    fun setPin(context: Context, pin: CharArray) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = derive(pin, salt)
        prefs(context).edit()
            .putString(KEY_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_HASH, Base64.encodeToString(hash, Base64.NO_WRAP))
            .apply()
        pin.fill('\u0000')
    }

    fun verifyPin(context: Context, pin: CharArray): Boolean {
        val saltEncoded = prefs(context).getString(KEY_SALT, null) ?: return false
        val hashEncoded = prefs(context).getString(KEY_HASH, null) ?: return false
        val salt = Base64.decode(saltEncoded, Base64.NO_WRAP)
        val expected = Base64.decode(hashEncoded, Base64.NO_WRAP)
        val actual = derive(pin, salt)
        pin.fill('\u0000')
        return MessageDigest.isEqual(expected, actual)
    }

    private fun derive(pin: CharArray, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin, salt, ITERATIONS, KEY_LENGTH)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(spec)
                .encoded
        } finally {
            spec.clearPassword()
        }
    }
}

object SecuritySession {
    @Volatile private var unlocked = false

    /**
     * La durée de session est pilotée par NovaApplication quand l'application
     * passe réellement en arrière-plan. Une navigation interne (Capture ->
     * Réglages -> Capture) ne doit jamais invalider la session.
     */
    fun unlock(context: Context) {
        unlocked = true
    }

    fun isUnlocked(): Boolean = unlocked

    fun lock() {
        unlocked = false
    }
}
