package fr.doudou.nova

import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.media3.common.MediaItem as PlayerMediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.AspectRatioFrameLayout
import fr.doudou.nova.databinding.ActivityMediaViewerBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min

@UnstableApi
class MediaViewerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMediaViewerBinding
    private lateinit var vault: MediaVault
    private lateinit var gestureDetector: GestureDetector
    private lateinit var thumbnailAdapter: ViewerThumbnailAdapter
    private val playbackPrefs by lazy { getSharedPreferences("nova_media_viewer", MODE_PRIVATE) }

    private var item: MediaItem? = null
    private var player: ExoPlayer? = null
    private var decodedBitmap: Bitmap? = null
    private var currentFolderItems: List<MediaItem> = emptyList()
    private var currentIndex: Int = -1
    private var controlsVisible = true
    private var fillMode = false
    private var playbackSpeed = 1f
    private var mediaRotationDegrees = 0f
    private var orientationLocked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!SecuritySession.isUnlocked()) {
            startActivity(Intent(this, GateActivity::class.java).apply {
                putExtra(GateActivity.EXTRA_DESTINATION, GateActivity.DESTINATION_MEDIA)
            })
            finish()
            return
        }
        SecuritySession.unlock(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        binding = ActivityMediaViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        vault = MediaVault(this)
        gestureDetector = createGestureDetector()
        thumbnailAdapter = ViewerThumbnailAdapter(vault) { selected ->
            if (selected.id != item?.id) {
                savePlaybackPosition()
                refreshSequence(selected.id)
                intent.putExtra(EXTRA_MEDIA_ID, selected.id)
                mediaRotationDegrees = 0f
                applyMediaRotation()
                loadCurrent()
            }
        }
        binding.viewerThumbnailRecycler.layoutManager = LinearLayoutManager(
            this,
            LinearLayoutManager.HORIZONTAL,
            false
        )
        binding.viewerThumbnailRecycler.adapter = thumbnailAdapter
        binding.viewerPlayer.controllerShowTimeoutMs = 2500

        val restoredId = savedInstanceState?.getString(STATE_MEDIA_ID)
        val id = restoredId ?: intent.getStringExtra(EXTRA_MEDIA_ID)
        if (id.isNullOrBlank() || !refreshSequence(id)) {
            finish()
            return
        }

        playbackSpeed = savedInstanceState?.getFloat(STATE_PLAYBACK_SPEED, 1f) ?: 1f
        fillMode = savedInstanceState?.getBoolean(STATE_FILL_MODE, false) ?: false
        controlsVisible = savedInstanceState?.getBoolean(STATE_CONTROLS_VISIBLE, true) ?: true
        mediaRotationDegrees = savedInstanceState?.getFloat(STATE_MEDIA_ROTATION, 0f) ?: 0f
        orientationLocked = savedInstanceState?.getBoolean(STATE_ORIENTATION_LOCKED, false) ?: false
        if (orientationLocked) requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LOCKED

        setupButtons()
        applyFillMode()
        applyMediaRotation()
        updateOrientationLockButton()
        applyChromeVisibility()
        loadCurrent()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (::gestureDetector.isInitialized && ev.pointerCount == 1 && isPointInMediaArea(ev)) {
            gestureDetector.onTouchEvent(ev)
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun setupButtons() {
        binding.viewerBackButton.setOnClickListener { finish() }
        binding.viewerExportButton.setOnClickListener { toggleVisibility() }
        binding.viewerDeleteButton.setOnClickListener { confirmDelete() }
        binding.viewerPrevButton.setOnClickListener { showPrevious() }
        binding.viewerNextButton.setOnClickListener { showNext() }
        binding.viewerCaptureFrameButton.setOnClickListener { captureFrameFromVideo() }
        binding.viewerSpeedButton.setOnClickListener { chooseSpeed() }
        binding.viewerFitButton.setOnClickListener {
            fillMode = !fillMode
            applyFillMode()
        }
        binding.viewerRotateButton.setOnClickListener { rotateMedia() }
        binding.viewerOrientationLockButton.setOnClickListener { toggleOrientationLock() }
        binding.viewerProtectButton.setOnClickListener { toggleProtection() }
    }

    private fun createGestureDetector(): GestureDetector {
        return GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                toggleChrome()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val current = item ?: return false
                if (current.kind == MEDIA_VIDEO) {
                    val frameWidth = binding.viewerMediaFrame.width.toFloat().coerceAtLeast(1f)
                    when {
                        e.x < frameWidth * 0.33f -> seekBy(-5_000L)
                        e.x > frameWidth * 0.66f -> seekBy(5_000L)
                        else -> binding.viewerVideoZoomLayout.toggleDoubleTapZoom()
                    }
                } else {
                    binding.viewerImageZoomLayout.toggleDoubleTapZoom()
                }
                return true
            }

            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float
            ): Boolean {
                if (currentZoomScale() > 1.05f) return false
                val start = e1 ?: return false
                val dx = e2.x - start.x
                val dy = e2.y - start.y
                if (abs(dx) < 120f || abs(dx) < abs(dy) || abs(velocityX) < 300f) return false
                if (dx > 0) showPrevious() else showNext()
                return true
            }
        })
    }

    private fun isPointInMediaArea(ev: MotionEvent): Boolean {
        val top = binding.viewerMediaFrame.top.toFloat()
        val bottom = binding.viewerMediaFrame.bottom.toFloat()
        return ev.y in top..bottom
    }

    private fun currentZoomScale(): Float {
        val current = item ?: return 1f
        return if (current.kind == MEDIA_VIDEO) {
            binding.viewerVideoZoomLayout.currentScale()
        } else {
            binding.viewerImageZoomLayout.currentScale()
        }
    }

    private fun loadCurrent() {
        val current = item ?: return
        player?.release()
        player = null
        binding.viewerPlayer.player = null
        decodedBitmap?.recycle()
        decodedBitmap = null
        binding.viewerImageZoomLayout.resetZoom()
        binding.viewerVideoZoomLayout.resetZoom()
        applyMediaRotation()
        binding.viewerProgress.visibility = View.VISIBLE
        binding.viewerInfo.text = buildInfo(current)
        updateVisibilityButton(current)
        updateProtectionButton(current)
        updateSequenceUi()
        updateVideoButtons(current)

        if (current.kind == MEDIA_VIDEO && vault.isStreamableVideo(current)) {
            binding.viewerProgress.visibility = View.GONE
            binding.viewerImageZoomLayout.visibility = View.GONE
            binding.viewerVideoZoomLayout.visibility = View.VISIBLE
            startEncryptedPlayer(current)
            prefetchNeighbours()
            return
        }

        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val file = vault.decryptToCache(current)
                    val bitmap = if (current.kind == MEDIA_PHOTO) decodeForScreen(file) else null
                    file to bitmap
                }
            }
            result.onSuccess { (file, bitmap) ->
                binding.viewerProgress.visibility = View.GONE
                if (current.kind == MEDIA_PHOTO) {
                    binding.viewerVideoZoomLayout.visibility = View.GONE
                    binding.viewerImageZoomLayout.visibility = View.VISIBLE
                    decodedBitmap = bitmap
                    binding.viewerImage.setImageBitmap(bitmap)
                } else {
                    binding.viewerImageZoomLayout.visibility = View.GONE
                    binding.viewerVideoZoomLayout.visibility = View.VISIBLE
                    startLegacyPlayer(file)
                    lifecycleScope.launch(Dispatchers.IO) {
                        vault.upgradeLegacyVideo(current, file)
                    }
                }
                prefetchNeighbours()
            }.onFailure { error ->
                binding.viewerProgress.visibility = View.GONE
                binding.viewerInfo.text = "Erreur de lecture : ${error.message}"
            }
        }
    }

    private fun startEncryptedPlayer(current: MediaItem) {
        val encryptedFile = File(current.encryptedPath)
        val sourceFactory = NovaChunkedDataSource.Factory(encryptedFile)
        val mediaSource = ProgressiveMediaSource.Factory(sourceFactory)
            .createMediaSource(PlayerMediaItem.fromUri(Uri.parse("nova://vault/${current.id}.mp4")))
        val exoPlayer = newPlayer()
        exoPlayer.setMediaSource(mediaSource)
        exoPlayer.setPlaybackParameters(PlaybackParameters(playbackSpeed))
        exoPlayer.seekTo(loadPlaybackPosition(current.id))
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
        player = exoPlayer
        binding.viewerPlayer.player = exoPlayer
    }

    private fun startLegacyPlayer(file: File) {
        val current = item ?: return
        val exoPlayer = newPlayer()
        exoPlayer.setMediaItem(PlayerMediaItem.fromUri(Uri.fromFile(file)))
        exoPlayer.setPlaybackParameters(PlaybackParameters(playbackSpeed))
        exoPlayer.seekTo(loadPlaybackPosition(current.id))
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
        player = exoPlayer
        binding.viewerPlayer.player = exoPlayer
    }

    private fun newPlayer(): ExoPlayer = ExoPlayer.Builder(this).build().also { created ->
        created.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                binding.viewerProgress.visibility = View.GONE
                binding.viewerInfo.text = "Vidéo illisible : ${error.errorCodeName}"
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                binding.viewerProgress.visibility = if (playbackState == Player.STATE_BUFFERING) {
                    View.VISIBLE
                } else {
                    View.GONE
                }
                val current = item
                if (playbackState == Player.STATE_ENDED && current != null) {
                    savePlaybackPosition(current.id, 0L)
                }
            }
        })
    }

    private fun decodeForScreen(file: File): Bitmap {
        val target = (resources.displayMetrics.widthPixels.coerceAtLeast(
            resources.displayMetrics.heightPixels
        ) * 2).coerceAtLeast(1600)
        return ImageDecoder.decodeBitmap(ImageDecoder.createSource(file)) { decoder, info, _ ->
            val width = info.size.width.coerceAtLeast(1)
            val height = info.size.height.coerceAtLeast(1)
            val largest = maxOf(width, height)
            if (largest > target) {
                val ratio = target.toDouble() / largest.toDouble()
                decoder.setTargetSize(
                    (width * ratio).toInt().coerceAtLeast(1),
                    (height * ratio).toInt().coerceAtLeast(1)
                )
            }
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    }

    private fun toggleVisibility() {
        val current = item ?: return
        binding.viewerExportButton.isEnabled = false
        lifecycleScope.launch {
            if (current.exportedUri == null) {
                runCatching {
                    withContext(Dispatchers.IO) { vault.exportToGallery(current) }
                }.onSuccess {
                    refreshSequence(current.id)
                    item?.let {
                        binding.viewerInfo.text = buildInfo(it) + "\nCopie rendue visible dans la galerie."
                    }
                }.onFailure { error ->
                    binding.viewerInfo.text = "Export impossible : ${error.message}"
                }
            } else {
                runCatching {
                    withContext(Dispatchers.IO) { vault.hideFromGallery(current) }
                }.onSuccess {
                    refreshSequence(current.id)
                    item?.let {
                        binding.viewerInfo.text = buildInfo(it) + "\nCopie publique retirée de la galerie."
                    }
                }.onFailure { error ->
                    binding.viewerInfo.text = "Masquage impossible : ${error.message}"
                }
            }
            item?.let(::updateVisibilityButton)
            binding.viewerExportButton.isEnabled = true
        }
    }

    private fun captureFrameFromVideo() {
        val current = item ?: return
        if (current.kind != MEDIA_VIDEO) return
        val wasPlaying = player?.isPlaying == true
        val currentPosition = player?.currentPosition ?: 0L
        player?.pause()
        binding.viewerCaptureFrameButton.isEnabled = false
        binding.viewerProgress.visibility = View.VISIBLE
        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val sourceFile = vault.decryptToCache(current)
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(sourceFile.absolutePath)
                        val bitmap = retriever.getFrameAtTime(
                            currentPosition * 1000L,
                            MediaMetadataRetriever.OPTION_CLOSEST
                        ) ?: error("Image introuvable à cette position.")
                        val outFile = File(cacheDir, "frame_${current.id}_${System.currentTimeMillis()}.jpg")
                        outFile.outputStream().use { output ->
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, output)
                        }
                        bitmap.recycle()
                        vault.addPlainMedia(
                            plainFile = outFile,
                            kind = MEDIA_PHOTO,
                            camera = current.camera,
                            groupId = current.groupId,
                            folderId = current.folderId,
                            source = MEDIA_SOURCE_CAPTURED,
                            preferredDisplayName = buildFrameCaptureName(currentPosition)
                        )
                    } finally {
                        runCatching { retriever.release() }
                    }
                }
            }
            binding.viewerProgress.visibility = View.GONE
            binding.viewerCaptureFrameButton.isEnabled = true
            result.onSuccess { created ->
                refreshSequence(current.id)
                updateSequenceUi()
                binding.viewerInfo.text = "Capture enregistrée : ${created.displayName}"
            }.onFailure { error ->
                binding.viewerInfo.text = "Capture impossible : ${error.message}"
            }
            if (wasPlaying) player?.play()
        }
    }

    private fun buildFrameCaptureName(positionMs: Long): String {
        val timestamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.FRANCE)
            .format(Date())
        val totalSeconds = positionMs / 1000L
        val minutes = totalSeconds / 60L
        val seconds = totalSeconds % 60L
        return String.format(Locale.FRANCE, "Capture_video_%s_%02dm%02ds.jpg", timestamp, minutes, seconds)
    }

    private fun chooseSpeed() {
        val speeds = floatArrayOf(0.5f, 1f, 1.5f, 2f)
        val labels = arrayOf("0,5×", "1×", "1,5×", "2×")
        val selected = speeds.indexOfFirst { it == playbackSpeed }.coerceAtLeast(1)
        AlertDialog.Builder(this)
            .setTitle("Vitesse de lecture")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                playbackSpeed = speeds[which]
                player?.setPlaybackParameters(PlaybackParameters(playbackSpeed))
                updateSpeedButton()
                dialog.dismiss()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun toggleProtection() {
        val current = item ?: return
        val enable = !current.protectedFromDeletion
        lifecycleScope.launch {
            val updated = withContext(Dispatchers.IO) {
                vault.updateProtection(current.id, enable)
            }
            if (updated != null) {
                refreshSequence(updated.id)
                item?.let {
                    updateProtectionButton(it)
                    updateSequenceUi()
                    binding.viewerInfo.text = buildInfo(it) + if (enable) {
                        "\nMédia protégé contre la suppression."
                    } else {
                        "\nProtection contre la suppression retirée."
                    }
                }
            }
        }
    }

    private fun updateVisibilityButton(current: MediaItem) {
        binding.viewerExportButton.text = if (current.exportedUri == null) {
            "Rendre visible"
        } else {
            "Rendre privé"
        }
    }

    private fun updateProtectionButton(current: MediaItem) {
        binding.viewerProtectButton.text = if (current.protectedFromDeletion) {
            "Déverrouiller"
        } else {
            "Protéger"
        }
        binding.viewerDeleteButton.isEnabled = !current.protectedFromDeletion
        binding.viewerDeleteButton.alpha = if (current.protectedFromDeletion) 0.5f else 1f
    }

    private fun updateVideoButtons(current: MediaItem) {
        val visible = if (current.kind == MEDIA_VIDEO) View.VISIBLE else View.GONE
        binding.viewerCaptureFrameButton.visibility = visible
        binding.viewerSpeedButton.visibility = visible
        updateSpeedButton()
    }

    private fun updateSpeedButton() {
        binding.viewerSpeedButton.text = when (playbackSpeed) {
            0.5f -> "Vitesse 0,5×"
            1.5f -> "Vitesse 1,5×"
            2f -> "Vitesse 2×"
            else -> "Vitesse 1×"
        }
    }

    private fun updateSequenceUi() {
        val total = currentFolderItems.size.coerceAtLeast(1)
        val position = (currentIndex + 1).coerceAtLeast(1)
        binding.viewerCounter.text = "$position / $total"
        binding.viewerPrevButton.isEnabled = currentIndex > 0
        binding.viewerNextButton.isEnabled = currentIndex in 0 until (currentFolderItems.lastIndex)
        thumbnailAdapter.submit(currentFolderItems, item?.id)
        binding.viewerThumbnailRecycler.visibility = if (controlsVisible && currentFolderItems.size > 1) View.VISIBLE else View.GONE
        if (currentIndex >= 0) binding.viewerThumbnailRecycler.post {
            binding.viewerThumbnailRecycler.smoothScrollToPosition(currentIndex)
        }
    }

    private fun rotateMedia() {
        mediaRotationDegrees = (mediaRotationDegrees + 90f) % 360f
        applyMediaRotation()
    }

    private fun applyMediaRotation() {
        val quarterTurn = mediaRotationDegrees == 90f || mediaRotationDegrees == 270f
        binding.viewerMediaFrame.post {
            val frameWidth = binding.viewerMediaFrame.width.toFloat().coerceAtLeast(1f)
            val frameHeight = binding.viewerMediaFrame.height.toFloat().coerceAtLeast(1f)
            val fitScale = if (quarterTurn) min(frameWidth / frameHeight, frameHeight / frameWidth) else 1f
            listOf(binding.viewerImageZoomLayout, binding.viewerVideoZoomLayout).forEach { view ->
                view.rotation = mediaRotationDegrees
                view.scaleX = fitScale
                view.scaleY = fitScale
            }
        }
        binding.viewerRotateButton.text = if (mediaRotationDegrees == 0f) {
            "Rotation 90°"
        } else {
            "Rotation ${mediaRotationDegrees.toInt()}°"
        }
    }

    private fun toggleOrientationLock() {
        orientationLocked = !orientationLocked
        requestedOrientation = if (orientationLocked) {
            ActivityInfo.SCREEN_ORIENTATION_LOCKED
        } else {
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        updateOrientationLockButton()
    }

    private fun updateOrientationLockButton() {
        binding.viewerOrientationLockButton.text = if (orientationLocked) {
            "Déverrouiller orientation"
        } else {
            "Verrouiller orientation"
        }
    }

    private fun applyFillMode() {
        binding.viewerFitButton.text = if (fillMode) "Remplir" else "Ajuster"
        binding.viewerImage.scaleType = if (fillMode) {
            ImageView.ScaleType.CENTER_CROP
        } else {
            ImageView.ScaleType.FIT_CENTER
        }
        binding.viewerPlayer.resizeMode = if (fillMode) {
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM
        } else {
            AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
    }

    private fun toggleChrome() {
        controlsVisible = !controlsVisible
        applyChromeVisibility()
    }

    private fun applyChromeVisibility() {
        val visibility = if (controlsVisible) View.VISIBLE else View.GONE
        binding.viewerInfo.visibility = visibility
        binding.viewerActionsRow1.visibility = visibility
        binding.viewerActionsRow2.visibility = visibility
        binding.viewerCounter.visibility = visibility
        binding.viewerThumbnailRecycler.visibility = if (controlsVisible && currentFolderItems.size > 1) View.VISIBLE else View.GONE
        WindowCompat.setDecorFitsSystemWindows(window, controlsVisible)
        val controller = WindowInsetsControllerCompat(window, binding.root)
        if (controlsVisible) {
            controller.show(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun confirmDelete() {
        val current = item ?: return
        if (current.protectedFromDeletion) {
            binding.viewerInfo.text = "Ce média est protégé. Déverrouille-le d'abord pour le supprimer."
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Supprimer ce média ?")
            .setMessage("La suppression du fichier privé est définitive.")
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Supprimer") { _, _ ->
                lifecycleScope.launch {
                    val deletedId = current.id
                    val previousIndex = currentIndex
                    runCatching {
                        withContext(Dispatchers.IO) { vault.delete(current) }
                    }.onSuccess {
                        currentFolderItems = currentFolderItems.filterNot { it.id == deletedId }
                        when {
                            currentFolderItems.isEmpty() -> finish()
                            else -> {
                                currentIndex = min(previousIndex, currentFolderItems.lastIndex)
                                item = currentFolderItems[currentIndex]
                                loadCurrent()
                            }
                        }
                    }.onFailure { error ->
                        binding.viewerInfo.text = "Suppression impossible : ${error.message}"
                    }
                }
            }
            .show()
    }

    private fun refreshSequence(itemId: String): Boolean {
        val current = vault.find(itemId) ?: return false
        val folderItems = vault.list(current.folderId)
        val index = folderItems.indexOfFirst { it.id == itemId }
        if (index < 0) return false
        currentFolderItems = folderItems
        currentIndex = index
        item = folderItems[index]
        intent.putExtra(EXTRA_MEDIA_ID, itemId)
        return true
    }

    private fun showPrevious() {
        if (currentIndex <= 0) return
        savePlaybackPosition()
        currentIndex -= 1
        item = currentFolderItems[currentIndex]
        intent.putExtra(EXTRA_MEDIA_ID, item?.id)
        mediaRotationDegrees = 0f
        applyMediaRotation()
        loadCurrent()
    }

    private fun showNext() {
        if (currentIndex < 0 || currentIndex >= currentFolderItems.lastIndex) return
        savePlaybackPosition()
        currentIndex += 1
        item = currentFolderItems[currentIndex]
        intent.putExtra(EXTRA_MEDIA_ID, item?.id)
        mediaRotationDegrees = 0f
        applyMediaRotation()
        loadCurrent()
    }

    private fun seekBy(deltaMs: Long) {
        val exoPlayer = player ?: return
        val duration = exoPlayer.duration.takeIf { it > 0L } ?: Long.MAX_VALUE
        val target = (exoPlayer.currentPosition + deltaMs).coerceIn(0L, duration)
        exoPlayer.seekTo(target)
    }

    private fun savePlaybackPosition() {
        val current = item ?: return
        if (current.kind == MEDIA_VIDEO) {
            savePlaybackPosition(current.id, player?.currentPosition ?: 0L)
        }
    }

    private fun savePlaybackPosition(itemId: String, positionMs: Long) {
        playbackPrefs.edit().putLong("position_$itemId", positionMs).apply()
    }

    private fun loadPlaybackPosition(itemId: String): Long {
        return playbackPrefs.getLong("position_$itemId", 0L)
    }

    private fun prefetchNeighbours() {
        val neighbours = buildList {
            if (currentIndex > 0) add(currentFolderItems[currentIndex - 1])
            if (currentIndex >= 0 && currentIndex < currentFolderItems.lastIndex) add(currentFolderItems[currentIndex + 1])
        }
        if (neighbours.isEmpty()) return
        lifecycleScope.launch(Dispatchers.IO) {
            neighbours.forEach { neighbour ->
                runCatching { vault.thumbnailToCache(neighbour) }
                if (neighbour.kind == MEDIA_PHOTO || !vault.isStreamableVideo(neighbour)) {
                    runCatching { vault.decryptToCache(neighbour) }
                }
            }
        }
    }

    private fun buildInfo(item: MediaItem): String {
        val type = if (item.kind == MEDIA_PHOTO) "Photo" else "Vidéo"
        val camera = when (item.camera) {
            AppPrefs.MODE_FRONT -> "caméra avant"
            AppPrefs.MODE_BACK -> "caméra arrière"
            AppPrefs.MODE_DUAL -> "double caméra"
            AppPrefs.MODE_SUPPORT -> "Nova Support"
            else -> "importé"
        }
        val date = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.FRANCE)
            .format(Date(item.createdAt))
        val duration = if (item.kind == MEDIA_VIDEO && item.durationMs > 0L) {
            " • ${formatDuration(item.durationMs)}"
        } else {
            ""
        }
        val protection = if (item.protectedFromDeletion) " • protégé" else ""
        return "$type • $camera • ${vault.folderName(item.folderId)} • $date$duration$protection"
    }

    private fun formatDuration(durationMs: Long): String {
        val total = durationMs / 1000L
        val hours = total / 3600L
        val minutes = (total % 3600L) / 60L
        val seconds = total % 60L
        return if (hours > 0) {
            String.format(Locale.FRANCE, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.FRANCE, "%02d:%02d", minutes, seconds)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        savePlaybackPosition()
        outState.putString(STATE_MEDIA_ID, item?.id)
        outState.putFloat(STATE_PLAYBACK_SPEED, playbackSpeed)
        outState.putBoolean(STATE_FILL_MODE, fillMode)
        outState.putBoolean(STATE_CONTROLS_VISIBLE, controlsVisible)
        outState.putFloat(STATE_MEDIA_ROTATION, mediaRotationDegrees)
        outState.putBoolean(STATE_ORIENTATION_LOCKED, orientationLocked)
        super.onSaveInstanceState(outState)
    }

    override fun onStop() {
        savePlaybackPosition()
        player?.pause()
        super.onStop()
    }

    override fun onDestroy() {
        binding.viewerPlayer.player = null
        player?.release()
        player = null
        decodedBitmap?.recycle()
        decodedBitmap = null
        if (::thumbnailAdapter.isInitialized) thumbnailAdapter.close()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_MEDIA_ID = "media_id"
        private const val STATE_MEDIA_ID = "state_media_id"
        private const val STATE_PLAYBACK_SPEED = "state_playback_speed"
        private const val STATE_FILL_MODE = "state_fill_mode"
        private const val STATE_CONTROLS_VISIBLE = "state_controls_visible"
        private const val STATE_MEDIA_ROTATION = "state_media_rotation"
        private const val STATE_ORIENTATION_LOCKED = "state_orientation_locked"
    }
}
