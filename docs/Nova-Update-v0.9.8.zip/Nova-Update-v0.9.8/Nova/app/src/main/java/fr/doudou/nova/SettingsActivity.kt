package fr.doudou.nova

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import fr.doudou.nova.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    private val timeoutValues = listOf(0L, 30_000L, 60_000L, 300_000L)
    private val qualityValues = listOf(
        AppPrefs.QUALITY_AUTO,
        AppPrefs.QUALITY_UHD,
        AppPrefs.QUALITY_FHD,
        AppPrefs.QUALITY_HD,
        AppPrefs.QUALITY_SD
    )
    private val photoResolutionValues = listOf(
        AppPrefs.PHOTO_RESOLUTION_AUTO,
        AppPrefs.PHOTO_RESOLUTION_MAX
    )
    private val flashModeValues = listOf(
        AppPrefs.FLASH_OFF,
        AppPrefs.FLASH_AUTO,
        AppPrefs.FLASH_ON
    )
    private val burstCountValues = (2..20).toList()
    private val burstIntervalValues = listOf(250L, 500L, 1_000L)
    private val totalDurationValues = listOf(
        0L,
        10_000L,
        30_000L,
        60_000L,
        3 * 60_000L,
        5 * 60_000L,
        10 * 60_000L,
        30 * 60_000L,
        60 * 60_000L,
        2 * 60 * 60_000L,
        3 * 60 * 60_000L
    )
    private val segmentDurationValues = listOf(
        0L,
        10_000L,
        30_000L,
        60_000L,
        3 * 60_000L,
        5 * 60_000L,
        10 * 60_000L,
        30 * 60_000L,
        60 * 60_000L
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!SecuritySession.isUnlocked()) {
            startActivity(Intent(this, GateActivity::class.java).apply {
                putExtra(GateActivity.EXTRA_DESTINATION, GateActivity.DESTINATION_SETTINGS)
            })
            finish()
            return
        }
        SecuritySession.unlock(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupSpinners()
        restoreValues()
        setupActions()
    }

    private fun setupSpinners() {
        binding.lockTimeoutSpinner.adapter = spinnerAdapter(
            listOf("Immédiat", "30 secondes", "1 minute", "5 minutes")
        )
        binding.qualitySpinner.adapter = spinnerAdapter(
            listOf(
                "Automatique — meilleure qualité supportée",
                "4K / UHD avec repli automatique",
                "1080p",
                "720p",
                "480p"
            )
        )
        binding.photoResolutionSpinner.adapter = spinnerAdapter(
            listOf(
                "Automatique — rapide et compatible",
                "Maximale exposée — capture plus lente"
            )
        )
        binding.flashModeSpinner.adapter = spinnerAdapter(
            listOf("Désactivé", "Automatique", "Activé")
        )
        binding.burstCountSpinner.adapter = spinnerAdapter(
            burstCountValues.map { "$it photos" }
        )
        binding.burstIntervalSpinner.adapter = spinnerAdapter(
            listOf("250 ms — rapide", "500 ms — recommandé", "1 seconde — compatible")
        )
        binding.totalDurationSpinner.adapter = spinnerAdapter(
            listOf(
                "Illimitée", "10 secondes", "30 secondes", "1 minute", "3 minutes",
                "5 minutes", "10 minutes", "30 minutes", "1 heure", "2 heures", "3 heures"
            )
        )
        binding.segmentDurationSpinner.adapter = spinnerAdapter(
            listOf(
                "Sans découpage", "10 secondes", "30 secondes", "1 minute", "3 minutes",
                "5 minutes", "10 minutes", "30 minutes", "1 heure"
            )
        )
    }

    private fun spinnerAdapter(labels: List<String>) = ArrayAdapter(
        this,
        android.R.layout.simple_spinner_dropdown_item,
        labels
    )

    private fun restoreValues() {
        if (AppPrefs.feedbackMode(this) == AppPrefs.FEEDBACK_SIMPLE) {
            binding.simpleRadio.isChecked = true
        } else {
            binding.discreetRadio.isChecked = true
        }
        binding.lockTimeoutSpinner.setSelection(
            timeoutValues.indexOf(AppPrefs.lockTimeoutMs(this)).coerceAtLeast(0)
        )
        binding.biometricSwitch.isChecked = AppPrefs.biometricEnabled(this)
        binding.audioSwitch.isChecked = AppPrefs.audioEnabled(this)
        binding.videoTorchSwitch.isChecked = AppPrefs.videoTorchEnabled(this)
        binding.qualitySpinner.setSelection(
            qualityValues.indexOf(AppPrefs.quality(this)).coerceAtLeast(0)
        )
        binding.photoResolutionSpinner.setSelection(
            photoResolutionValues.indexOf(AppPrefs.photoResolution(this)).coerceAtLeast(0)
        )
        binding.flashModeSpinner.setSelection(
            flashModeValues.indexOf(AppPrefs.flashMode(this)).coerceAtLeast(0)
        )
        binding.nightModeSwitch.isChecked = AppPrefs.nightModeEnabled(this)
        binding.burstSwitch.isChecked = AppPrefs.burstEnabled(this)
        binding.burstCountSpinner.setSelection(
            burstCountValues.indexOf(AppPrefs.burstCount(this)).coerceAtLeast(0)
        )
        binding.burstIntervalSpinner.setSelection(
            burstIntervalValues.indexOf(AppPrefs.burstIntervalMs(this)).coerceAtLeast(0)
        )
        updateBurstControls()
        binding.totalDurationSpinner.setSelection(
            totalDurationValues.indexOf(AppPrefs.videoTotalDurationMs(this)).coerceAtLeast(0)
        )
        binding.segmentDurationSpinner.setSelection(
            segmentDurationValues.indexOf(AppPrefs.videoSegmentDurationMs(this)).coerceAtLeast(0)
        )
    }

    private fun setupActions() {
        binding.burstSwitch.setOnCheckedChangeListener { _, _ -> updateBurstControls() }
        binding.changePinButton.setOnClickListener { showChangePinDialog() }
        binding.updatesButton.setOnClickListener {
            startActivity(Intent(this, UpdatesActivity::class.java))
        }
        binding.saveSettingsButton.setOnClickListener {
            AppPrefs.setFeedbackMode(
                this,
                if (binding.simpleRadio.isChecked) AppPrefs.FEEDBACK_SIMPLE else AppPrefs.FEEDBACK_DISCREET
            )
            AppPrefs.setLockTimeoutMs(this, timeoutValues[binding.lockTimeoutSpinner.selectedItemPosition])
            AppPrefs.setBiometricEnabled(this, binding.biometricSwitch.isChecked)
            AppPrefs.setAudioEnabled(this, binding.audioSwitch.isChecked)
            AppPrefs.setVideoTorchEnabled(this, binding.videoTorchSwitch.isChecked)
            AppPrefs.setQuality(this, qualityValues[binding.qualitySpinner.selectedItemPosition])
            AppPrefs.setPhotoResolution(
                this,
                photoResolutionValues[binding.photoResolutionSpinner.selectedItemPosition]
            )
            AppPrefs.setFlashMode(
                this,
                flashModeValues[binding.flashModeSpinner.selectedItemPosition]
            )
            AppPrefs.setNightModeEnabled(this, binding.nightModeSwitch.isChecked)
            AppPrefs.setBurstEnabled(this, binding.burstSwitch.isChecked)
            if (binding.burstSwitch.isChecked) {
                AppPrefs.setCaptureActionMode(this, AppPrefs.ACTION_MODE_BURST)
            } else if (AppPrefs.captureActionMode(this) == AppPrefs.ACTION_MODE_BURST) {
                AppPrefs.setCaptureActionMode(this, AppPrefs.ACTION_MODE_NORMAL)
            }
            AppPrefs.setBurstCount(
                this,
                burstCountValues[binding.burstCountSpinner.selectedItemPosition]
            )
            AppPrefs.setBurstIntervalMs(
                this,
                burstIntervalValues[binding.burstIntervalSpinner.selectedItemPosition]
            )

            val totalDuration = totalDurationValues[binding.totalDurationSpinner.selectedItemPosition]
            val requestedSegment = segmentDurationValues[binding.segmentDurationSpinner.selectedItemPosition]
            val effectiveSegment = if (totalDuration > 0L && requestedSegment > totalDuration) {
                totalDuration
            } else {
                requestedSegment
            }
            AppPrefs.setVideoTotalDurationMs(this, totalDuration)
            AppPrefs.setVideoSegmentDurationMs(this, effectiveSegment)

            SecuritySession.unlock(this)
            val message = if (effectiveSegment != requestedSegment) {
                "Réglages enregistrés. Le découpage a été limité à la durée maximale sélectionnée. La rafale s’appliquera dès la prochaine photo ; les réglages caméra seront appliqués à la prochaine activation du service."
            } else {
                "Réglages enregistrés. La rafale s’appliquera dès la prochaine photo ; les réglages caméra seront appliqués à la prochaine activation du service."
            }
            AlertDialog.Builder(this)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show()
        }
        binding.settingsBackButton.setOnClickListener { finish() }
    }

    private fun updateBurstControls() {
        val enabled = binding.burstSwitch.isChecked
        binding.burstCountSpinner.isEnabled = enabled
        binding.burstIntervalSpinner.isEnabled = enabled
        binding.burstDetails.alpha = if (enabled) 1f else 0.55f
    }

    private fun showChangePinDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val padding = (20 * resources.displayMetrics.density).toInt()
            setPadding(padding, 0, padding, 0)
        }
        val current = EditText(this).apply {
            hint = "PIN actuel"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        val replacement = EditText(this).apply {
            hint = "Nouveau PIN (6 chiffres minimum)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        val confirmation = EditText(this).apply {
            hint = "Confirmer le nouveau PIN"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        container.addView(current)
        container.addView(replacement)
        container.addView(confirmation)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Changer le PIN Nova")
            .setView(container)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val oldPin = current.text.toString()
                val newPin = replacement.text.toString()
                val confirmed = confirmation.text.toString()
                when {
                    !SecurityStore.verifyPin(this, oldPin.toCharArray()) -> current.error = "PIN actuel incorrect"
                    newPin.length < 6 || newPin.any { !it.isDigit() } -> replacement.error = "6 chiffres minimum"
                    newPin != confirmed -> confirmation.error = "Les PIN ne correspondent pas"
                    else -> {
                        SecurityStore.setPin(this, newPin.toCharArray())
                        SecuritySession.unlock(this)
                        dialog.dismiss()
                    }
                }
            }
        }
        dialog.show()
    }
}
