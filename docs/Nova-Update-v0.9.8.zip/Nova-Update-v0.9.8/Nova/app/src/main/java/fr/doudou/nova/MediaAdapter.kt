package fr.doudou.nova

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import fr.doudou.nova.databinding.ItemMediaBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MediaAdapter(
    private val vault: MediaVault,
    private var items: List<MediaItem>,
    private val onClick: (MediaItem) -> Unit,
    private val onSelectionChanged: (List<MediaItem>) -> Unit
) : RecyclerView.Adapter<MediaAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemMediaBinding) : RecyclerView.ViewHolder(binding.root)

    private val executor = Executors.newFixedThreadPool(3)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val selectedIds = linkedSetOf<String>()
    private var selectionMode = false
    private val thumbnailCache = object : LruCache<String, Bitmap>(32 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    init {
        setHasStableIds(true)
    }

    override fun getItemId(position: Int): Long = items[position].id.hashCode().toLong()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemMediaBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val date = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date(item.createdAt))
        val camera = when (item.camera) {
            AppPrefs.MODE_FRONT -> "Avant"
            AppPrefs.MODE_BACK -> "Arrière"
            AppPrefs.MODE_DUAL -> "Double"
            AppPrefs.MODE_SUPPORT -> "Support"
            else -> "Importé"
        }
        val type = if (item.kind == MEDIA_PHOTO) "Photo" else "Vidéo"
        val selected = item.id in selectedIds

        holder.binding.mediaTypeIcon.text = if (item.kind == MEDIA_PHOTO) "P" else "V"
        holder.binding.mediaTitle.text = "$type · $camera"
        holder.binding.mediaSubtitle.text = "$date · ${formatBytes(item.originalBytes)}"
        holder.binding.mediaDuration.visibility = if (item.kind == MEDIA_VIDEO) View.VISIBLE else View.GONE
        holder.binding.mediaDuration.text = formatDuration(item.durationMs)
        holder.binding.mediaSelectionShade.visibility = if (selected) View.VISIBLE else View.GONE
        holder.binding.mediaSelectionIndicator.visibility = if (selectionMode) View.VISIBLE else View.GONE
        holder.binding.mediaSelectionIndicator.text = if (selected) "✓" else ""
        holder.binding.root.alpha = if (selected) 0.88f else 1f
        holder.binding.mediaThumbnail.tag = item.id
        holder.binding.mediaThumbnail.setImageDrawable(null)

        val cached = thumbnailCache.get(item.id)
        if (cached != null && !cached.isRecycled) {
            holder.binding.mediaThumbnail.setImageBitmap(cached)
        } else {
            executor.execute {
                val bitmap = runCatching {
                    vault.thumbnailToCache(item)?.let { BitmapFactory.decodeFile(it.absolutePath) }
                }.getOrNull()
                if (bitmap != null) thumbnailCache.put(item.id, bitmap)
                mainHandler.post {
                    if (holder.binding.mediaThumbnail.tag == item.id && bitmap != null && !bitmap.isRecycled) {
                        holder.binding.mediaThumbnail.setImageBitmap(bitmap)
                    }
                }
            }
        }

        holder.binding.root.setOnClickListener {
            if (selectionMode) toggleSelection(item) else onClick(item)
        }
        holder.binding.root.setOnLongClickListener {
            if (!selectionMode) selectionMode = true
            toggleSelection(item)
            true
        }
    }

    override fun onViewRecycled(holder: ViewHolder) {
        holder.binding.mediaThumbnail.tag = null
        holder.binding.mediaThumbnail.setImageDrawable(null)
        super.onViewRecycled(holder)
    }

    override fun getItemCount(): Int = items.size

    fun submit(newItems: List<MediaItem>) {
        val oldItems = items
        items = newItems
        selectedIds.retainAll(newItems.mapTo(mutableSetOf()) { it.id })
        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize(): Int = oldItems.size
            override fun getNewListSize(): Int = newItems.size
            override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean =
                oldItems[oldItemPosition].id == newItems[newItemPosition].id

            override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean =
                oldItems[oldItemPosition] == newItems[newItemPosition]
        })
        diff.dispatchUpdatesTo(this)
        dispatchSelectionChanged()
    }

    fun beginSelection() {
        if (selectionMode) return
        selectionMode = true
        notifyItemRangeChanged(0, itemCount)
        dispatchSelectionChanged()
    }

    fun clearSelection() {
        val hadMode = selectionMode
        selectionMode = false
        selectedIds.clear()
        if (hadMode) notifyItemRangeChanged(0, itemCount)
        dispatchSelectionChanged()
    }

    fun selectAll() {
        selectionMode = true
        selectedIds.clear()
        selectedIds.addAll(items.map { it.id })
        notifyItemRangeChanged(0, itemCount)
        dispatchSelectionChanged()
    }

    fun isSelectionMode(): Boolean = selectionMode

    fun selectedItems(): List<MediaItem> = items.filter { it.id in selectedIds }

    private fun toggleSelection(item: MediaItem) {
        val position = items.indexOfFirst { it.id == item.id }
        if (!selectedIds.add(item.id)) selectedIds.remove(item.id)
        if (position >= 0) notifyItemChanged(position)
        dispatchSelectionChanged()
    }

    private fun dispatchSelectionChanged() {
        onSelectionChanged(selectedItems())
    }

    fun close() {
        executor.shutdownNow()
    }

    private fun formatBytes(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        return if (mb >= 1.0) String.format(Locale.FRANCE, "%.1f Mo", mb)
        else String.format(Locale.FRANCE, "%.0f Ko", bytes / 1024.0)
    }

    private fun formatDuration(durationMs: Long): String {
        val seconds = durationMs / 1000L
        val hours = seconds / 3600L
        val minutes = (seconds % 3600L) / 60L
        val remainder = seconds % 60L
        return if (hours > 0) {
            String.format(Locale.FRANCE, "%d:%02d:%02d", hours, minutes, remainder)
        } else {
            String.format(Locale.FRANCE, "%02d:%02d", minutes, remainder)
        }
    }
}
