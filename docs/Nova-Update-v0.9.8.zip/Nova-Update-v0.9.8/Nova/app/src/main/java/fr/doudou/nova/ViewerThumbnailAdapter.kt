package fr.doudou.nova

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import fr.doudou.nova.databinding.ItemViewerThumbnailBinding
import java.util.concurrent.Executors

class ViewerThumbnailAdapter(
    private val vault: MediaVault,
    private val onClick: (MediaItem) -> Unit
) : RecyclerView.Adapter<ViewerThumbnailAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemViewerThumbnailBinding) : RecyclerView.ViewHolder(binding.root)

    private var items: List<MediaItem> = emptyList()
    private var selectedId: String? = null
    private val executor = Executors.newFixedThreadPool(2)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val cache = object : LruCache<String, Bitmap>(16 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    init {
        setHasStableIds(true)
    }

    override fun getItemId(position: Int): Long = items[position].id.hashCode().toLong()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemViewerThumbnailBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val selected = item.id == selectedId
        holder.binding.thumbnailRoot.background = holder.itemView.context.getDrawable(
            if (selected) R.drawable.bg_viewer_thumb_selected else R.drawable.bg_viewer_thumb
        )
        holder.binding.thumbnailRoot.alpha = if (selected) 1f else 0.78f
        holder.binding.thumbnailVideoBadge.visibility = if (item.kind == MEDIA_VIDEO) View.VISIBLE else View.GONE
        holder.binding.thumbnailProtectedBadge.visibility = if (item.protectedFromDeletion) View.VISIBLE else View.GONE
        holder.binding.thumbnailImage.tag = item.id
        holder.binding.thumbnailImage.setImageDrawable(null)

        val cached = cache.get(item.id)
        if (cached != null && !cached.isRecycled) {
            holder.binding.thumbnailImage.setImageBitmap(cached)
        } else {
            executor.execute {
                val bitmap = runCatching {
                    vault.thumbnailToCache(item)?.let { BitmapFactory.decodeFile(it.absolutePath) }
                }.getOrNull()
                if (bitmap != null) cache.put(item.id, bitmap)
                mainHandler.post {
                    if (holder.binding.thumbnailImage.tag == item.id && bitmap != null && !bitmap.isRecycled) {
                        holder.binding.thumbnailImage.setImageBitmap(bitmap)
                    }
                }
            }
        }
        holder.binding.root.setOnClickListener { onClick(item) }
    }

    override fun getItemCount(): Int = items.size

    override fun onViewRecycled(holder: ViewHolder) {
        holder.binding.thumbnailImage.tag = null
        holder.binding.thumbnailImage.setImageDrawable(null)
        super.onViewRecycled(holder)
    }

    fun submit(newItems: List<MediaItem>, newSelectedId: String?) {
        val oldItems = items
        val oldSelected = selectedId
        items = newItems
        selectedId = newSelectedId
        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize(): Int = oldItems.size
            override fun getNewListSize(): Int = newItems.size
            override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean =
                oldItems[oldItemPosition].id == newItems[newItemPosition].id

            override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean =
                oldItems[oldItemPosition] == newItems[newItemPosition] &&
                    (oldItems[oldItemPosition].id == oldSelected) == (newItems[newItemPosition].id == newSelectedId)
        })
        diff.dispatchUpdatesTo(this)
    }

    fun close() {
        executor.shutdownNow()
        cache.evictAll()
    }
}
