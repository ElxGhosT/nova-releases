package fr.doudou.nova

import android.content.Context

object AppPrefs {
    private const val FILE = "nova_preferences"

    const val MODE_BACK = "BACK"
    const val MODE_FRONT = "FRONT"
    const val MODE_DUAL = "DUAL"
    const val MODE_SUPPORT = "SUPPORT"

    const val CAPTURE_PHOTO = "PHOTO"
    const val CAPTURE_VIDEO = "VIDEO"

    const val ACTION_MODE_NORMAL = "NORMAL"
    const val ACTION_MODE_DELAYED = "DELAYED"
    const val ACTION_MODE_BURST = "BURST"

    const val FLASH_OFF = "OFF"
    const val FLASH_AUTO = "AUTO"
    const val FLASH_ON = "ON"

    const val QUALITY_AUTO = "AUTO"
    const val QUALITY_UHD = "UHD"
    const val QUALITY_FHD = "FHD"
    const val QUALITY_HD = "HD"
    const val QUALITY_SD = "SD"

    const val PHOTO_RESOLUTION_AUTO = "AUTO"
    const val PHOTO_RESOLUTION_MAX = "MAX"

    const val FEEDBACK_DISCREET = "DISCREET"
    const val FEEDBACK_SIMPLE = "SIMPLE"

    private fun prefs(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun cameraMode(context: Context): String =
        prefs(context).getString("camera_mode", MODE_BACK) ?: MODE_BACK

    fun setCameraMode(context: Context, value: String) {
        prefs(context).edit().putString("camera_mode", value).apply()
    }

    fun captureMode(context: Context): String =
        prefs(context).getString("capture_mode", CAPTURE_PHOTO) ?: CAPTURE_PHOTO

    fun setCaptureMode(context: Context, value: String) {
        prefs(context).edit().putString("capture_mode", value).apply()
    }


    fun captureActionMode(context: Context): String {
        val stored = prefs(context).getString("capture_action_mode", ACTION_MODE_NORMAL)
            ?: ACTION_MODE_NORMAL
        return when (stored) {
            ACTION_MODE_NORMAL, ACTION_MODE_DELAYED, ACTION_MODE_BURST -> stored
            else -> ACTION_MODE_NORMAL
        }
    }

    fun setCaptureActionMode(context: Context, value: String) {
        val normalized = when (value) {
            ACTION_MODE_NORMAL, ACTION_MODE_DELAYED, ACTION_MODE_BURST -> value
            else -> ACTION_MODE_NORMAL
        }
        prefs(context).edit().putString("capture_action_mode", normalized).apply()
        setBurstEnabled(context, normalized == ACTION_MODE_BURST)
    }

    fun captureDelayMs(context: Context): Long {
        val stored = prefs(context).getLong("capture_delay_ms", 3_000L)
        return when (stored) {
            3_000L, 5_000L, 10_000L, 30_000L, 60_000L -> stored
            else -> 3_000L
        }
    }

    fun setCaptureDelayMs(context: Context, value: Long) {
        val normalized = when (value) {
            3_000L, 5_000L, 10_000L, 30_000L, 60_000L -> value
            else -> 3_000L
        }
        prefs(context).edit().putLong("capture_delay_ms", normalized).apply()
    }

    fun flashMode(context: Context): String {
        val stored = prefs(context).getString("flash_mode", FLASH_OFF) ?: FLASH_OFF
        return when (stored) {
            FLASH_OFF, FLASH_AUTO, FLASH_ON -> stored
            else -> FLASH_OFF
        }
    }

    fun setFlashMode(context: Context, value: String) {
        val normalized = when (value) {
            FLASH_OFF, FLASH_AUTO, FLASH_ON -> value
            else -> FLASH_OFF
        }
        prefs(context).edit().putString("flash_mode", normalized).apply()
    }

    fun videoTorchEnabled(context: Context): Boolean =
        prefs(context).getBoolean("video_torch_enabled", false)

    fun setVideoTorchEnabled(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("video_torch_enabled", value).apply()
    }

    fun nightModeEnabled(context: Context): Boolean =
        prefs(context).getBoolean("night_mode_enabled", false)

    fun setNightModeEnabled(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("night_mode_enabled", value).apply()
    }

    fun remoteMotionEnabled(context: Context): Boolean =
        prefs(context).getBoolean("remote_motion_enabled", false)

    fun setRemoteMotionEnabled(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("remote_motion_enabled", value).apply()
    }

    fun remoteMotionSensitivity(context: Context): Int =
        prefs(context).getInt("remote_motion_sensitivity", 55).coerceIn(10, 95)

    fun setRemoteMotionSensitivity(context: Context, value: Int) {
        prefs(context).edit().putInt("remote_motion_sensitivity", value.coerceIn(10, 95)).apply()
    }

    fun remoteMotionDurationMs(context: Context): Long {
        val stored = prefs(context).getLong("remote_motion_duration_ms", 30_000L)
        return when (stored) {
            10_000L, 20_000L, 30_000L, 60_000L, 120_000L, 300_000L -> stored
            else -> 30_000L
        }
    }

    fun setRemoteMotionDurationMs(context: Context, value: Long) {
        val normalized = when (value) {
            10_000L, 20_000L, 30_000L, 60_000L, 120_000L, 300_000L -> value
            else -> 30_000L
        }
        prefs(context).edit().putLong("remote_motion_duration_ms", normalized).apply()
    }

    fun quality(context: Context): String {
        val stored = prefs(context).getString("quality", QUALITY_AUTO) ?: QUALITY_AUTO
        return when (stored) {
            QUALITY_AUTO, QUALITY_UHD, QUALITY_FHD, QUALITY_HD, QUALITY_SD -> stored
            else -> QUALITY_AUTO
        }
    }

    fun setQuality(context: Context, value: String) {
        prefs(context).edit().putString("quality", value).apply()
    }

    fun photoResolution(context: Context): String {
        val stored = prefs(context).getString("photo_resolution", PHOTO_RESOLUTION_AUTO)
            ?: PHOTO_RESOLUTION_AUTO
        return when (stored) {
            PHOTO_RESOLUTION_AUTO, PHOTO_RESOLUTION_MAX -> stored
            else -> PHOTO_RESOLUTION_AUTO
        }
    }

    fun setPhotoResolution(context: Context, value: String) {
        prefs(context).edit().putString("photo_resolution", value).apply()
    }

    fun burstEnabled(context: Context): Boolean =
        prefs(context).getBoolean("burst_enabled", false)

    fun setBurstEnabled(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("burst_enabled", value).apply()
    }

    /** Nombre de déclenchements dans une rafale. En mode double, chaque déclenchement produit deux photos. */
    fun burstCount(context: Context): Int =
        prefs(context).getInt("burst_count", 5).coerceIn(2, 20)

    fun setBurstCount(context: Context, value: Int) {
        prefs(context).edit().putInt("burst_count", value.coerceIn(2, 20)).apply()
    }

    fun burstIntervalMs(context: Context): Long {
        val stored = prefs(context).getLong("burst_interval_ms", 500L)
        return when (stored) {
            250L, 500L, 1_000L -> stored
            else -> 500L
        }
    }

    fun setBurstIntervalMs(context: Context, value: Long) {
        val normalized = when (value) {
            250L, 500L, 1_000L -> value
            else -> 500L
        }
        prefs(context).edit().putLong("burst_interval_ms", normalized).apply()
    }

    fun remoteCameraAddress(context: Context): String =
        prefs(context).getString("remote_camera_address", "") ?: ""

    fun setRemoteCameraAddress(context: Context, value: String) {
        prefs(context).edit().putString("remote_camera_address", value.trim()).apply()
    }

    fun remoteCameraCode(context: Context): String {
        val secure = RemotePairingStore.read(context)
        if (secure.isNotBlank()) return secure
        // Migration transparente depuis la v0.9.0, qui stockait le code en clair.
        val legacy = prefs(context).getString("remote_camera_code", "").orEmpty()
        if (legacy.isNotBlank()) {
            RemotePairingStore.write(context, legacy)
            prefs(context).edit().remove("remote_camera_code").apply()
        }
        return legacy
    }

    fun setRemoteCameraCode(context: Context, value: String) {
        RemotePairingStore.write(context, value)
        prefs(context).edit().remove("remote_camera_code").apply()
    }

    /**
     * Rapport demandé pour la caméra arrière logique. CameraX le limitera à la
     * plage réellement exposée par le téléphone. Sur les appareils compatibles,
     * une valeur inférieure à 1 bascule vers l'ultra grand-angle.
     */
    fun rearZoomRatio(context: Context): Float =
        normalizeRearZoomRatio(prefs(context).getFloat("rear_zoom_ratio", 1f))

    fun setRearZoomRatio(context: Context, value: Float) {
        prefs(context).edit()
            .putFloat("rear_zoom_ratio", normalizeRearZoomRatio(value))
            .apply()
    }

    /**
     * Conserve explicitement le palier 0,6×. La version 0.8.2.1 relisait par
     * erreur toute valeur comprise entre 0,55 et 2 comme 1×, ce qui faisait
     * revenir l'ultra grand-angle à 1× au moment d'armer le service.
     */
    private fun normalizeRearZoomRatio(value: Float): Float = when {
        value < 0.8f -> 0.6f
        value < 2f -> 1f
        value < 4f -> 3f
        else -> 5f
    }

    fun audioEnabled(context: Context): Boolean =
        prefs(context).getBoolean("audio_enabled", true)

    fun setAudioEnabled(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("audio_enabled", value).apply()
    }

    fun feedbackMode(context: Context): String =
        prefs(context).getString("feedback_mode", FEEDBACK_DISCREET) ?: FEEDBACK_DISCREET

    fun setFeedbackMode(context: Context, value: String) {
        prefs(context).edit().putString("feedback_mode", value).apply()
    }

    fun biometricEnabled(context: Context): Boolean =
        prefs(context).getBoolean("biometric_enabled", true)

    fun setBiometricEnabled(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("biometric_enabled", value).apply()
    }

    fun lockTimeoutMs(context: Context): Long {
        val stored = prefs(context).getLong("lock_timeout_ms", 30_000L)
        return if (stored <= 1L) 0L else stored
    }

    fun setLockTimeoutMs(context: Context, value: Long) {
        prefs(context).edit().putLong("lock_timeout_ms", value).apply()
    }

    /** 0 = illimité. */
    fun videoTotalDurationMs(context: Context): Long =
        prefs(context).getLong("video_total_duration_ms", 0L).coerceAtLeast(0L)

    fun setVideoTotalDurationMs(context: Context, value: Long) {
        prefs(context).edit().putLong("video_total_duration_ms", value.coerceAtLeast(0L)).apply()
    }

    /** 0 = aucun découpage automatique. */
    fun videoSegmentDurationMs(context: Context): Long =
        prefs(context).getLong("video_segment_duration_ms", 5 * 60_000L).coerceAtLeast(0L)

    fun setVideoSegmentDurationMs(context: Context, value: Long) {
        prefs(context).edit().putLong("video_segment_duration_ms", value.coerceAtLeast(0L)).apply()
    }

    fun recordingActive(context: Context): Boolean =
        prefs(context).getBoolean("recording_active", false)

    fun setRecordingActive(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("recording_active", value).apply()
    }

    fun serviceActive(context: Context): Boolean =
        prefs(context).getBoolean("service_active", false)

    fun setServiceActive(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("service_active", value).apply()
    }
}
