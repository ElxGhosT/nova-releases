package fr.doudou.nova

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import fr.doudou.nova.databinding.ActivityQuickCaptureBinding

class QuickCaptureActivity : AppCompatActivity() {

    private lateinit var binding: ActivityQuickCaptureBinding

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) armAndClose()
        else binding.quickDescription.text = "Les autorisations caméra et notification sont nécessaires."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!SecuritySession.isUnlocked()) {
            startActivity(Intent(this, GateActivity::class.java).apply {
                putExtra(GateActivity.EXTRA_DESTINATION, GateActivity.DESTINATION_QUICK)
            })
            finish()
            return
        }
        SecuritySession.unlock(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        binding = ActivityQuickCaptureBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val cameraLabel = when (AppPrefs.cameraMode(this)) {
            AppPrefs.MODE_FRONT -> "caméra avant"
            AppPrefs.MODE_DUAL -> "caméras avant et arrière"
            else -> "caméra arrière"
        }
        val actionLabel = if (AppPrefs.captureMode(this) == AppPrefs.CAPTURE_VIDEO) {
            "Vidéo"
        } else {
            "Photo"
        }
        binding.quickDescription.text = "$actionLabel • $cameraLabel"
        binding.quickArmButton.text = if (AppPrefs.serviceActive(this)) {
            if (AppPrefs.captureMode(this) == AppPrefs.CAPTURE_VIDEO) {
                if (AppPrefs.recordingActive(this)) "Arrêter la vidéo" else "Démarrer la vidéo"
            } else {
                "Prendre une photo"
            }
        } else {
            "Armer Nova"
        }
        binding.quickArmButton.setOnClickListener { requestPermissionsAndRun() }
        binding.quickCancelButton.setOnClickListener { finish() }
    }

    private fun requestPermissionsAndRun() {
        if (AppPrefs.serviceActive(this)) {
            val action = when (AppPrefs.captureMode(this)) {
                AppPrefs.CAPTURE_VIDEO -> if (AppPrefs.recordingActive(this)) {
                    CaptureService.ACTION_STOP_RECORDING
                } else {
                    CaptureService.ACTION_START_RECORDING
                }
                else -> CaptureService.ACTION_TAKE_PHOTO
            }
            startService(Intent(this, CaptureService::class.java).apply { this.action = action })
            finish()
            return
        }

        val permissions = buildList {
            add(Manifest.permission.CAMERA)
            if (AppPrefs.captureMode(this@QuickCaptureActivity) == AppPrefs.CAPTURE_VIDEO &&
                AppPrefs.audioEnabled(this@QuickCaptureActivity)
            ) {
                add(Manifest.permission.RECORD_AUDIO)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) armAndClose() else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun armAndClose() {
        val intent = Intent(this, CaptureService::class.java).apply {
            action = CaptureService.ACTION_ARM
            putExtra(CaptureService.EXTRA_CAMERA_MODE, AppPrefs.cameraMode(this@QuickCaptureActivity))
            putExtra(CaptureService.EXTRA_CAPTURE_MODE, AppPrefs.captureMode(this@QuickCaptureActivity))
            putExtra(CaptureService.EXTRA_QUALITY, AppPrefs.quality(this@QuickCaptureActivity))
            putExtra(
                CaptureService.EXTRA_PHOTO_RESOLUTION,
                AppPrefs.photoResolution(this@QuickCaptureActivity)
            )
            putExtra(CaptureService.EXTRA_ZOOM_RATIO, AppPrefs.rearZoomRatio(this@QuickCaptureActivity))
            putExtra(CaptureService.EXTRA_AUDIO_ENABLED, AppPrefs.audioEnabled(this@QuickCaptureActivity))
            putExtra(
                CaptureService.EXTRA_TOTAL_DURATION_MS,
                AppPrefs.videoTotalDurationMs(this@QuickCaptureActivity)
            )
            putExtra(
                CaptureService.EXTRA_SEGMENT_DURATION_MS,
                AppPrefs.videoSegmentDurationMs(this@QuickCaptureActivity)
            )
        }
        ContextCompat.startForegroundService(this, intent)
        finish()
    }
}
