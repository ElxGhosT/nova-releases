package fr.doudou.nova

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.max
import kotlin.math.roundToInt

const val MEDIA_PHOTO = "PHOTO"
const val MEDIA_VIDEO = "VIDEO"
const val MEDIA_SOURCE_CAPTURED = "CAPTURED"
const val MEDIA_SOURCE_IMPORTED = "IMPORTED"

const val FOLDER_IMAGES = "SYSTEM_IMAGES"
const val FOLDER_VIDEOS = "SYSTEM_VIDEOS"
const val FOLDER_OTHER = "SYSTEM_OTHER"

data class MediaFolder(
    val id: String,
    val name: String,
    val parentId: String?,
    val system: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        if (parentId != null) put("parentId", parentId)
        put("system", system)
        put("createdAt", createdAt)
    }

    companion object {
        fun fromJson(json: JSONObject) = MediaFolder(
            id = json.getString("id"),
            name = json.getString("name"),
            parentId = json.optString("parentId").takeIf { it.isNotBlank() },
            system = json.optBoolean("system", false),
            createdAt = json.optLong("createdAt", System.currentTimeMillis())
        )
    }
}

data class MediaItem(
    val id: String,
    val kind: String,
    val camera: String,
    val groupId: String,
    val encryptedPath: String,
    val thumbnailEncryptedPath: String?,
    val displayName: String,
    val mimeType: String,
    val createdAt: Long,
    val originalBytes: Long,
    val durationMs: Long = 0L,
    val folderId: String,
    val source: String = MEDIA_SOURCE_CAPTURED,
    val exportedUri: String? = null,
    val protectedFromDeletion: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("kind", kind)
        put("camera", camera)
        put("groupId", groupId)
        put("encryptedPath", encryptedPath)
        if (thumbnailEncryptedPath != null) put("thumbnailEncryptedPath", thumbnailEncryptedPath)
        put("displayName", displayName)
        put("mimeType", mimeType)
        put("createdAt", createdAt)
        put("originalBytes", originalBytes)
        put("durationMs", durationMs)
        put("folderId", folderId)
        put("source", source)
        if (exportedUri != null) put("exportedUri", exportedUri)
        put("protectedFromDeletion", protectedFromDeletion)
    }

    companion object {
        fun fromJson(json: JSONObject): MediaItem {
            val kind = json.optString("kind", MEDIA_PHOTO)
            return MediaItem(
                id = json.getString("id"),
                kind = kind,
                camera = json.optString("camera", AppPrefs.MODE_BACK),
                groupId = json.optString("groupId"),
                encryptedPath = json.getString("encryptedPath"),
                thumbnailEncryptedPath = json.optString("thumbnailEncryptedPath").takeIf { it.isNotBlank() },
                displayName = json.getString("displayName"),
                mimeType = json.optString(
                    "mimeType",
                    if (kind == MEDIA_PHOTO) "image/jpeg" else "video/mp4"
                ),
                createdAt = json.optLong("createdAt", 0L),
                originalBytes = json.optLong("originalBytes", 0L),
                durationMs = json.optLong("durationMs", 0L),
                folderId = json.optString("folderId").takeIf { it.isNotBlank() }
                    ?: if (kind == MEDIA_PHOTO) FOLDER_IMAGES else FOLDER_VIDEOS,
                source = json.optString("source", MEDIA_SOURCE_CAPTURED),
                exportedUri = json.optString("exportedUri").takeIf { it.isNotBlank() },
                protectedFromDeletion = json.optBoolean("protectedFromDeletion", false)
            )
        }
    }
}

class MediaVault(private val context: Context) {
    private val root = File(context.filesDir, "nova/media").apply { mkdirs() }
    private val thumbRoot = File(root, "thumbs").apply { mkdirs() }
    private val cacheMediaRoot = File(context.cacheDir, "nova_view/media").apply { mkdirs() }
    private val cacheThumbRoot = File(context.cacheDir, "nova_view/thumbs").apply { mkdirs() }
    private val pendingRoot = File(context.cacheDir, "nova_import").apply { mkdirs() }
    private val indexFile = File(root, "media_index.json")
    private val folderIndexFile = File(root, "folder_index.json")

    init {
        ensureSystemFolders()
    }

    fun addPlainMedia(
        plainFile: File,
        kind: String,
        camera: String,
        groupId: String = UUID.randomUUID().toString(),
        folderId: String? = null,
        source: String = MEDIA_SOURCE_CAPTURED,
        preferredDisplayName: String? = null,
        preferredMimeType: String? = null
    ): MediaItem {
        require(plainFile.exists()) { "Le média temporaire est introuvable." }
        require(kind == MEDIA_PHOTO || kind == MEDIA_VIDEO) { "Type de média non pris en charge." }

        val now = System.currentTimeMillis()
        val id = UUID.randomUUID().toString()
        val cameraLabel = when (camera) {
            AppPrefs.MODE_FRONT -> "FRONT"
            AppPrefs.MODE_BACK -> "BACK"
            AppPrefs.MODE_DUAL -> "DUAL"
            AppPrefs.MODE_SUPPORT -> "SUPPORT"
            else -> "IMPORT"
        }
        val defaultExtension = if (kind == MEDIA_PHOTO) "jpg" else "mp4"
        val mime = preferredMimeType?.takeIf { it.isNotBlank() }
            ?: if (kind == MEDIA_PHOTO) "image/jpeg" else "video/mp4"
        val sourceExtension = preferredDisplayName
            ?.substringAfterLast('.', "")
            ?.lowercase(Locale.ROOT)
            ?.takeIf { it.matches(Regex("[a-z0-9]{1,6}")) }
        val extension = sourceExtension ?: defaultExtension
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.FRANCE).format(Date(now))
        val generatedName = "NOVA_${stamp}_${cameraLabel}.$extension"
        val displayName = preferredDisplayName
            ?.substringAfterLast('/')
            ?.takeIf { it.isNotBlank() }
            ?: generatedName
        val encrypted = File(root, "$id.nva")
        val thumbnailEncrypted = File(thumbRoot, "$id.nvt")
        val thumbnailPlain = File(pendingRoot, "$id.jpg")
        val originalBytes = plainFile.length()
        val durationMs = if (kind == MEDIA_VIDEO) readVideoDuration(plainFile) else 0L

        val hasThumbnail = runCatching {
            createThumbnail(plainFile, kind, thumbnailPlain)
            VaultCrypto.encrypt(thumbnailPlain, thumbnailEncrypted)
            thumbnailPlain.delete()
            true
        }.getOrElse {
            thumbnailPlain.delete()
            thumbnailEncrypted.delete()
            false
        }

        if (kind == MEDIA_VIDEO) {
            VaultCrypto.encryptChunked(plainFile, encrypted)
        } else {
            VaultCrypto.encrypt(plainFile, encrypted)
        }
        plainFile.delete()

        val targetFolder = folderId ?: if (kind == MEDIA_PHOTO) FOLDER_IMAGES else FOLDER_VIDEOS
        val item = MediaItem(
            id = id,
            kind = kind,
            camera = camera,
            groupId = groupId,
            encryptedPath = encrypted.absolutePath,
            thumbnailEncryptedPath = thumbnailEncrypted.absolutePath.takeIf { hasThumbnail },
            displayName = displayName,
            mimeType = mime,
            createdAt = now,
            originalBytes = originalBytes,
            durationMs = durationMs,
            folderId = targetFolder,
            source = source,
            exportedUri = null,
            protectedFromDeletion = false
        )
        synchronized(INDEX_LOCK) {
            val items = readIndex().toMutableList().apply { add(item) }
            writeIndex(items)
        }
        return item
    }

    fun importUri(uri: Uri, folderId: String = FOLDER_OTHER): MediaItem {
        val mime = context.contentResolver.getType(uri).orEmpty()
        val kind = when {
            mime.startsWith("image/") -> MEDIA_PHOTO
            mime.startsWith("video/") -> MEDIA_VIDEO
            else -> error("Seules les images et vidéos sont acceptées.")
        }
        val displayName = queryDisplayName(uri)
        val extension = if (kind == MEDIA_PHOTO) "jpg" else "mp4"
        val temporary = File(pendingRoot, "import_${UUID.randomUUID()}.$extension")
        context.contentResolver.openInputStream(uri)?.use { input ->
            temporary.outputStream().use { output -> input.copyTo(output, 1024 * 1024) }
        } ?: error("Impossible de lire le média sélectionné.")

        return try {
            addPlainMedia(
                plainFile = temporary,
                kind = kind,
                camera = "IMPORT",
                folderId = folderId,
                source = MEDIA_SOURCE_IMPORTED,
                preferredDisplayName = displayName,
                preferredMimeType = mime
            )
        } catch (error: Throwable) {
            temporary.delete()
            throw error
        }
    }

    fun list(folderId: String? = null): List<MediaItem> = synchronized(INDEX_LOCK) {
        readIndex()
            .filter { File(it.encryptedPath).exists() }
            .filter { folderId == null || it.folderId == folderId }
            .sortedByDescending { it.createdAt }
    }

    fun find(id: String): MediaItem? = synchronized(INDEX_LOCK) {
        readIndex().firstOrNull { it.id == id && File(it.encryptedPath).exists() }
    }

    fun folders(): List<MediaFolder> = synchronized(INDEX_LOCK) {
        ensureSystemFoldersLocked()
        readFolders()
    }

    fun createFolder(name: String, parentId: String): MediaFolder = synchronized(INDEX_LOCK) {
        val cleaned = name.trim().replace(Regex("[\\r\\n\\t]"), " ").take(40)
        require(cleaned.isNotBlank()) { "Le nom du dossier est vide." }
        val existing = readFolders()
        require(existing.any { it.id == parentId }) { "Le dossier parent est introuvable." }
        require(existing.none { it.parentId == parentId && it.name.equals(cleaned, true) }) {
            "Un dossier portant ce nom existe déjà ici."
        }
        val folder = MediaFolder(
            id = "USER_${UUID.randomUUID()}",
            name = cleaned,
            parentId = parentId,
            system = false
        )
        writeFolders(existing + folder)
        folder
    }

    fun folderName(folderId: String): String =
        folders().firstOrNull { it.id == folderId }?.name ?: "Médias"

    fun flattenedFolders(): List<Pair<MediaFolder, Int>> {
        val all = folders()
        val result = mutableListOf<Pair<MediaFolder, Int>>()
        fun append(parent: String?, depth: Int) {
            all.filter { it.parentId == parent }
                .sortedWith(compareByDescending<MediaFolder> { it.system }.thenBy { it.createdAt })
                .forEach { folder ->
                    result += folder to depth
                    append(folder.id, depth + 1)
                }
        }
        append(null, 0)
        return result
    }

    fun decryptToCache(item: MediaItem): File {
        val extension = item.displayName.substringAfterLast('.', "")
            .lowercase(Locale.ROOT)
            .takeIf { it.matches(Regex("[a-z0-9]{1,6}")) }
            ?: if (item.kind == MEDIA_PHOTO) "jpg" else "mp4"
        val output = File(cacheMediaRoot, "${item.id}.$extension")
        if (!output.exists() || output.length() == 0L) {
            VaultCrypto.decrypt(File(item.encryptedPath), output)
        }
        return output
    }

    fun thumbnailToCache(item: MediaItem): File? {
        val output = File(cacheThumbRoot, "${item.id}.jpg")
        if (output.exists() && output.length() > 0L) return output

        val encryptedPath = item.thumbnailEncryptedPath
        if (!encryptedPath.isNullOrBlank() && File(encryptedPath).exists()) {
            return runCatching {
                VaultCrypto.decrypt(File(encryptedPath), output)
                output
            }.getOrNull()
        }

        return runCatching {
            val media = decryptToCache(item)
            val plainThumb = File(pendingRoot, "thumb_${item.id}.jpg")
            createThumbnail(media, item.kind, plainThumb)
            plainThumb.copyTo(output, overwrite = true)
            plainThumb.delete()
            output
        }.getOrNull()
    }

    fun clearDecryptedCache() {
        cacheMediaRoot.listFiles()?.forEach { it.deleteRecursively() }
        cacheThumbRoot.listFiles()?.forEach { it.deleteRecursively() }
        pendingRoot.listFiles()?.forEach { it.deleteRecursively() }
    }

    fun delete(item: MediaItem) = delete(listOf(item))

    fun delete(items: Collection<MediaItem>) = synchronized(INDEX_LOCK) {
        if (items.isEmpty()) return@synchronized
        val protectedItems = items.filter { it.protectedFromDeletion }
        require(protectedItems.isEmpty()) {
            if (protectedItems.size == 1) {
                "Le média protégé doit d'abord être déverrouillé."
            } else {
                "Certains médias sont protégés et doivent d'abord être déverrouillés."
            }
        }
        val ids = items.mapTo(mutableSetOf()) { it.id }
        items.forEach(::deleteFiles)
        writeIndex(readIndex().filterNot { it.id in ids })
    }

    private fun deleteFiles(item: MediaItem) {
        item.exportedUri?.let { stored ->
            runCatching { context.contentResolver.delete(Uri.parse(stored), null, null) }
        }
        File(item.encryptedPath).delete()
        item.thumbnailEncryptedPath?.let { File(it).delete() }
        cacheMediaRoot.listFiles { file -> file.name.startsWith("${item.id}.") }
            ?.forEach { it.delete() }
        File(cacheThumbRoot, "${item.id}.jpg").delete()
    }


    fun updateProtection(itemId: String, protectedFromDeletion: Boolean): MediaItem? = synchronized(INDEX_LOCK) {
        var updated: MediaItem? = null
        writeIndex(readIndex().map { current ->
            if (current.id == itemId) {
                current.copy(protectedFromDeletion = protectedFromDeletion).also { updated = it }
            } else {
                current
            }
        })
        updated
    }

    fun move(item: MediaItem, folderId: String) = move(listOf(item), folderId)

    fun move(items: Collection<MediaItem>, folderId: String) = synchronized(INDEX_LOCK) {
        require(readFolders().any { it.id == folderId }) { "Le dossier de destination est introuvable." }
        if (items.isEmpty()) return@synchronized
        val ids = items.mapTo(mutableSetOf()) { it.id }
        writeIndex(readIndex().map { current ->
            if (current.id in ids) current.copy(folderId = folderId) else current
        })
    }

    fun isStreamableVideo(item: MediaItem): Boolean =
        item.kind == MEDIA_VIDEO && VaultCrypto.isChunked(File(item.encryptedPath))

    /** Convertit une ancienne vidéo après sa première lecture, sans bloquer le lecteur. */
    fun upgradeLegacyVideo(item: MediaItem, plainFile: File): Boolean {
        if (item.kind != MEDIA_VIDEO || !plainFile.exists()) return false
        val encrypted = File(item.encryptedPath)
        if (!encrypted.exists() || VaultCrypto.isChunked(encrypted)) return false

        val replacement = File(root, "${item.id}.streamable.tmp")
        val backup = File(root, "${item.id}.legacy.bak")
        return runCatching {
            replacement.delete()
            backup.delete()
            VaultCrypto.encryptChunked(plainFile, replacement)
            synchronized(INDEX_LOCK) {
                if (VaultCrypto.isChunked(encrypted)) {
                    replacement.delete()
                    return@synchronized
                }
                check(encrypted.renameTo(backup)) { "Impossible de préparer la conversion vidéo." }
                if (!replacement.renameTo(encrypted)) {
                    backup.renameTo(encrypted)
                    error("Impossible de finaliser la conversion vidéo.")
                }
                backup.delete()
            }
            true
        }.getOrElse {
            replacement.delete()
            if (!encrypted.exists() && backup.exists()) backup.renameTo(encrypted)
            false
        }
    }

    fun exportToGallery(item: MediaItem): Uri {
        val plain = decryptToCache(item)
        val collection = if (item.kind == MEDIA_PHOTO) {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, item.displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, item.mimeType)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val folder = if (item.kind == MEDIA_PHOTO) "Pictures/Nova" else "Movies/Nova"
                put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
        val uri = context.contentResolver.insert(collection, values)
            ?: error("Impossible de créer le média dans la galerie.")
        try {
            context.contentResolver.openOutputStream(uri, "w")?.use { output ->
                plain.inputStream().use { input -> input.copyTo(output, 1024 * 1024) }
            } ?: error("Impossible d’écrire le média dans la galerie.")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                context.contentResolver.update(uri, values, null, null)
            }
            synchronized(INDEX_LOCK) {
                writeIndex(readIndex().map { current ->
                    if (current.id == item.id) current.copy(exportedUri = uri.toString()) else current
                })
            }
            return uri
        } catch (error: Throwable) {
            context.contentResolver.delete(uri, null, null)
            throw error
        }
    }

    fun hideFromGallery(item: MediaItem) {
        item.exportedUri?.let { stored ->
            runCatching { context.contentResolver.delete(Uri.parse(stored), null, null) }
        }
        synchronized(INDEX_LOCK) {
            writeIndex(readIndex().map { current ->
                if (current.id == item.id) current.copy(exportedUri = null) else current
            })
        }
    }

    private fun queryDisplayName(uri: Uri): String? = runCatching {
        context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    }.getOrNull()

    private fun createThumbnail(input: File, kind: String, output: File) {
        val bitmap = if (kind == MEDIA_PHOTO) {
            val source = ImageDecoder.createSource(input)
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                val width = info.size.width.coerceAtLeast(1)
                val height = info.size.height.coerceAtLeast(1)
                val ratio = 512.0 / max(width, height).toDouble()
                if (ratio < 1.0) {
                    decoder.setTargetSize(
                        (width * ratio).roundToInt().coerceAtLeast(1),
                        (height * ratio).roundToInt().coerceAtLeast(1)
                    )
                }
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } else {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(input.absolutePath)
                val frame = retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: error("Aucune miniature vidéo disponible.")
                scaleBitmap(frame, 512)
            } finally {
                retriever.release()
            }
        }
        output.parentFile?.mkdirs()
        output.outputStream().use { stream ->
            check(bitmap.compress(Bitmap.CompressFormat.JPEG, 82, stream)) {
                "Impossible de créer la miniature."
            }
        }
        bitmap.recycle()
    }

    private fun scaleBitmap(bitmap: Bitmap, maxSize: Int): Bitmap {
        val largest = max(bitmap.width, bitmap.height)
        if (largest <= maxSize) return bitmap
        val ratio = maxSize.toDouble() / largest.toDouble()
        val scaled = Bitmap.createScaledBitmap(
            bitmap,
            (bitmap.width * ratio).roundToInt().coerceAtLeast(1),
            (bitmap.height * ratio).roundToInt().coerceAtLeast(1),
            true
        )
        if (scaled !== bitmap) bitmap.recycle()
        return scaled
    }

    private fun readVideoDuration(file: File): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull()
                ?: 0L
        } catch (_: Throwable) {
            0L
        } finally {
            retriever.release()
        }
    }

    private fun ensureSystemFolders() = synchronized(INDEX_LOCK) {
        ensureSystemFoldersLocked()
    }

    private fun ensureSystemFoldersLocked() {
        val existing = readFolders().toMutableList()
        var changed = false
        fun ensure(id: String, name: String) {
            if (existing.none { it.id == id }) {
                existing += MediaFolder(id, name, null, system = true, createdAt = 0L)
                changed = true
            }
        }
        ensure(FOLDER_IMAGES, "Images")
        ensure(FOLDER_VIDEOS, "Vidéos")
        ensure(FOLDER_OTHER, "Autres")
        if (changed || !folderIndexFile.exists()) writeFolders(existing)
    }

    private fun readIndex(): List<MediaItem> {
        if (!indexFile.exists()) return emptyList()
        return runCatching {
            val array = JSONArray(indexFile.readText(Charsets.UTF_8))
            buildList {
                for (index in 0 until array.length()) {
                    add(MediaItem.fromJson(array.getJSONObject(index)))
                }
            }
        }.getOrElse { emptyList() }
    }

    private fun writeIndex(items: List<MediaItem>) {
        val array = JSONArray()
        items.forEach { array.put(it.toJson()) }
        atomicWrite(indexFile, array.toString())
    }

    private fun readFolders(): List<MediaFolder> {
        if (!folderIndexFile.exists()) return emptyList()
        return runCatching {
            val array = JSONArray(folderIndexFile.readText(Charsets.UTF_8))
            buildList {
                for (index in 0 until array.length()) {
                    add(MediaFolder.fromJson(array.getJSONObject(index)))
                }
            }
        }.getOrElse { emptyList() }
    }

    private fun writeFolders(folders: List<MediaFolder>) {
        val array = JSONArray()
        folders.distinctBy { it.id }.forEach { array.put(it.toJson()) }
        atomicWrite(folderIndexFile, array.toString())
    }

    private fun atomicWrite(target: File, content: String) {
        val temporary = File(target.parentFile, "${target.name}.tmp")
        temporary.writeText(content, Charsets.UTF_8)
        if (target.exists()) target.delete()
        check(temporary.renameTo(target)) { "Impossible d’enregistrer les données privées." }
    }

    companion object {
        private val INDEX_LOCK = Any()
    }
}
