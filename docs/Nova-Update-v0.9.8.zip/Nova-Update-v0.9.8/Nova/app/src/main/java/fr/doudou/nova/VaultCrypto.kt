package fr.doudou.nova

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlin.math.min

object VaultCrypto {
    private const val KEY_ALIAS = "nova_media_key_v1"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val IV_LENGTH = 12
    private const val GCM_TAG_BYTES = 16

    private val CHUNK_MAGIC = byteArrayOf('N'.code.toByte(), 'V'.code.toByte(), 'C'.code.toByte(), '1'.code.toByte())
    private const val CHUNK_VERSION = 1
    private const val DEFAULT_CHUNK_SIZE = 1024 * 1024
    private const val CHUNK_HEADER_SIZE = 24L

    private fun key(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }

    /** Chiffrement historique, conservé pour les photos, miniatures et anciens médias. */
    fun encrypt(input: File, output: File) {
        output.parentFile?.mkdirs()
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        FileOutputStream(output).use { destination ->
            destination.write(cipher.iv)
            CipherOutputStream(destination, cipher).use { encrypted ->
                FileInputStream(input).use { source -> source.copyTo(encrypted, 1024 * 1024) }
            }
        }
    }

    /**
     * Chiffre une vidéo par blocs indépendants. ExoPlayer peut ensuite demander uniquement
     * les blocs nécessaires au démarrage ou à la recherche, sans déchiffrer tout le fichier.
     */
    fun encryptChunked(input: File, output: File, chunkSize: Int = DEFAULT_CHUNK_SIZE) {
        require(chunkSize >= 64 * 1024) { "Taille de bloc invalide." }
        output.parentFile?.mkdirs()
        val originalLength = input.length()
        val chunkCount = if (originalLength == 0L) 0 else {
            ((originalLength + chunkSize - 1L) / chunkSize.toLong()).toInt()
        }

        val activeKey = key()
        DataOutputStream(BufferedOutputStream(FileOutputStream(output), 1024 * 1024)).use { destination ->
            destination.write(CHUNK_MAGIC)
            destination.writeInt(CHUNK_VERSION)
            destination.writeLong(originalLength)
            destination.writeInt(chunkSize)
            destination.writeInt(chunkCount)

            BufferedInputStream(FileInputStream(input), chunkSize).use { source ->
                val buffer = ByteArray(chunkSize)
                while (true) {
                    var total = 0
                    while (total < buffer.size) {
                        val read = source.read(buffer, total, buffer.size - total)
                        if (read < 0) break
                        total += read
                    }
                    if (total == 0) break

                    val cipher = Cipher.getInstance(TRANSFORMATION)
                    cipher.init(Cipher.ENCRYPT_MODE, activeKey)
                    val encrypted = cipher.doFinal(buffer, 0, total)
                    destination.write(cipher.iv)
                    destination.write(encrypted)
                    if (total < buffer.size) break
                }
            }
        }
    }

    fun decrypt(input: File, output: File) {
        if (isChunked(input)) {
            decryptChunked(input, output)
        } else {
            decryptLegacy(input, output)
        }
    }

    private fun decryptLegacy(input: File, output: File) {
        output.parentFile?.mkdirs()
        FileInputStream(input).use { source ->
            val iv = ByteArray(IV_LENGTH)
            val read = source.read(iv)
            require(read == IV_LENGTH) { "Fichier Nova invalide" }
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            CipherInputStream(source, cipher).use { decrypted ->
                FileOutputStream(output).use { destination ->
                    decrypted.copyTo(destination, 1024 * 1024)
                }
            }
        }
    }

    private fun decryptChunked(input: File, output: File) {
        output.parentFile?.mkdirs()
        openChunkedReader(input).use { reader ->
            BufferedOutputStream(FileOutputStream(output), 1024 * 1024).use { destination ->
                for (index in 0 until reader.chunkCount) {
                    destination.write(reader.readChunk(index))
                }
            }
        }
    }

    fun isChunked(file: File): Boolean {
        if (!file.exists() || file.length() < CHUNK_HEADER_SIZE) return false
        return runCatching {
            DataInputStream(FileInputStream(file)).use { input ->
                val magic = ByteArray(CHUNK_MAGIC.size)
                input.readFully(magic)
                magic.contentEquals(CHUNK_MAGIC)
            }
        }.getOrDefault(false)
    }

    fun openChunkedReader(file: File): ChunkReader {
        require(isChunked(file)) { "Cette vidéo n'utilise pas le format de lecture rapide Nova." }
        return ChunkReader(file, key())
    }

    class ChunkReader internal constructor(
        file: File,
        private val secretKey: SecretKey
    ) : AutoCloseable {
        private val randomAccess = RandomAccessFile(file, "r")
        val originalLength: Long
        val chunkSize: Int
        val chunkCount: Int

        init {
            val magic = ByteArray(CHUNK_MAGIC.size)
            randomAccess.readFully(magic)
            require(magic.contentEquals(CHUNK_MAGIC)) { "En-tête vidéo Nova invalide." }
            val version = randomAccess.readInt()
            require(version == CHUNK_VERSION) { "Version vidéo Nova non prise en charge." }
            originalLength = randomAccess.readLong()
            chunkSize = randomAccess.readInt()
            chunkCount = randomAccess.readInt()
            require(originalLength >= 0L && chunkSize > 0 && chunkCount >= 0) {
                "Métadonnées vidéo Nova invalides."
            }
        }

        fun readChunk(index: Int): ByteArray {
            require(index in 0 until chunkCount) { "Bloc vidéo hors limites." }
            val plainStart = index.toLong() * chunkSize.toLong()
            val plainLength = min(chunkSize.toLong(), originalLength - plainStart).toInt()
            val recordOffset = CHUNK_HEADER_SIZE +
                index.toLong() * (IV_LENGTH + chunkSize + GCM_TAG_BYTES).toLong()
            randomAccess.seek(recordOffset)

            val iv = ByteArray(IV_LENGTH)
            randomAccess.readFully(iv)
            val encrypted = ByteArray(plainLength + GCM_TAG_BYTES)
            try {
                randomAccess.readFully(encrypted)
            } catch (error: EOFException) {
                throw IllegalStateException("Vidéo Nova incomplète.", error)
            }

            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(128, iv))
            return cipher.doFinal(encrypted)
        }

        override fun close() {
            randomAccess.close()
        }
    }
}
