package fr.doudou.nova

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import fr.doudou.nova.databinding.ActivityUpdatesBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class UpdatesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUpdatesBinding
    private lateinit var manager: GitHubUpdateManager
    private var novaInfo: GitHubUpdateInfo? = null
    private var supportInfo: GitHubUpdateInfo? = null
    private var pendingInstall: File? = null

    private val unknownSourcesLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        val pending = pendingInstall
        if (pending != null && packageManager.canRequestPackageInstalls()) {
            startActivity(manager.installIntent(pending))
            pendingInstall = null
        } else if (pending != null) {
            showStatus("Autorisation d’installation non accordée.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!SecuritySession.isUnlocked()) {
            startActivity(Intent(this, GateActivity::class.java).apply {
                putExtra(GateActivity.EXTRA_DESTINATION, GateActivity.DESTINATION_SETTINGS)
            })
            finish()
            return
        }
        SecuritySession.unlock(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        binding = ActivityUpdatesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        manager = GitHubUpdateManager(this)

        binding.updateBaseUrlInput.setText(UpdatePrefs.baseUrl(this))
        binding.periodicCheckSwitch.isChecked = UpdatePrefs.autoCheck(this)
        binding.novaVersionText.text = "Installée : ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})"
        refreshInstalledSupport()
        refreshQr()
        setupActions()
    }

    private fun setupActions() {
        binding.updatesBackButton.setOnClickListener { finish() }
        binding.periodicCheckSwitch.setOnCheckedChangeListener { _, checked ->
            UpdatePrefs.setAutoCheck(this, checked)
        }
        binding.saveUpdateUrlButton.setOnClickListener {
            val value = binding.updateBaseUrlInput.text.toString().trim().trimEnd('/')
            if (!value.startsWith("https://")) {
                showStatus("L’adresse doit commencer par https://")
                return@setOnClickListener
            }
            UpdatePrefs.setBaseUrl(this, value)
            novaInfo = null
            supportInfo = null
            binding.installNovaUpdateButton.isEnabled = false
            binding.installSupportUpdateButton.isEnabled = false
            refreshQr()
            showStatus("Adresse GitHub Pages enregistrée.")
        }
        binding.checkUpdatesButton.setOnClickListener { checkUpdates() }
        binding.installNovaUpdateButton.setOnClickListener {
            novaInfo?.let { downloadVerifyAndInstall(it) }
        }
        binding.installSupportUpdateButton.setOnClickListener {
            supportInfo?.let { downloadVerifyAndInstall(it) }
        }
        binding.shareSupportPageButton.setOnClickListener { shareSupportPage() }
    }

    private fun checkUpdates() {
        val base = configuredBaseUrl() ?: return
        setBusy(true, "Recherche des mises à jour…")
        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val nova = manager.fetchInfo("$base/nova.json")
                    val support = manager.fetchInfo("$base/nova-support.json")
                    nova to support
                }
            }
            setBusy(false)
            result.onSuccess { (nova, support) ->
                novaInfo = nova
                supportInfo = support
                renderUpdateInfo()
                showStatus("Informations de version vérifiées.")
            }.onFailure { error ->
                showStatus("Recherche impossible : ${error.message}")
            }
        }
    }

    private fun renderUpdateInfo() {
        val nova = novaInfo
        if (nova != null) {
            val newer = nova.versionCode > BuildConfig.VERSION_CODE.toLong()
            binding.novaVersionText.text = buildString {
                append("Installée : ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
                append("\nDisponible : ${nova.versionName} (${nova.versionCode})")
            }
            binding.novaNotesText.text = notesText(nova, newer)
            binding.installNovaUpdateButton.isEnabled = newer
            binding.installNovaUpdateButton.text = if (newer) {
                "Télécharger Nova ${nova.versionName}"
            } else {
                "Nova est à jour"
            }
        }

        val support = supportInfo
        if (support != null) {
            val installed = manager.installedVersion(SUPPORT_PACKAGE)
            val newer = installed == null || support.versionCode > installed.first
            binding.supportVersionText.text = buildString {
                append(if (installed == null) "Installée : non détectée" else "Installée : ${installed.second} (${installed.first})")
                append("\nDisponible : ${support.versionName} (${support.versionCode})")
            }
            binding.supportNotesText.text = notesText(support, newer)
            binding.installSupportUpdateButton.isEnabled = newer
            binding.installSupportUpdateButton.text = when {
                installed == null -> "Installer Nova Support ${support.versionName}"
                newer -> "Mettre à jour Nova Support"
                else -> "Nova Support est à jour"
            }
        }
        refreshQr()
    }

    private fun notesText(info: GitHubUpdateInfo, updateAvailable: Boolean): String {
        val prefix = if (updateAvailable) {
            if (info.mandatory) "Mise à jour obligatoire" else "Mise à jour disponible"
        } else {
            "Aucune mise à jour nécessaire"
        }
        return if (info.notes.isEmpty()) prefix else {
            prefix + "\n" + info.notes.joinToString("\n") { "• $it" }
        }
    }

    private fun downloadVerifyAndInstall(info: GitHubUpdateInfo) {
        setBusy(true, "Téléchargement de ${info.versionName}…")
        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val file = manager.download(info) { downloaded, total ->
                        if (total > 0L) {
                            val percent = ((downloaded * 100L) / total).toInt().coerceIn(0, 100)
                            runOnUiThread {
                                binding.updateProgress.isIndeterminate = false
                                binding.updateProgress.progress = percent
                                binding.updateStatusText.text = "Téléchargement : $percent %"
                            }
                        }
                    }
                    manager.verify(info, file)
                }
            }
            setBusy(false)
            result.onSuccess { verified ->
                showStatus("APK vérifié : ${verified.versionName}. Ouverture de l’installateur Android…")
                requestInstall(verified.file)
            }.onFailure { error ->
                showStatus("Installation bloquée : ${error.message}")
            }
        }
    }

    private fun requestInstall(file: File) {
        if (packageManager.canRequestPackageInstalls()) {
            startActivity(manager.installIntent(file))
        } else {
            pendingInstall = file
            AlertDialog.Builder(this)
                .setTitle("Autoriser cette source")
                .setMessage("Android doit autoriser Nova à ouvrir l’installateur d’APK. Active « Autoriser depuis cette source », puis reviens dans Nova.")
                .setNegativeButton("Annuler") { _, _ -> pendingInstall = null }
                .setPositiveButton("Ouvrir les réglages") { _, _ ->
                    unknownSourcesLauncher.launch(
                        Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                            data = Uri.parse("package:$packageName")
                        }
                    )
                }
                .show()
        }
    }

    private fun refreshInstalledSupport() {
        val installed = manager.installedVersion(SUPPORT_PACKAGE)
        binding.supportVersionText.text = if (installed == null) {
            "Installée : non détectée"
        } else {
            "Installée : ${installed.second} (${installed.first})"
        }
    }

    private fun refreshQr() {
        val base = UpdatePrefs.baseUrl(this)
        val page = supportInfo?.pageUrl?.takeIf { it.startsWith("https://") }
            ?: base.takeIf { it.startsWith("https://") }?.let { "$it/support/" }
        if (page == null) {
            binding.supportInstallQrImage.setImageDrawable(null)
            binding.supportPageUrlText.text = "Le QR apparaîtra après configuration."
            return
        }
        binding.supportInstallQrImage.setImageBitmap(createQrBitmap(page, 720))
        binding.supportPageUrlText.text = page
    }

    private fun shareSupportPage() {
        val base = configuredBaseUrl() ?: return
        val page = supportInfo?.pageUrl?.takeIf { it.startsWith("https://") } ?: "$base/support/"
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Installer Nova Support")
            putExtra(Intent.EXTRA_TEXT, page)
        }, "Partager le lien Nova Support"))
    }

    private fun configuredBaseUrl(): String? {
        val base = UpdatePrefs.baseUrl(this)
        if (!base.startsWith("https://")) {
            showStatus("Configure d’abord l’adresse HTTPS de GitHub Pages.")
            return null
        }
        return base
    }

    private fun createQrBitmap(content: String, size: Int): Bitmap {
        val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size)
        val pixels = IntArray(size * size)
        for (y in 0 until size) {
            for (x in 0 until size) {
                pixels[y * size + x] = if (matrix[x, y]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
            }
        }
        return Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).apply {
            setPixels(pixels, 0, size, 0, 0, size, size)
        }
    }

    private fun setBusy(busy: Boolean, message: String? = null) {
        binding.checkUpdatesButton.isEnabled = !busy
        binding.saveUpdateUrlButton.isEnabled = !busy
        binding.installNovaUpdateButton.isEnabled = !busy && novaInfo?.versionCode?.let {
            it > BuildConfig.VERSION_CODE.toLong()
        } == true
        val supportInstalled = manager.installedVersion(SUPPORT_PACKAGE)?.first ?: 0L
        binding.installSupportUpdateButton.isEnabled = !busy && supportInfo?.versionCode?.let {
            it > supportInstalled
        } == true
        binding.updateProgress.visibility = if (busy) View.VISIBLE else View.GONE
        binding.updateProgress.isIndeterminate = busy
        if (message != null) showStatus(message)
    }

    private fun showStatus(message: String) {
        binding.updateStatusText.text = message
    }

    companion object {
        private const val SUPPORT_PACKAGE = "fr.doudou.novasupport"
    }
}
