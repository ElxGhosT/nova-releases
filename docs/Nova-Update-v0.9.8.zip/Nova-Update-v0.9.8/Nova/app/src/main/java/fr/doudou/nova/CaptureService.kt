package fr.doudou.nova

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.hardware.camera2.CaptureRequest
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import android.util.Size
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraInfo
import androidx.camera.core.CameraSelector
import androidx.camera.core.ConcurrentCamera
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.min

class CaptureService : LifecycleService() {

    private enum class Stream { FRONT, BACK }
    private enum class BindingMode { PREVIEW, PHOTO, VIDEO }

    private data class PhotoBurstSession(
        val id: String = UUID.randomUUID().toString(),
        val groupId: String = UUID.randomUUID().toString(),
        val targetShots: Int,
        val intervalMs: Long,
        var completedShots: Int = 0,
        var savedCount: Int = 0,
        var pendingSaves: Int = 0,
        var captureSequenceDone: Boolean = false,
        val errors: MutableList<String> = mutableListOf()
    )

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val imageCaptures = mutableMapOf<Stream, ImageCapture>()
    private val cameras = mutableMapOf<Stream, Camera>()
    private val videoCaptures = mutableMapOf<Stream, VideoCapture<Recorder>>()
    private val recordings = mutableMapOf<Stream, Recording>()
    private val pendingVideoFiles = mutableMapOf<Stream, File>()
    private val durations = mutableMapOf<Stream, Long>()
    private val byteCounts = mutableMapOf<Stream, Long>()
    private val startedStreams = mutableSetOf<Stream>()
    private val finalizeErrors = mutableListOf<String>()

    private var cameraProvider: ProcessCameraProvider? = null
    private var selectedCameraMode = AppPrefs.MODE_BACK
    private var selectedCaptureMode = AppPrefs.CAPTURE_PHOTO
    private var selectedQuality = AppPrefs.QUALITY_AUTO
    private var selectedPhotoResolution = AppPrefs.PHOTO_RESOLUTION_AUTO
    private var selectedZoomRatio = 1f
    private var audioEnabled = true
    private var totalDurationLimitMs = 0L
    private var segmentDurationLimitMs = 5 * 60_000L
    private var delayedCountdownText = ""

    private var foregroundStarted = false
    private var bindingInProgress = false
    private var pendingStartRecording = false
    private var recording = false
    private var stopSessionAfterFinalize = false
    private var segmentRollRequested = false
    private var expectedStreams = 1
    private var finalizedStreams = 0
    private var savedVideoCount = 0
    private var dualVideoAvailable = true
    private var pendingPhotoRequest = false
    private var photoCaptureInProgress = false
    private var photoBurstSession: PhotoBurstSession? = null
    private var photoBurstJob: Job? = null
    private var delayedActionJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private var recordingSessionStartedElapsed = 0L
    private var segmentStartedElapsed = 0L
    private var recordingSessionGroupId = ""
    private var currentSegmentGroupId = ""
    private var segmentIndex = 0
    private var segmentTimerJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_ARM -> {
                readConfiguration(intent)
                ensureForeground()
                if (!bindingInProgress) bindSession(startRecordingAfterBind = false)
            }

            ACTION_RECONFIGURE -> {
                if (recording) {
                    reportError("Arrête d’abord la vidéo avant de changer de mode.")
                } else {
                    CaptureStateStore.update(CaptureState.Starting)
                    readConfiguration(intent)
                    ensureForeground()
                    bindSession(startRecordingAfterBind = false)
                }
            }

            ACTION_START_RECORDING -> {
                readConfiguration(intent)
                selectedCaptureMode = AppPrefs.CAPTURE_VIDEO
                AppPrefs.setCaptureMode(this, AppPrefs.CAPTURE_VIDEO)
                ensureForeground()
                requestVideoStartWithDelay()
            }

            ACTION_TAKE_PHOTO -> requestPhotoWithDelay()
            ACTION_SET_ZOOM -> {
                selectedZoomRatio = intent.getFloatExtra(
                    EXTRA_ZOOM_RATIO,
                    AppPrefs.rearZoomRatio(this)
                )
                AppPrefs.setRearZoomRatio(this, selectedZoomRatio)
                applyZoomToBackCamera()
            }
            ACTION_STOP_RECORDING -> stopRecording(endSession = false)
            ACTION_STOP_SESSION -> stopRecording(endSession = true)
        }
        return START_NOT_STICKY
    }

    private fun readConfiguration(intent: Intent) {
        selectedCameraMode = intent.getStringExtra(EXTRA_CAMERA_MODE)
            ?: AppPrefs.cameraMode(this)
        selectedCaptureMode = intent.getStringExtra(EXTRA_CAPTURE_MODE)
            ?: AppPrefs.captureMode(this)
        selectedQuality = intent.getStringExtra(EXTRA_QUALITY)
            ?: AppPrefs.quality(this)
        selectedPhotoResolution = intent.getStringExtra(EXTRA_PHOTO_RESOLUTION)
            ?: AppPrefs.photoResolution(this)
        selectedZoomRatio = intent.getFloatExtra(EXTRA_ZOOM_RATIO, AppPrefs.rearZoomRatio(this))
        audioEnabled = intent.getBooleanExtra(EXTRA_AUDIO_ENABLED, AppPrefs.audioEnabled(this))
        totalDurationLimitMs = intent.getLongExtra(
            EXTRA_TOTAL_DURATION_MS,
            AppPrefs.videoTotalDurationMs(this)
        ).coerceAtLeast(0L)
        segmentDurationLimitMs = intent.getLongExtra(
            EXTRA_SEGMENT_DURATION_MS,
            AppPrefs.videoSegmentDurationMs(this)
        ).coerceAtLeast(0L)

        AppPrefs.setCameraMode(this, selectedCameraMode)
        AppPrefs.setCaptureMode(this, selectedCaptureMode)
        AppPrefs.setQuality(this, selectedQuality)
        AppPrefs.setPhotoResolution(this, selectedPhotoResolution)
        AppPrefs.setRearZoomRatio(this, selectedZoomRatio)
        AppPrefs.setAudioEnabled(this, audioEnabled)
    }

    private fun ensureForeground() {
        if (foregroundStarted) return
        CaptureStateStore.update(CaptureState.Starting)
        AppPrefs.setServiceActive(this, true)
        AppPrefs.setRecordingActive(this, false)
        acquireWakeLock()

        val serviceTypes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            var value = ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            if (audioEnabled) value = value or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            value
        } else {
            0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), serviceTypes)
        foregroundStarted = true
        refreshExternalControls()
    }

    private fun bindSession(startRecordingAfterBind: Boolean) {
        if (bindingInProgress) {
            pendingStartRecording = pendingStartRecording || startRecordingAfterBind
            return
        }
        bindingInProgress = true
        pendingStartRecording = startRecordingAfterBind
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            runCatching {
                val provider = future.get()
                cameraProvider = provider
                provider.unbindAll()
                clearUseCases()

                val bindingMode = when {
                    pendingStartRecording -> BindingMode.VIDEO
                    pendingPhotoRequest -> BindingMode.PHOTO
                    else -> BindingMode.PREVIEW
                }

                if (selectedCameraMode == AppPrefs.MODE_DUAL) {
                    bindDual(provider, bindingMode)
                } else {
                    bindSingle(provider, bindingMode)
                }

                bindingInProgress = false
                when {
                    pendingStartRecording -> {
                        pendingStartRecording = false
                        beginRecording(isContinuation = false)
                    }
                    pendingPhotoRequest -> flushPendingPhotoRequest()
                    else -> {
                        CaptureStateStore.update(CaptureState.Armed(selectedCameraMode, dualVideoAvailable))
                        FeedbackController.confirm(this)
                    }
                }
            }.onFailure { error ->
                bindingInProgress = false
                pendingStartRecording = false
                pendingPhotoRequest = false
                reportError(error.message ?: error.javaClass.simpleName)
                stopSessionNow()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun buildStablePreview(): Preview = Preview.Builder()
        .setResolutionSelector(
            ResolutionSelector.Builder()
                .setResolutionStrategy(
                    ResolutionStrategy(
                        Size(1280, 720),
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                    )
                )
                .build()
        )
        .build()

    private fun bindSingle(provider: ProcessCameraProvider, bindingMode: BindingMode) {
        val stream = if (selectedCameraMode == AppPrefs.MODE_FRONT) Stream.FRONT else Stream.BACK
        val selector = if (stream == Stream.FRONT) {
            CameraSelector.DEFAULT_FRONT_CAMERA
        } else {
            CameraSelector.DEFAULT_BACK_CAMERA
        }
        val useMaxResolution = bindingMode == BindingMode.PHOTO &&
            selectedPhotoResolution == AppPrefs.PHOTO_RESOLUTION_MAX

        fun bind(useMax: Boolean): Camera {
            val useCases = mutableListOf<UseCase>()
            var preview: Preview? = null

            when (bindingMode) {
                BindingMode.PREVIEW -> {
                    val previewUseCase = buildStablePreview()
                    preview = previewUseCase
                    useCases += previewUseCase
                }
                BindingMode.PHOTO -> {
                    val imageCapture = buildImageCapture(useMax)
                    imageCaptures[stream] = imageCapture
                    useCases += imageCapture
                }
                BindingMode.VIDEO -> {
                    val recorder = buildRecorder(selectedQuality)
                    val videoCapture = VideoCapture.Builder(recorder).build()
                    videoCaptures[stream] = videoCapture
                    useCases += videoCapture
                }
            }

            val camera = provider.bindToLifecycle(this, selector, *useCases.toTypedArray())
            cameras[stream] = camera
            if (stream == Stream.BACK) applyZoom(camera, selectedZoomRatio)
            if (bindingMode == BindingMode.PREVIEW) {
                if (stream == Stream.BACK) {
                    PreviewBridge.publishPreviews(back = preview, front = null)
                } else {
                    PreviewBridge.publishPreviews(back = null, front = preview)
                }
            } else {
                PreviewBridge.publishPreviews(back = null, front = null)
            }
            return camera
        }

        runCatching { bind(useMaxResolution) }.recoverCatching { error ->
            if (!useMaxResolution) throw error
            provider.unbindAll()
            clearUseCases()
            bind(useMax = false)
            CaptureEventStore.emit(
                CaptureEvent.Error(
                    "Résolution maximale indisponible avec cet objectif — mode automatique utilisé."
                )
            )
        }.getOrThrow()
        dualVideoAvailable = true
    }

    private fun bindDual(provider: ProcessCameraProvider, bindingMode: BindingMode) {
        val pair = findFrontBackPair(provider)
            ?: error("Le mode avant + arrière n’est pas disponible sur cet appareil.")

        val frontUseCases = mutableListOf<UseCase>()
        val backUseCases = mutableListOf<UseCase>()
        var frontPreview: Preview? = null
        var backPreview: Preview? = null

        when (bindingMode) {
            BindingMode.PREVIEW -> {
                val frontPreviewUseCase = buildStablePreview()
                val backPreviewUseCase = buildStablePreview()
                frontPreview = frontPreviewUseCase
                backPreview = backPreviewUseCase
                frontUseCases += frontPreviewUseCase
                backUseCases += backPreviewUseCase
            }
            BindingMode.PHOTO -> {
                val frontImage = buildImageCapture(useMaxResolution = false)
                val backImage = buildImageCapture(useMaxResolution = false)
                imageCaptures[Stream.FRONT] = frontImage
                imageCaptures[Stream.BACK] = backImage
                frontUseCases += frontImage
                backUseCases += backImage
            }
            BindingMode.VIDEO -> {
                val dualQuality = if (selectedQuality == AppPrefs.QUALITY_AUTO) {
                    AppPrefs.QUALITY_FHD
                } else {
                    selectedQuality
                }
                val frontVideo = VideoCapture.Builder(buildRecorder(dualQuality)).build()
                val backVideo = VideoCapture.Builder(buildRecorder(dualQuality)).build()
                videoCaptures[Stream.FRONT] = frontVideo
                videoCaptures[Stream.BACK] = backVideo
                frontUseCases += frontVideo
                backUseCases += backVideo
            }
        }

        val frontConfig = ConcurrentCamera.SingleCameraConfig(
            pair.first.cameraSelector,
            UseCaseGroup.Builder().apply { frontUseCases.forEach { addUseCase(it) } }.build(),
            this
        )
        val backConfig = ConcurrentCamera.SingleCameraConfig(
            pair.second.cameraSelector,
            UseCaseGroup.Builder().apply { backUseCases.forEach { addUseCase(it) } }.build(),
            this
        )
        provider.bindToLifecycle(listOf(frontConfig, backConfig))
        dualVideoAvailable = true
        if (bindingMode == BindingMode.PREVIEW) {
            PreviewBridge.publishPreviews(back = backPreview, front = frontPreview)
        } else {
            PreviewBridge.publishPreviews(back = null, front = null)
        }
    }

    private fun buildImageCapture(useMaxResolution: Boolean): ImageCapture {
        val burstMode = AppPrefs.captureActionMode(this) == AppPrefs.ACTION_MODE_BURST &&
            AppPrefs.burstCount(this) > 1
        val builder = ImageCapture.Builder()
            .setCaptureMode(
                if (burstMode) ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY
                else ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY
            )
            .setJpegQuality(if (burstMode) 92 else 100)
            .setFlashMode(
                if (AppPrefs.cameraMode(this) != AppPrefs.MODE_BACK) {
                    ImageCapture.FLASH_MODE_OFF
                } else {
                    when (AppPrefs.flashMode(this)) {
                        AppPrefs.FLASH_AUTO -> ImageCapture.FLASH_MODE_AUTO
                        AppPrefs.FLASH_ON -> ImageCapture.FLASH_MODE_ON
                        else -> ImageCapture.FLASH_MODE_OFF
                    }
                }
            )
        if (AppPrefs.nightModeEnabled(this) && AppPrefs.cameraMode(this) == AppPrefs.MODE_BACK && !burstMode) {
            applyExperimentalNightScene(builder)
        }
        if (useMaxResolution && !burstMode) {
            builder.setResolutionSelector(
                ResolutionSelector.Builder()
                    .setAllowedResolutionMode(
                        ResolutionSelector.PREFER_HIGHER_RESOLUTION_OVER_CAPTURE_RATE
                    )
                    .build()
            )
        }
        return builder.build()
    }


    @OptIn(ExperimentalCamera2Interop::class)
    private fun applyExperimentalNightScene(builder: ImageCapture.Builder) {
        runCatching {
            Camera2Interop.Extender(builder)
                .setCaptureRequestOption(
                    CaptureRequest.CONTROL_MODE,
                    CaptureRequest.CONTROL_MODE_USE_SCENE_MODE
                )
                .setCaptureRequestOption(
                    CaptureRequest.CONTROL_SCENE_MODE,
                    CaptureRequest.CONTROL_SCENE_MODE_NIGHT
                )
        }
    }

    private fun findFrontBackPair(provider: ProcessCameraProvider): Pair<CameraInfo, CameraInfo>? {
        provider.availableConcurrentCameraInfos.forEach { infos ->
            val front = infos.firstOrNull { it.lensFacing == CameraSelector.LENS_FACING_FRONT }
            val back = infos.firstOrNull { it.lensFacing == CameraSelector.LENS_FACING_BACK }
            if (front != null && back != null) return front to back
        }
        return null
    }

    private fun applyZoomToBackCamera() {
        if (selectedCameraMode != AppPrefs.MODE_BACK) return
        val camera = cameras[Stream.BACK] ?: return
        applyZoom(camera, selectedZoomRatio)
    }

    private fun applyZoom(camera: Camera, requestedRatio: Float) {
        val zoomLiveData = camera.cameraInfo.zoomState
        val current = zoomLiveData.value
        if (current == null) {
            zoomLiveData.observe(this) { state ->
                if (state != null) {
                    zoomLiveData.removeObservers(this)
                    applyZoomWithRange(camera, requestedRatio, state.minZoomRatio, state.maxZoomRatio)
                }
            }
            return
        }
        applyZoomWithRange(camera, requestedRatio, current.minZoomRatio, current.maxZoomRatio)
    }

    private fun applyZoomWithRange(
        camera: Camera,
        requestedRatio: Float,
        minZoom: Float,
        maxZoom: Float
    ) {
        val ratio = requestedRatio.coerceIn(minZoom, maxZoom)
        camera.cameraControl.setZoomRatio(ratio).addListener({
            if (ratio != requestedRatio) {
                CaptureEventStore.emit(
                    CaptureEvent.Error(
                        "Le zoom demandé n’est pas exposé par cet objectif. Nova utilise %.1f×."
                            .format(Locale.FRANCE, ratio)
                    )
                )
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun buildRecorder(qualityName: String): Recorder {
        val selector = when (qualityName) {
            AppPrefs.QUALITY_UHD -> QualitySelector.from(
                Quality.UHD,
                FallbackStrategy.higherQualityOrLowerThan(Quality.UHD)
            )
            AppPrefs.QUALITY_FHD -> QualitySelector.from(
                Quality.FHD,
                FallbackStrategy.higherQualityOrLowerThan(Quality.FHD)
            )
            AppPrefs.QUALITY_HD -> QualitySelector.from(
                Quality.HD,
                FallbackStrategy.higherQualityOrLowerThan(Quality.HD)
            )
            AppPrefs.QUALITY_SD -> QualitySelector.from(
                Quality.SD,
                FallbackStrategy.higherQualityOrLowerThan(Quality.SD)
            )
            else -> QualitySelector.from(Quality.HIGHEST)
        }
        return Recorder.Builder().setQualitySelector(selector).build()
    }

    @SuppressLint("MissingPermission")
    private fun beginRecording(isContinuation: Boolean) {
        if (recording || videoCaptures.isEmpty()) {
            if (videoCaptures.isEmpty()) reportError("Le mode vidéo n’est pas disponible dans cette session.")
            return
        }

        if (!isContinuation) {
            recordingSessionStartedElapsed = SystemClock.elapsedRealtime()
            recordingSessionGroupId = UUID.randomUUID().toString()
            segmentIndex = 0
        }
        segmentIndex += 1
        segmentStartedElapsed = SystemClock.elapsedRealtime()
        currentSegmentGroupId = "${recordingSessionGroupId}_SEG_${segmentIndex.toString().padStart(3, '0')}"

        recording = true
        stopSessionAfterFinalize = false
        segmentRollRequested = false
        expectedStreams = videoCaptures.size
        finalizedStreams = 0
        savedVideoCount = 0
        finalizeErrors.clear()
        durations.clear()
        byteCounts.clear()
        startedStreams.clear()
        pendingVideoFiles.clear()
        AppPrefs.setRecordingActive(this, true)
        refreshExternalControls()
        applyVideoTorch(AppPrefs.videoTorchEnabled(this))

        videoCaptures.forEach { (stream, capture) ->
            val pendingDir = File(cacheDir, "nova_pending").apply { mkdirs() }
            val file = File(pendingDir, "video_${stream.name}_${UUID.randomUUID()}.mp4")
            pendingVideoFiles[stream] = file
            runCatching {
                var pending = capture.output.prepareRecording(
                    this,
                    FileOutputOptions.Builder(file).build()
                )
                val streamGetsAudio = audioEnabled &&
                    (selectedCameraMode != AppPrefs.MODE_DUAL || stream == Stream.BACK)
                if (streamGetsAudio) pending = pending.withAudioEnabled()
                recordings[stream] = pending.start(ContextCompat.getMainExecutor(this)) { event ->
                    handleVideoEvent(stream, event)
                }
            }.onFailure { error ->
                pendingVideoFiles.remove(stream)
                file.delete()
                finalizeErrors += error.message
                    ?: "Impossible de démarrer la vidéo ${stream.name.lowercase(Locale.FRANCE)}"
            }
        }
        expectedStreams = recordings.size
        if (recordings.isEmpty()) {
            recording = false
            AppPrefs.setRecordingActive(this, false)
            refreshExternalControls()
            reportError(finalizeErrors.joinToString().ifBlank { "Impossible de démarrer l’enregistrement." })
        }
    }

    private fun handleVideoEvent(stream: Stream, event: VideoRecordEvent) {
        when (event) {
            is VideoRecordEvent.Start -> {
                startedStreams += stream
                durations[stream] = 0L
                byteCounts[stream] = 0L
                if (startedStreams.size == expectedStreams) {
                    FeedbackController.confirm(this)
                    scheduleAutomaticStop()
                }
                updateRecordingState()
            }

            is VideoRecordEvent.Status -> {
                durations[stream] = TimeUnit.NANOSECONDS.toMillis(
                    event.recordingStats.recordedDurationNanos
                )
                byteCounts[stream] = event.recordingStats.numBytesRecorded
                updateRecordingState()
            }

            is VideoRecordEvent.Finalize -> finalizeVideo(stream, event)
            else -> Unit
        }
    }

    private fun scheduleAutomaticStop() {
        segmentTimerJob?.cancel()
        val sessionElapsed = sessionElapsedMs()
        val totalRemaining = if (totalDurationLimitMs > 0L) {
            (totalDurationLimitMs - sessionElapsed).coerceAtLeast(0L)
        } else {
            Long.MAX_VALUE
        }
        val segmentRemaining = if (segmentDurationLimitMs > 0L) {
            segmentDurationLimitMs
        } else {
            Long.MAX_VALUE
        }
        val delayMs = min(totalRemaining, segmentRemaining)
        val timerEndsWholeRecording = totalDurationLimitMs > 0L && totalRemaining <= segmentRemaining
        if (delayMs == Long.MAX_VALUE) return
        if (delayMs <= 0L) {
            segmentRollRequested = false
            stopRecording(endSession = false)
            return
        }
        segmentTimerJob = serviceScope.launch {
            delay(delayMs)
            // La décision est prise au moment de programmer le timer. Elle ne dépend
            // plus d'une tolérance temporelle susceptible de relancer un minuscule
            // segment après la durée totale demandée.
            segmentRollRequested = !timerEndsWholeRecording
            stopRecording(endSession = false, automatic = true)
        }
    }

    private fun updateRecordingState() {
        CaptureStateStore.update(
            CaptureState.Recording(
                sessionDurationMs = sessionElapsedMs(),
                segmentDurationMs = (SystemClock.elapsedRealtime() - segmentStartedElapsed).coerceAtLeast(0L),
                segmentIndex = segmentIndex,
                bytes = byteCounts.values.sum(),
                streamCount = startedStreams.size.coerceAtLeast(1),
                photoDuringVideoAvailable = false
            )
        )
    }

    private fun sessionElapsedMs(): Long = if (recordingSessionStartedElapsed <= 0L) {
        0L
    } else {
        (SystemClock.elapsedRealtime() - recordingSessionStartedElapsed).coerceAtLeast(0L)
    }

    private fun finalizeVideo(stream: Stream, event: VideoRecordEvent.Finalize) {
        recordings.remove(stream)
        val file = pendingVideoFiles.remove(stream)
        if (file == null || !file.exists()) {
            val cause = event.cause?.message ?: "code ${event.error}"
            finalizeErrors += "${stream.name.lowercase(Locale.FRANCE)} : fichier final absent ($cause)"
            onVideoFinalizationComplete()
            return
        }

        /*
         * CameraX peut terminer un enregistrement avec un code d'erreur récupérable
         * (notamment lorsque la source devient inactive ou lors d'un arrêt proche de
         * la limite). Le MP4 produit reste parfois parfaitement lisible. L'ancienne
         * logique supprimait systématiquement ce dernier segment, ce qui faisait
         * disparaître la fin d'une vidéo lorsqu'elle durait moins que le découpage.
         *
         * On vérifie désormais le conteneur réel avant de le rejeter. Un segment
         * lisible est conservé, même si Finalize signale une erreur récupérable.
         */
        serviceScope.launch {
            val usable = withContext(Dispatchers.IO) { isUsableFinalVideo(file) }
            if (!usable) {
                val cause = event.cause?.message ?: "code ${event.error}"
                finalizeErrors += "${stream.name.lowercase(Locale.FRANCE)} : segment vidéo inutilisable ($cause)"
                file.delete()
                onVideoFinalizationComplete()
                return@launch
            }

            runCatching {
                withContext(Dispatchers.IO) {
                    val camera = if (stream == Stream.FRONT) AppPrefs.MODE_FRONT else AppPrefs.MODE_BACK
                    MediaVault(this@CaptureService).addPlainMedia(
                        plainFile = file,
                        kind = MEDIA_VIDEO,
                        camera = camera,
                        groupId = currentSegmentGroupId,
                        folderId = FOLDER_VIDEOS
                    )
                }
            }.onSuccess {
                savedVideoCount += 1
            }.onFailure { error ->
                finalizeErrors += error.message ?: "Échec du chiffrement vidéo"
                file.delete()
            }
            onVideoFinalizationComplete()
        }
    }

    private fun isUsableFinalVideo(file: File): Boolean {
        if (!file.exists() || file.length() < MIN_USABLE_VIDEO_BYTES) return false
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            val durationMs = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull()
                ?: 0L
            durationMs >= MIN_USABLE_VIDEO_DURATION_MS
        } catch (_: Throwable) {
            false
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun onVideoFinalizationComplete() {
        finalizedStreams += 1
        if (finalizedStreams < expectedStreams) return

        segmentTimerJob?.cancel()
        segmentTimerJob = null
        recording = false
        recordings.clear()
        applyVideoTorch(false)
        FeedbackController.confirm(this)
        if (savedVideoCount > 0) {
            CaptureEventStore.emit(CaptureEvent.VideoSaved(savedVideoCount, segmentIndex))
        }
        if (finalizeErrors.isNotEmpty()) {
            CaptureEventStore.emit(CaptureEvent.Error(finalizeErrors.joinToString()))
        }

        when {
            stopSessionAfterFinalize -> stopSessionNow()
            segmentRollRequested && foregroundStarted -> {
                segmentRollRequested = false
                serviceScope.launch {
                    delay(180L)
                    beginRecording(isContinuation = true)
                }
            }
            else -> {
                AppPrefs.setRecordingActive(this, false)
                refreshExternalControls()
                serviceScope.launch {
                    delay(160L)
                    bindSession(startRecordingAfterBind = false)
                }
            }
        }
    }

    private fun applyVideoTorch(enabled: Boolean) {
        cameras.values.forEach { camera ->
            if (camera.cameraInfo.hasFlashUnit()) {
                runCatching { camera.cameraControl.enableTorch(enabled) }
            }
        }
    }

    private fun stopRecording(endSession: Boolean, automatic: Boolean = false) {
        stopSessionAfterFinalize = endSession
        if (!automatic) segmentRollRequested = false
        segmentTimerJob?.cancel()
        segmentTimerJob = null
        if (!recording || recordings.isEmpty()) {
            AppPrefs.setRecordingActive(this, false)
            refreshExternalControls()
            if (endSession) stopSessionNow()
            else bindSession(startRecordingAfterBind = false)
            return
        }
        CaptureStateStore.update(CaptureState.Stopping)
        recordings.values.toList().forEach { runCatching { it.stop() } }
    }

    private fun requestVideoStartWithDelay() {
        if (recording || pendingStartRecording) return
        if (AppPrefs.captureActionMode(this) != AppPrefs.ACTION_MODE_DELAYED) {
            startVideoNow()
            return
        }
        scheduleDelayedAction("Vidéo") { startVideoNow() }
    }

    private fun startVideoNow() {
        if (recording || pendingStartRecording) return
        if (videoCaptures.isEmpty()) {
            pendingStartRecording = true
            bindSession(startRecordingAfterBind = true)
        } else {
            beginRecording(isContinuation = false)
        }
    }

    private fun requestPhotoWithDelay() {
        if (AppPrefs.captureActionMode(this) != AppPrefs.ACTION_MODE_DELAYED) {
            requestPhoto()
            return
        }
        scheduleDelayedAction("Photo") { requestPhoto() }
    }

    private fun scheduleDelayedAction(label: String, block: () -> Unit) {
        if (delayedActionJob?.isActive == true) {
            delayedActionJob?.cancel()
            delayedActionJob = null
            CaptureEventStore.emit(CaptureEvent.Error("Retardateur annulé"))
            CaptureStateStore.update(CaptureState.Armed(selectedCameraMode, dualVideoAvailable))
            updateNotification()
            return
        }
        val delayMs = AppPrefs.captureDelayMs(this)
        delayedActionJob = serviceScope.launch {
            var remaining = delayMs
            while (remaining > 0L) {
                delayedCountdownText = "$label dans ${formatDelayRemaining(remaining)}"
                CaptureStateStore.update(CaptureState.Starting)
                updateNotification()
                val step = minOf(1_000L, remaining)
                delay(step)
                remaining -= step
            }
            delayedCountdownText = ""
            delayedActionJob = null
            updateNotification()
            block()
        }
    }

    private fun formatDelayRemaining(value: Long): String {
        val seconds = ((value + 999L) / 1_000L).coerceAtLeast(1L)
        return if (seconds >= 60L) "1 min" else "$seconds s"
    }

    private fun requestPhoto() {
        if (photoCaptureInProgress) return
        if (!foregroundStarted) {
            reportError("Active d’abord les raccourcis externes Nova.")
            return
        }
        if (recording) {
            reportError("Le mode actif est Vidéo. Arrête la vidéo ou sélectionne Photo.")
            return
        }
        if (bindingInProgress) {
            pendingPhotoRequest = true
            return
        }
        if (imageCaptures.isEmpty()) {
            selectedCaptureMode = AppPrefs.CAPTURE_PHOTO
            AppPrefs.setCaptureMode(this, AppPrefs.CAPTURE_PHOTO)
            pendingPhotoRequest = true
            bindSession(startRecordingAfterBind = false)
            return
        }
        startPhotoBurst()
    }

    private fun flushPendingPhotoRequest() {
        if (!pendingPhotoRequest || bindingInProgress || imageCaptures.isEmpty()) return
        pendingPhotoRequest = false
        startPhotoBurst()
    }

    private fun startPhotoBurst() {
        if (!foregroundStarted || imageCaptures.isEmpty()) {
            reportError("La capture photo n’est pas disponible dans cette session.")
            return
        }

        val targetShots = if (AppPrefs.captureActionMode(this) == AppPrefs.ACTION_MODE_BURST) {
            AppPrefs.burstCount(this)
        } else {
            1
        }
        photoCaptureInProgress = true
        photoBurstSession = PhotoBurstSession(
            targetShots = targetShots,
            intervalMs = if (targetShots > 1) AppPrefs.burstIntervalMs(this) else 0L
        )
        captureNextPhotoBurstFrame()
    }

    private fun captureNextPhotoBurstFrame() {
        val session = photoBurstSession ?: return
        if (!foregroundStarted || imageCaptures.isEmpty()) {
            finishPhotoBurst(session.id, "La caméra n’est plus disponible.")
            return
        }

        val frameNumber = session.completedShots + 1
        val frameStartedAt = SystemClock.elapsedRealtime()
        val remaining = AtomicInteger(imageCaptures.size)
        val frameErrors = mutableListOf<String>()

        imageCaptures.forEach { (stream, imageCapture) ->
            val pendingDir = File(cacheDir, "nova_pending").apply { mkdirs() }
            val file = File(
                pendingDir,
                "photo_${stream.name}_R${frameNumber.toString().padStart(2, '0')}_${UUID.randomUUID()}.jpg"
            )
            val callback = object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    serviceScope.launch {
                        val active = photoBurstSession?.takeIf { it.id == session.id }
                        if (active == null) {
                            file.delete()
                            return@launch
                        }
                        active.pendingSaves += 1
                        completePhotoBurstCapture(
                            session.id,
                            remaining,
                            frameErrors,
                            frameStartedAt
                        )
                        launch {
                            runCatching {
                                withContext(Dispatchers.IO) {
                                    val camera = if (stream == Stream.FRONT) AppPrefs.MODE_FRONT else AppPrefs.MODE_BACK
                                    MediaVault(this@CaptureService).addPlainMedia(
                                        plainFile = file,
                                        kind = MEDIA_PHOTO,
                                        camera = camera,
                                        groupId = active.groupId,
                                        folderId = FOLDER_IMAGES
                                    )
                                }
                            }.onSuccess {
                                photoBurstSession?.takeIf { it.id == session.id }?.apply { savedCount += 1 }
                            }.onFailure { error ->
                                file.delete()
                                photoBurstSession?.takeIf { it.id == session.id }?.errors?.add(
                                    error.message ?: "Échec du chiffrement photo"
                                )
                            }
                            photoBurstSession?.takeIf { it.id == session.id }?.let {
                                it.pendingSaves = (it.pendingSaves - 1).coerceAtLeast(0)
                                maybeFinishPhotoBurst(it.id)
                            }
                        }
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    synchronized(frameErrors) {
                        frameErrors += exception.message ?: "Échec photo"
                    }
                    file.delete()
                    serviceScope.launch {
                        completePhotoBurstCapture(
                            session.id,
                            remaining,
                            frameErrors,
                            frameStartedAt
                        )
                    }
                }
            }

            runCatching {
                imageCapture.takePicture(
                    ImageCapture.OutputFileOptions.Builder(file).build(),
                    cameraExecutor,
                    callback
                )
            }.onFailure { error ->
                synchronized(frameErrors) {
                    frameErrors += error.message ?: "Impossible de démarrer la capture photo"
                }
                file.delete()
                serviceScope.launch {
                    completePhotoBurstCapture(
                        session.id,
                        remaining,
                        frameErrors,
                        frameStartedAt
                    )
                }
            }
        }
    }

    private fun completePhotoBurstCapture(
        sessionId: String,
        remaining: AtomicInteger,
        frameErrors: MutableList<String>,
        frameStartedAt: Long
    ) {
        if (remaining.decrementAndGet() != 0) return
        val session = photoBurstSession?.takeIf { it.id == sessionId } ?: return
        synchronized(frameErrors) { session.errors += frameErrors }
        session.completedShots += 1

        if (session.completedShots < session.targetShots && foregroundStarted && !recording) {
            photoBurstJob?.cancel()
            val elapsed = SystemClock.elapsedRealtime() - frameStartedAt
            val remainingDelay = (session.intervalMs - elapsed).coerceAtLeast(0L)
            photoBurstJob = serviceScope.launch {
                delay(remainingDelay)
                if (photoBurstSession?.id == sessionId) captureNextPhotoBurstFrame()
            }
        } else {
            session.captureSequenceDone = true
            maybeFinishPhotoBurst(sessionId)
        }
    }

    private fun maybeFinishPhotoBurst(sessionId: String) {
        val session = photoBurstSession?.takeIf { it.id == sessionId } ?: return
        if (session.captureSequenceDone && session.pendingSaves == 0) {
            finishPhotoBurst(sessionId)
        }
    }

    private fun finishPhotoBurst(sessionId: String, fatalError: String? = null) {
        val session = photoBurstSession?.takeIf { it.id == sessionId } ?: return
        if (fatalError != null) session.errors += fatalError
        photoBurstJob?.cancel()
        photoBurstJob = null
        photoBurstSession = null
        photoCaptureInProgress = false

        if (session.savedCount > 0) {
            FeedbackController.confirm(this)
            CaptureEventStore.emit(CaptureEvent.PhotoSaved(session.savedCount))
        }
        if (session.errors.isNotEmpty()) {
            val prefix = if (session.savedCount > 0) "Rafale partielle. " else "Capture échouée. "
            CaptureEventStore.emit(
                CaptureEvent.Error(prefix + session.errors.distinct().joinToString())
            )
        }
        if (foregroundStarted && !recording) {
            serviceScope.launch {
                delay(120L)
                bindSession(startRecordingAfterBind = false)
            }
        }
    }

    private fun reportError(message: String) {
        CaptureEventStore.emit(CaptureEvent.Error(message))
        CaptureStateStore.update(CaptureState.Error(message))
        serviceScope.launch {
            delay(1_500L)
            if (foregroundStarted && !recording) {
                CaptureStateStore.update(CaptureState.Armed(selectedCameraMode, dualVideoAvailable))
            }
        }
    }

    private fun clearUseCases() {
        imageCaptures.clear()
        videoCaptures.clear()
        cameras.clear()
        PreviewBridge.clearPreviews()
    }

    private fun stopSessionNow() {
        segmentTimerJob?.cancel()
        segmentTimerJob = null
        recordings.values.forEach { runCatching { it.close() } }
        recordings.clear()
        cameraProvider?.unbindAll()
        cameraProvider = null
        clearUseCases()
        recording = false
        bindingInProgress = false
        pendingStartRecording = false
        pendingPhotoRequest = false
        photoBurstJob?.cancel()
        photoBurstJob = null
        photoBurstSession = null
        photoCaptureInProgress = false
        segmentRollRequested = false
        AppPrefs.setRecordingActive(this, false)
        AppPrefs.setServiceActive(this, false)
        CaptureStateStore.update(CaptureState.Idle)
        releaseWakeLock()
        refreshExternalControls()
        if (foregroundStarted) stopForeground(STOP_FOREGROUND_REMOVE)
        foregroundStarted = false
        stopSelf()
    }

    private fun refreshExternalControls() {
        WidgetUpdater.updateAll(this)
        NovaTileService.requestRefresh(this)
    }

    private fun buildNotification() = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(R.drawable.ic_nova_status)
        .setContentTitle(getString(R.string.notification_title))
        .setContentText(
            if (delayedCountdownText.isNotBlank()) delayedCountdownText
            else getString(R.string.notification_text)
        )
        .setContentIntent(openAppPendingIntent())
        .addAction(R.drawable.ic_stop, getString(R.string.notification_stop), stopPendingIntent())
        .setCategory(NotificationCompat.CATEGORY_SERVICE)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setSilent(true)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
        .build()

    private fun updateNotification() {
        if (!foregroundStarted) return
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification())
    }

    private fun openAppPendingIntent(): PendingIntent {
        val intent = Intent(this, GateActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            this,
            20,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun stopPendingIntent(): PendingIntent {
        val intent = Intent(this, CaptureService::class.java).apply { action = ACTION_STOP_SESSION }
        return PendingIntent.getService(
            this,
            21,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Service actif de Nova"
            setSound(null, null)
            enableVibration(false)
            setShowBadge(false)
            lockscreenVisibility = android.app.Notification.VISIBILITY_PRIVATE
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    @SuppressLint("WakelockTimeout")
    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val manager = getSystemService(PowerManager::class.java)
        wakeLock = manager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "Nova:CaptureSession"
        ).apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    override fun onDestroy() {
        segmentTimerJob?.cancel()
        photoBurstJob?.cancel()
        delayedActionJob?.cancel()
        delayedActionJob = null
        photoBurstJob = null
        photoBurstSession = null
        cameraExecutor.shutdown()
        serviceScope.cancel()
        photoCaptureInProgress = false
        if (foregroundStarted || AppPrefs.serviceActive(this)) {
            AppPrefs.setRecordingActive(this, false)
            AppPrefs.setServiceActive(this, false)
            CaptureStateStore.update(CaptureState.Idle)
            refreshExternalControls()
        }
        releaseWakeLock()
        super.onDestroy()
    }

    companion object {
        const val ACTION_ARM = "fr.doudou.nova.action.ARM"
        const val ACTION_RECONFIGURE = "fr.doudou.nova.action.RECONFIGURE"
        const val ACTION_START_RECORDING = "fr.doudou.nova.action.START_RECORDING"
        const val ACTION_STOP_RECORDING = "fr.doudou.nova.action.STOP_RECORDING"
        const val ACTION_TAKE_PHOTO = "fr.doudou.nova.action.TAKE_PHOTO"
        const val ACTION_SET_ZOOM = "fr.doudou.nova.action.SET_ZOOM"
        const val ACTION_STOP_SESSION = "fr.doudou.nova.action.STOP_SESSION"

        const val EXTRA_CAMERA_MODE = "camera_mode"
        const val EXTRA_CAPTURE_MODE = "capture_mode"
        const val EXTRA_AUDIO_ENABLED = "audio_enabled"
        const val EXTRA_QUALITY = "quality"
        const val EXTRA_PHOTO_RESOLUTION = "photo_resolution"
        const val EXTRA_ZOOM_RATIO = "zoom_ratio"
        const val EXTRA_TOTAL_DURATION_MS = "total_duration_ms"
        const val EXTRA_SEGMENT_DURATION_MS = "segment_duration_ms"

        private const val CHANNEL_ID = "nova_services"
        private const val NOTIFICATION_ID = 1707
        private const val MIN_USABLE_VIDEO_BYTES = 8L * 1024L
        private const val MIN_USABLE_VIDEO_DURATION_MS = 300L
    }
}
