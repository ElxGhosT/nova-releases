package fr.doudou.nova

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class NovaTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refreshTile()
    }

    override fun onClick() {
        super.onClick()
        if (AppPrefs.serviceActive(this)) {
            val action = when (AppPrefs.captureMode(this)) {
                AppPrefs.CAPTURE_VIDEO -> if (AppPrefs.recordingActive(this)) {
                    CaptureService.ACTION_STOP_RECORDING
                } else {
                    CaptureService.ACTION_START_RECORDING
                }
                else -> CaptureService.ACTION_TAKE_PHOTO
            }
            startService(Intent(this, CaptureService::class.java).apply { this.action = action })
            refreshTile()
        } else {
            val intent = Intent(this, QuickCaptureActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val pending = PendingIntent.getActivity(
                    this,
                    401,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                startActivityAndCollapse(pending)
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(intent)
            }
        }
    }

    private fun refreshTile() {
        val active = AppPrefs.serviceActive(this)
        val video = AppPrefs.captureMode(this) == AppPrefs.CAPTURE_VIDEO
        val recording = AppPrefs.recordingActive(this)
        qsTile?.apply {
            state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            label = "Nova"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                subtitle = when {
                    !active -> "Inactif"
                    video && recording -> "Arrêter vidéo"
                    video -> "Démarrer vidéo"
                    else -> "Prendre photo"
                }
            }
            updateTile()
        }
    }

    companion object {
        fun requestRefresh(context: Context) {
            runCatching {
                requestListeningState(context, ComponentName(context, NovaTileService::class.java))
            }
        }
    }
}
