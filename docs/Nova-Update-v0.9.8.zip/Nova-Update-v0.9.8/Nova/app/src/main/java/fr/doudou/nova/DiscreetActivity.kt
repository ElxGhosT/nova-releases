package fr.doudou.nova

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import fr.doudou.nova.databinding.ActivityDiscreetBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Écran local gardant Nova au premier plan afin que les touches physiques
 * puissent être reçues normalement par l'activité. Il ne remplace ni ne
 * contourne les indicateurs Android : notification et point vert restent actifs.
 */
class DiscreetActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDiscreetBinding
    private val clockHandler = Handler(Looper.getMainLooper())
    private var lastVolumeTriggerAt = 0L
    private val hideModeStatus = Runnable {
        if (::binding.isInitialized && !AppPrefs.recordingActive(this)) {
            binding.portalModeStatus.visibility = android.view.View.GONE
        }
    }

    private val clockUpdater = object : Runnable {
        override fun run() {
            if (::binding.isInitialized) updateDateAndTime()
            val delayUntilNextMinute = 60_000L - (System.currentTimeMillis() % 60_000L)
            clockHandler.postDelayed(this, delayUntilNextMinute.coerceAtLeast(1_000L))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!SecuritySession.isUnlocked()) {
            startActivity(Intent(this, GateActivity::class.java))
            finish()
            return
        }
        if (!AppPrefs.serviceActive(this)) {
            finish()
            return
        }

        SecuritySession.unlock(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        binding = ActivityDiscreetBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupPortalActions()
        clockHandler.post(clockUpdater)
    }

    override fun onResume() {
        super.onResume()
        if (!AppPrefs.serviceActive(this)) {
            finish()
        } else if (AppPrefs.recordingActive(this)) {
            showModeStatus(persistent = true)
        }
    }

    override fun onDestroy() {
        clockHandler.removeCallbacks(clockUpdater)
        clockHandler.removeCallbacks(hideModeStatus)
        super.onDestroy()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN &&
            event.action == KeyEvent.ACTION_DOWN &&
            event.repeatCount == 0 &&
            AppPrefs.serviceActive(this) &&
            CaptureStateStore.state.value !is CaptureState.Starting &&
            CaptureStateStore.state.value !is CaptureState.Stopping
        ) {
            val now = SystemClock.elapsedRealtime()
            if (now - lastVolumeTriggerAt >= VOLUME_TRIGGER_DEBOUNCE_MS) {
                lastVolumeTriggerAt = now
                triggerSelectedAction()
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun setupPortalActions() = with(binding) {
        closeButton.setOnClickListener { finish() }
        backButton.setOnClickListener {
            pageScroll.smoothScrollTo(0, 0)
            showSection("Activité récente", defaultActivityText())
        }
        refreshButton.setOnClickListener {
            updateDateAndTime()
            connectionStatus.text = "●  À jour"
            showSection(
                "Synchronisation terminée",
                "Les informations locales ont été actualisées.\nAucun élément ne nécessite votre attention."
            )
        }

        shortcutOne.setOnClickListener {
            showSection(
                "Agenda",
                "08:30  Intervention planifiée\n12:00  Pause déjeuner\n18:30  Temps personnel"
            )
        }
        shortcutTwo.setOnClickListener {
            triggerSelectedAction()
            showSection(
                "Maison",
                "État général : normal\nRéseau local : disponible\nDernière vérification : ${currentTime()}"
            )
        }
        shortcutThree.setOnClickListener {
            showSection(
                "Documents récents",
                "Rapport hebdomadaire\nListe de contrôle\nNotes techniques"
            )
            showModeStatus(persistent = AppPrefs.recordingActive(this@DiscreetActivity))
        }
        shortcutFour.setOnClickListener {
            showSection(
                "Notes",
                "• Vérifier les tâches de demain\n• Classer les nouveaux documents\n• Préparer la prochaine intervention"
            )
        }

        searchField.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                submitSearch(searchField.text?.toString().orEmpty())
                true
            } else {
                false
            }
        }
        addressField.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                addressField.setText(PORTAL_ADDRESS)
                pageScroll.smoothScrollTo(0, 0)
                showSection("Accueil", defaultActivityText())
                true
            } else {
                false
            }
        }
    }

    private fun submitSearch(rawQuery: String) {
        val query = rawQuery.trim()
        if (query.isEmpty()) {
            showSection("Recherche", "Saisissez un mot-clé pour rechercher dans votre espace.")
            return
        }
        showSection(
            "Résultats pour « $query »",
            "Aucun résultat exact.\nSuggestions : Agenda, Maison, Documents ou Notes."
        )
    }

    private fun showSection(title: String, text: String) = with(binding) {
        resultTitle.text = title
        resultText.text = text
        resultCard.post { pageScroll.smoothScrollTo(0, resultCard.top) }
    }

    private fun updateDateAndTime() = with(binding) {
        val now = Date()
        pageDate.text = DATE_FORMAT.format(now).replaceFirstChar { it.titlecase(Locale.FRANCE) }
        pageTime.text = TIME_FORMAT.format(now)
        greetingText.text = when (SimpleDateFormat("H", Locale.FRANCE).format(now).toIntOrNull() ?: 12) {
            in 5..11 -> "Bonjour"
            in 12..17 -> "Bon après-midi"
            else -> "Bonsoir"
        }
    }

    private fun currentTime(): String = TIME_FORMAT.format(Date())

    private fun defaultActivityText(): String =
        "• Synchronisation terminée à ${currentTime()}\n" +
            "• Deux documents consultés aujourd’hui\n" +
            "• Aucun élément ne nécessite votre attention"

    private fun triggerSelectedAction() {
        val action = when (AppPrefs.captureMode(this)) {
            AppPrefs.CAPTURE_VIDEO -> if (AppPrefs.recordingActive(this)) {
                CaptureService.ACTION_STOP_RECORDING
            } else {
                CaptureService.ACTION_START_RECORDING
            }
            else -> CaptureService.ACTION_TAKE_PHOTO
        }
        startService(Intent(this, CaptureService::class.java).apply { this.action = action })
        showModeStatus(persistent = action == CaptureService.ACTION_START_RECORDING)
    }

    private fun showModeStatus(persistent: Boolean = false) {
        val label = if (AppPrefs.captureMode(this) == AppPrefs.CAPTURE_VIDEO) {
            if (AppPrefs.recordingActive(this)) "Vidéo en cours" else when (AppPrefs.captureActionMode(this)) {
                AppPrefs.ACTION_MODE_DELAYED -> "Vidéo · retard ${formatDelay(AppPrefs.captureDelayMs(this))}"
                else -> "Vidéo"
            }
        } else {
            when (AppPrefs.captureActionMode(this)) {
                AppPrefs.ACTION_MODE_BURST -> "Rafale ×${AppPrefs.burstCount(this)}"
                AppPrefs.ACTION_MODE_DELAYED -> "Photo · retard ${formatDelay(AppPrefs.captureDelayMs(this))}"
                else -> "Photo"
            }
        }
        binding.portalModeStatus.text = "Mode : $label"
        binding.portalModeStatus.visibility = android.view.View.VISIBLE
        clockHandler.removeCallbacks(hideModeStatus)
        if (!persistent) clockHandler.postDelayed(hideModeStatus, 3_500L)
    }

    private fun formatDelay(value: Long): String = when (value) {
        3_000L -> "3 s"
        5_000L -> "5 s"
        10_000L -> "10 s"
        30_000L -> "30 s"
        60_000L -> "1 min"
        else -> "3 s"
    }

    companion object {
        private const val VOLUME_TRIGGER_DEBOUNCE_MS = 850L
        private const val PORTAL_ADDRESS = "portail.local/accueil"
        private val DATE_FORMAT = SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRANCE)
        private val TIME_FORMAT = SimpleDateFormat("HH:mm", Locale.FRANCE)
    }
}
