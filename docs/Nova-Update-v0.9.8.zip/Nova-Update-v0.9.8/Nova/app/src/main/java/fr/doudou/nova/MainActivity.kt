package fr.doudou.nova

import android.Manifest
import android.hardware.camera2.CaptureRequest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.os.Build
import android.os.Bundle
import android.util.Size
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraInfo
import androidx.camera.core.CameraSelector
import androidx.camera.core.ConcurrentCamera
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import fr.doudou.nova.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : AppCompatActivity() {

    private enum class Stream { FRONT, BACK }

    private data class LocalBurstSession(
        val id: String = UUID.randomUUID().toString(),
        val groupId: String = UUID.randomUUID().toString(),
        val targetShots: Int,
        val intervalMs: Long,
        var completedShots: Int = 0,
        var savedCount: Int = 0,
        var pendingSaves: Int = 0,
        var captureSequenceDone: Boolean = false,
        val errors: MutableList<String> = mutableListOf()
    )

    private lateinit var binding: ActivityMainBinding
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val localImageCaptures = mutableMapOf<Stream, ImageCapture>()
    private val localCameras = mutableMapOf<Stream, Camera>()
    private val localPreviews = mutableListOf<Preview>()
    private var localProvider: ProcessCameraProvider? = null
    private var dualCameraAvailable = false
    private var suppressArmListener = false
    private var pendingPermissionAction: (() -> Unit)? = null
    private var previewSuppressed = false
    private var localPhotoPending = false
    private var localBurstSession: LocalBurstSession? = null
    private var rearMinZoom = 1f
    private var rearMaxZoom = 1f
    private var rearZoomCapabilitiesKnown = false
    private var dualPreviewRecoveryAttempts = 0
    private var dualPreviewCheckJob: Job? = null
    private var delayedLocalActionJob: Job? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val action = pendingPermissionAction
        pendingPermissionAction = null
        val denied = results.filterValues { !it }.keys
        if (denied.isEmpty()) {
            action?.invoke()
        } else {
            localPhotoPending = false
            localBurstSession = null
            suppressArmListener = true
            binding.armSwitch.isChecked = AppPrefs.serviceActive(this)
            suppressArmListener = false
            binding.statusText.text = "Autorisation requise : ${denied.joinToString()}"
            restorePreviewAfterCapture()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!SecuritySession.isUnlocked()) {
            startActivity(Intent(this, GateActivity::class.java))
            finish()
            return
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        restoreSelections()
        setupActions()
        observeState()
        observeEvents()
        detectDualCameraSupport()
        updateStorageText()
    }

    override fun onStart() {
        super.onStart()
        if (::binding.isInitialized && CaptureStateStore.state.value !is CaptureState.Recording) {
            attachServicePreviewProviders()
        }
    }

    override fun onResume() {
        super.onResume()
        if (!SecuritySession.isUnlocked()) {
            startActivity(Intent(this, GateActivity::class.java))
            finish()
            return
        }
        SecuritySession.unlock(this)
        updateCaptureButton(CaptureStateStore.state.value)
        if (!AppPrefs.serviceActive(this)) requestCameraPermissionForPreview()
        maybeCheckForUpdates()
    }

    override fun onStop() {
        dualPreviewCheckJob?.cancel()
        if (::binding.isInitialized && AppPrefs.serviceActive(this)) {
            PreviewBridge.attachProviders(null, null)
        }
        super.onStop()
    }


    private fun maybeCheckForUpdates() {
        if (!UpdatePrefs.shouldAutoCheck(this)) return
        UpdatePrefs.markAutoCheck(this)
        val base = UpdatePrefs.baseUrl(this)
        lifecycleScope.launch {
            val info = runCatching {
                withContext(Dispatchers.IO) {
                    GitHubUpdateManager(this@MainActivity).fetchInfo("$base/nova.json")
                }
            }.getOrNull() ?: return@launch
            if (info.versionCode <= BuildConfig.VERSION_CODE.toLong()) return@launch
            if (UpdatePrefs.lastNotifiedVersion(this@MainActivity) >= info.versionCode) return@launch
            UpdatePrefs.markNotifiedVersion(this@MainActivity, info.versionCode)
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Mise à jour Nova disponible")
                .setMessage("Version ${info.versionName} disponible.${if (info.notes.isEmpty()) "" else "\n\n" + info.notes.joinToString("\n") { "• $it" }}")
                .setNegativeButton("Plus tard", null)
                .setPositiveButton("Ouvrir") { _, _ ->
                    startActivity(Intent(this@MainActivity, UpdatesActivity::class.java))
                }
                .show()
        }
    }

    private fun restoreSelections() {
        when (AppPrefs.cameraMode(this)) {
            AppPrefs.MODE_FRONT -> binding.cameraToggle.check(R.id.frontButton)
            AppPrefs.MODE_DUAL -> binding.cameraToggle.check(R.id.dualButton)
            else -> binding.cameraToggle.check(R.id.backButton)
        }
        when (AppPrefs.captureMode(this)) {
            AppPrefs.CAPTURE_VIDEO -> binding.modeToggle.check(R.id.videoModeButton)
            else -> binding.modeToggle.check(R.id.photoModeButton)
        }
        when (AppPrefs.rearZoomRatio(this)) {
            0.6f -> binding.zoomToggle.check(R.id.zoom06Button)
            3f -> binding.zoomToggle.check(R.id.zoom3Button)
            5f -> binding.zoomToggle.check(R.id.zoom5Button)
            else -> binding.zoomToggle.check(R.id.zoom1Button)
        }
        when (AppPrefs.captureActionMode(this)) {
            AppPrefs.ACTION_MODE_DELAYED -> binding.actionModeToggle.check(R.id.delayedActionButton)
            AppPrefs.ACTION_MODE_BURST -> binding.actionModeToggle.check(R.id.burstActionButton)
            else -> binding.actionModeToggle.check(R.id.normalActionButton)
        }
        updatePreviewLayout()
        updateActionModeUi()
        updateCaptureButton(CaptureStateStore.state.value)
    }

    private fun setupActions() {
        binding.cameraToggle.addOnButtonCheckedListener { _, checkedId, checked ->
            if (!checked) return@addOnButtonCheckedListener
            val mode = when (checkedId) {
                R.id.frontButton -> AppPrefs.MODE_FRONT
                R.id.dualButton -> AppPrefs.MODE_DUAL
                else -> AppPrefs.MODE_BACK
            }
            AppPrefs.setCameraMode(this, mode)
            dualPreviewRecoveryAttempts = 0
            dualPreviewCheckJob?.cancel()
            updatePreviewLayout()

            val state = CaptureStateStore.state.value
            if (AppPrefs.serviceActive(this) && state is CaptureState.Armed) {
                suppressPreviewForCapture("Changement de caméra…", showProgress = true)
                startCaptureService(CaptureService.ACTION_RECONFIGURE)
            } else if (!AppPrefs.serviceActive(this)) {
                bindLocalPreview()
            }
        }

        binding.zoomToggle.addOnButtonCheckedListener { _, checkedId, checked ->
            if (!checked) return@addOnButtonCheckedListener
            val ratio = when (checkedId) {
                R.id.zoom06Button -> 0.6f
                R.id.zoom3Button -> 3f
                R.id.zoom5Button -> 5f
                else -> 1f
            }
            AppPrefs.setRearZoomRatio(this, ratio)
            if (AppPrefs.serviceActive(this)) {
                startService(Intent(this, CaptureService::class.java).apply {
                    action = CaptureService.ACTION_SET_ZOOM
                    putExtra(CaptureService.EXTRA_ZOOM_RATIO, ratio)
                })
            } else {
                localCameras[Stream.BACK]?.let { applyZoom(it, ratio) }
            }
        }

        binding.modeToggle.addOnButtonCheckedListener { _, checkedId, checked ->
            if (!checked) return@addOnButtonCheckedListener
            val mode = if (checkedId == R.id.videoModeButton) {
                AppPrefs.CAPTURE_VIDEO
            } else {
                AppPrefs.CAPTURE_PHOTO
            }
            AppPrefs.setCaptureMode(this, mode)
            WidgetUpdater.updateAll(this)
            NovaTileService.requestRefresh(this)
            updateActionModeUi()
            updateCaptureButton(CaptureStateStore.state.value)

            if (AppPrefs.serviceActive(this) &&
                CaptureStateStore.state.value !is CaptureState.Recording &&
                CaptureStateStore.state.value !is CaptureState.Stopping
            ) {
                suppressPreviewForCapture("Adaptation du service…", showProgress = true)
                startCaptureService(CaptureService.ACTION_RECONFIGURE)
            }
        }

        binding.actionModeToggle.addOnButtonCheckedListener { _, checkedId, checked ->
            if (!checked) return@addOnButtonCheckedListener
            val actionMode = when (checkedId) {
                R.id.delayedActionButton -> AppPrefs.ACTION_MODE_DELAYED
                R.id.burstActionButton -> AppPrefs.ACTION_MODE_BURST
                else -> AppPrefs.ACTION_MODE_NORMAL
            }
            AppPrefs.setCaptureActionMode(this, actionMode)
            updateActionModeUi()
            updateCaptureButton(CaptureStateStore.state.value)
            WidgetUpdater.updateAll(this)
            NovaTileService.requestRefresh(this)
        }

        binding.delaySelectorButton.setOnClickListener { showDelaySelector() }

        binding.armSwitch.setOnCheckedChangeListener { _, checked ->
            if (suppressArmListener) return@setOnCheckedChangeListener
            if (checked) {
                requestPermissions(forService = true) {
                    suppressPreviewForCapture("Activation du service…", showProgress = true)
                    localProvider?.unbindAll()
                    localImageCaptures.clear()
                    localCameras.clear()
                    localPreviews.clear()
                    startCaptureService(CaptureService.ACTION_ARM)
                }
            } else if (AppPrefs.serviceActive(this)) {
                startService(Intent(this, CaptureService::class.java).apply {
                    action = CaptureService.ACTION_STOP_SESSION
                })
            }
        }

        binding.captureButton.setOnClickListener { triggerSelectedAction() }
        binding.mediaButton.setOnClickListener {
            startActivity(Intent(this, MediaVaultActivity::class.java))
        }
        binding.settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.remoteCameraButton.setOnClickListener {
            startActivity(Intent(this, RemoteCameraActivity::class.java))
        }
        binding.discreetScreenButton.setOnClickListener {
            if (AppPrefs.serviceActive(this)) {
                PreviewBridge.attachProviders(null, null)
                startActivity(Intent(this, DiscreetActivity::class.java))
            } else {
                binding.statusText.text = "Arme d’abord les services pour utiliser l’écran discret."
            }
        }
    }

    private fun triggerSelectedAction() {
        val mode = AppPrefs.captureActionMode(this)
        if (mode == AppPrefs.ACTION_MODE_DELAYED &&
            AppPrefs.captureMode(this) == AppPrefs.CAPTURE_PHOTO &&
            !AppPrefs.serviceActive(this)
        ) {
            startLocalDelayedAction()
            return
        }
        executeSelectedAction()
    }

    private fun executeSelectedAction() {
        val state = CaptureStateStore.state.value
        if (state is CaptureState.Starting || state is CaptureState.Stopping || localPhotoPending) return

        if (AppPrefs.captureMode(this) == AppPrefs.CAPTURE_PHOTO) {
            val burstCount = if (AppPrefs.captureActionMode(this) == AppPrefs.ACTION_MODE_BURST) {
                AppPrefs.burstCount(this)
            } else {
                1
            }
            suppressPreviewForCapture(
                if (burstCount > 1) "Rafale de $burstCount déclenchements…" else "Prise de photo…",
                showProgress = true
            )
            if (AppPrefs.serviceActive(this)) {
                startService(Intent(this, CaptureService::class.java).apply {
                    action = CaptureService.ACTION_TAKE_PHOTO
                })
            } else {
                localPhotoPending = true
                requestPermissions(forService = false) { takeLocalPhoto() }
            }
        } else {
            if (state is CaptureState.Recording || AppPrefs.recordingActive(this)) {
                suppressPreviewForCapture("Finalisation de la vidéo…", showProgress = true)
                startService(Intent(this, CaptureService::class.java).apply {
                    action = CaptureService.ACTION_STOP_RECORDING
                })
            } else {
                suppressPreviewForCapture("Démarrage de la vidéo…", showProgress = true)
                requestPermissions(forService = true) {
                    localProvider?.unbindAll()
                    localImageCaptures.clear()
                    localCameras.clear()
                    localPreviews.clear()
                    startCaptureService(CaptureService.ACTION_START_RECORDING)
                }
            }
        }
    }

    private fun startLocalDelayedAction() {
        if (delayedLocalActionJob?.isActive == true) {
            delayedLocalActionJob?.cancel()
            delayedLocalActionJob = null
            binding.statusText.text = "Retardateur annulé"
            updateCaptureButton(CaptureStateStore.state.value)
            return
        }
        val delayMs = AppPrefs.captureDelayMs(this)
        delayedLocalActionJob = lifecycleScope.launch {
            var remaining = delayMs
            while (remaining > 0L) {
                binding.statusText.text = "Photo dans ${formatDelayRemaining(remaining)}"
                binding.captureButton.text = "Annuler le retardateur"
                delay(minOf(1_000L, remaining))
                remaining -= minOf(1_000L, remaining)
            }
            delayedLocalActionJob = null
            executeSelectedAction()
        }
    }

    private fun showDelaySelector() {
        val values = longArrayOf(3_000L, 5_000L, 10_000L, 30_000L, 60_000L)
        val labels = arrayOf("3 secondes", "5 secondes", "10 secondes", "30 secondes", "1 minute")
        val selected = values.indexOf(AppPrefs.captureDelayMs(this)).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Retardateur")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                AppPrefs.setCaptureDelayMs(this, values[which])
                updateActionModeUi()
                dialog.dismiss()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun updateActionModeUi() {
        val photoMode = AppPrefs.captureMode(this) == AppPrefs.CAPTURE_PHOTO
        binding.burstActionButton.visibility = if (photoMode) View.VISIBLE else View.GONE
        if (!photoMode && AppPrefs.captureActionMode(this) == AppPrefs.ACTION_MODE_BURST) {
            AppPrefs.setCaptureActionMode(this, AppPrefs.ACTION_MODE_NORMAL)
            binding.actionModeToggle.check(R.id.normalActionButton)
        }
        val delayed = AppPrefs.captureActionMode(this) == AppPrefs.ACTION_MODE_DELAYED
        binding.delaySelectorButton.visibility = if (delayed) View.VISIBLE else View.GONE
        binding.delaySelectorButton.text = "Retardateur : ${formatDelayLabel(AppPrefs.captureDelayMs(this))}"
    }

    private fun formatDelayLabel(value: Long): String = when (value) {
        3_000L -> "3 secondes"
        5_000L -> "5 secondes"
        10_000L -> "10 secondes"
        30_000L -> "30 secondes"
        60_000L -> "1 minute"
        else -> "3 secondes"
    }

    private fun formatDelayRemaining(value: Long): String {
        val seconds = ((value + 999L) / 1_000L).coerceAtLeast(1L)
        return if (seconds >= 60L) "1 min" else "$seconds s"
    }

    private fun requestCameraPermissionForPreview() {
        requestPermissions(forService = false) { bindLocalPreview() }
    }

    private fun requestPermissions(forService: Boolean, action: () -> Unit) {
        val permissions = buildList {
            add(Manifest.permission.CAMERA)
            if (forService && AppPrefs.audioEnabled(this@MainActivity)) {
                add(Manifest.permission.RECORD_AUDIO)
            }
            if (forService && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            action()
        } else {
            if (pendingPermissionAction != null) return
            pendingPermissionAction = action
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun startCaptureService(action: String) {
        val intent = Intent(this, CaptureService::class.java).apply {
            this.action = action
            putExtra(CaptureService.EXTRA_CAMERA_MODE, selectedCameraMode())
            putExtra(CaptureService.EXTRA_CAPTURE_MODE, AppPrefs.captureMode(this@MainActivity))
            putExtra(CaptureService.EXTRA_QUALITY, AppPrefs.quality(this@MainActivity))
            putExtra(
                CaptureService.EXTRA_PHOTO_RESOLUTION,
                AppPrefs.photoResolution(this@MainActivity)
            )
            putExtra(CaptureService.EXTRA_ZOOM_RATIO, AppPrefs.rearZoomRatio(this@MainActivity))
            putExtra(CaptureService.EXTRA_AUDIO_ENABLED, AppPrefs.audioEnabled(this@MainActivity))
            putExtra(
                CaptureService.EXTRA_TOTAL_DURATION_MS,
                AppPrefs.videoTotalDurationMs(this@MainActivity)
            )
            putExtra(
                CaptureService.EXTRA_SEGMENT_DURATION_MS,
                AppPrefs.videoSegmentDurationMs(this@MainActivity)
            )
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun selectedCameraMode(): String = when (binding.cameraToggle.checkedButtonId) {
        R.id.frontButton -> AppPrefs.MODE_FRONT
        R.id.dualButton -> AppPrefs.MODE_DUAL
        else -> AppPrefs.MODE_BACK
    }

    private fun detectDualCameraSupport() {
        binding.dualButton.isEnabled = false
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            dualCameraAvailable = runCatching {
                future.get().availableConcurrentCameraInfos.any { infos ->
                    infos.any { it.lensFacing == CameraSelector.LENS_FACING_FRONT } &&
                        infos.any { it.lensFacing == CameraSelector.LENS_FACING_BACK }
                }
            }.getOrDefault(false)

            binding.capabilityText.text = if (dualCameraAvailable) {
                "Avant + arrière détecté — la qualité réelle dépend de la combinaison acceptée par le S25"
            } else {
                "Mode avant + arrière non exposé par le téléphone"
            }
            if (!dualCameraAvailable && selectedCameraMode() == AppPrefs.MODE_DUAL) {
                binding.cameraToggle.check(R.id.backButton)
            }
            updateControlAvailability(CaptureStateStore.state.value)

            runCatching {
                val backInfo = future.get().getCameraInfo(CameraSelector.DEFAULT_BACK_CAMERA)
                val zoomLiveData = backInfo.zoomState
                val current = zoomLiveData.value
                if (current != null) {
                    configureZoomButtons(current.minZoomRatio, current.maxZoomRatio)
                } else {
                    binding.zoomCapabilityText.text = "Objectifs arrière : détection…"
                    zoomLiveData.observe(this) { state ->
                        if (state != null) {
                            zoomLiveData.removeObservers(this)
                            configureZoomButtons(state.minZoomRatio, state.maxZoomRatio)
                        }
                    }
                }
            }.onFailure {
                binding.zoomCapabilityText.text = "Plage de zoom disponible après ouverture de la caméra"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindLocalPreview() {
        if (AppPrefs.serviceActive(this) || !::binding.isInitialized || localPhotoPending) return
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            runCatching {
                val provider = future.get()
                localProvider = provider
                provider.unbindAll()
                localImageCaptures.clear()
                localCameras.clear()
                localPreviews.clear()

                when (selectedCameraMode()) {
                    AppPrefs.MODE_DUAL -> bindLocalDual(provider)
                    AppPrefs.MODE_FRONT -> bindLocalSingle(provider, Stream.FRONT)
                    else -> bindLocalSingle(provider, Stream.BACK)
                }
            }.onFailure { error ->
                binding.statusText.text = "Aperçu indisponible : ${error.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun buildLocalImageCapture(useMaxResolution: Boolean): ImageCapture {
        val burstMode = AppPrefs.captureActionMode(this) == AppPrefs.ACTION_MODE_BURST &&
            AppPrefs.burstCount(this) > 1
        val builder = ImageCapture.Builder()
            .setCaptureMode(
                if (burstMode) ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY
                else ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY
            )
            .setJpegQuality(if (burstMode) 92 else 100)
            .setFlashMode(
                if (AppPrefs.cameraMode(this) != AppPrefs.MODE_BACK) {
                    ImageCapture.FLASH_MODE_OFF
                } else {
                    when (AppPrefs.flashMode(this)) {
                        AppPrefs.FLASH_AUTO -> ImageCapture.FLASH_MODE_AUTO
                        AppPrefs.FLASH_ON -> ImageCapture.FLASH_MODE_ON
                        else -> ImageCapture.FLASH_MODE_OFF
                    }
                }
            )
        if (AppPrefs.nightModeEnabled(this) && AppPrefs.cameraMode(this) == AppPrefs.MODE_BACK && !burstMode) {
            applyExperimentalNightScene(builder)
        }
        if (useMaxResolution && !burstMode) {
            builder.setResolutionSelector(
                ResolutionSelector.Builder()
                    .setAllowedResolutionMode(
                        ResolutionSelector.PREFER_HIGHER_RESOLUTION_OVER_CAPTURE_RATE
                    )
                    .build()
            )
        }
        return builder.build()
    }

    private fun buildStablePreview(): Preview = Preview.Builder()
        .setResolutionSelector(
            ResolutionSelector.Builder()
                .setResolutionStrategy(
                    ResolutionStrategy(
                        Size(1280, 720),
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                    )
                )
                .build()
        )
        .build()

    private fun bindLocalSingle(provider: ProcessCameraProvider, stream: Stream) {
        val selector = if (stream == Stream.FRONT) {
            CameraSelector.DEFAULT_FRONT_CAMERA
        } else {
            CameraSelector.DEFAULT_BACK_CAMERA
        }
        val preview = buildStablePreview().also {
            it.setSurfaceProvider(binding.mainPreview.surfaceProvider)
        }
        val camera = provider.bindToLifecycle(this, selector, preview)
        localPreviews += preview
        localCameras[stream] = camera
        if (stream == Stream.BACK) {
            configureZoomButtonsFromCamera(camera)
            applyZoom(camera, AppPrefs.rearZoomRatio(this))
        }
        binding.statusText.text = "Prêt"
        restorePreviewAfterCapture()
    }

    private fun bindLocalDual(provider: ProcessCameraProvider) {
        val pair = findFrontBackPair(provider)
            ?: error("Caméras concurrentes indisponibles")
        val frontPreview = buildStablePreview().also {
            it.setSurfaceProvider(binding.secondaryPreview.surfaceProvider)
        }
        val backPreview = buildStablePreview().also {
            it.setSurfaceProvider(binding.mainPreview.surfaceProvider)
        }
        localPreviews += frontPreview
        localPreviews += backPreview

        val frontGroup = UseCaseGroup.Builder()
            .addUseCase(frontPreview)
            .build()
        val backGroup = UseCaseGroup.Builder()
            .addUseCase(backPreview)
            .build()
        provider.bindToLifecycle(
            listOf(
                ConcurrentCamera.SingleCameraConfig(pair.first.cameraSelector, frontGroup, this),
                ConcurrentCamera.SingleCameraConfig(pair.second.cameraSelector, backGroup, this)
            )
        )
        binding.statusText.text = "Prêt — double aperçu stabilisé"
        restorePreviewAfterCapture()
        scheduleDualPreviewHealthCheck()
    }

    private fun bindLocalPhotoCapture(provider: ProcessCameraProvider) {
        provider.unbindAll()
        localImageCaptures.clear()
        localCameras.clear()
        localPreviews.clear()

        when (selectedCameraMode()) {
            AppPrefs.MODE_DUAL -> {
                val pair = findFrontBackPair(provider)
                    ?: error("Caméras concurrentes indisponibles")
                val frontImage = buildLocalImageCapture(useMaxResolution = false)
                val backImage = buildLocalImageCapture(useMaxResolution = false)
                localImageCaptures[Stream.FRONT] = frontImage
                localImageCaptures[Stream.BACK] = backImage
                provider.bindToLifecycle(
                    listOf(
                        ConcurrentCamera.SingleCameraConfig(
                            pair.first.cameraSelector,
                            UseCaseGroup.Builder().addUseCase(frontImage).build(),
                            this
                        ),
                        ConcurrentCamera.SingleCameraConfig(
                            pair.second.cameraSelector,
                            UseCaseGroup.Builder().addUseCase(backImage).build(),
                            this
                        )
                    )
                )
            }

            AppPrefs.MODE_FRONT -> {
                val image = buildLocalImageCapture(
                    AppPrefs.photoResolution(this) == AppPrefs.PHOTO_RESOLUTION_MAX
                )
                localImageCaptures[Stream.FRONT] = image
                localCameras[Stream.FRONT] = provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_FRONT_CAMERA, image
                )
            }

            else -> {
                val image = buildLocalImageCapture(
                    AppPrefs.photoResolution(this) == AppPrefs.PHOTO_RESOLUTION_MAX
                )
                localImageCaptures[Stream.BACK] = image
                val camera = provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, image
                )
                localCameras[Stream.BACK] = camera
                applyZoom(camera, AppPrefs.rearZoomRatio(this))
            }
        }
    }


    @OptIn(ExperimentalCamera2Interop::class)
    private fun applyExperimentalNightScene(builder: ImageCapture.Builder) {
        runCatching {
            Camera2Interop.Extender(builder)
                .setCaptureRequestOption(
                    CaptureRequest.CONTROL_MODE,
                    CaptureRequest.CONTROL_MODE_USE_SCENE_MODE
                )
                .setCaptureRequestOption(
                    CaptureRequest.CONTROL_SCENE_MODE,
                    CaptureRequest.CONTROL_SCENE_MODE_NIGHT
                )
        }
    }

    private fun findFrontBackPair(provider: ProcessCameraProvider): Pair<CameraInfo, CameraInfo>? {
        provider.availableConcurrentCameraInfos.forEach { infos ->
            val front = infos.firstOrNull { it.lensFacing == CameraSelector.LENS_FACING_FRONT }
            val back = infos.firstOrNull { it.lensFacing == CameraSelector.LENS_FACING_BACK }
            if (front != null && back != null) return front to back
        }
        return null
    }

    private fun takeLocalPhoto() {
        val provider = localProvider
        if (provider == null) {
            localPhotoPending = false
            binding.statusText.text = "La caméra n’est pas encore prête."
            restorePreviewAfterCapture()
            return
        }
        runCatching { bindLocalPhotoCapture(provider) }.onFailure { error ->
            localPhotoPending = false
            binding.statusText.text = "Capture indisponible : ${error.message}"
            restorePreviewAfterCapture()
            bindLocalPreview()
            return
        }

        val targetShots = if (AppPrefs.captureActionMode(this) == AppPrefs.ACTION_MODE_BURST) {
            AppPrefs.burstCount(this)
        } else {
            1
        }
        localBurstSession = LocalBurstSession(
            targetShots = targetShots,
            intervalMs = if (targetShots > 1) AppPrefs.burstIntervalMs(this) else 0L
        )
        captureNextLocalBurstFrame()
    }

    private fun captureNextLocalBurstFrame() {
        val session = localBurstSession ?: return
        if (localImageCaptures.isEmpty()) {
            finishLocalBurst(session.id, "La caméra n’est plus disponible.")
            return
        }

        val frameNumber = session.completedShots + 1
        val frameStartedAt = android.os.SystemClock.elapsedRealtime()
        val remaining = AtomicInteger(localImageCaptures.size)
        val frameErrors = mutableListOf<String>()

        localImageCaptures.forEach { (stream, capture) ->
            val pending = File(cacheDir, "nova_pending").apply { mkdirs() }
            val file = File(
                pending,
                "photo_${stream.name}_R${frameNumber.toString().padStart(2, '0')}_${UUID.randomUUID()}.jpg"
            )
            val callback = object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    lifecycleScope.launch {
                        val active = localBurstSession?.takeIf { it.id == session.id }
                        if (active == null) {
                            file.delete()
                            return@launch
                        }
                        active.pendingSaves += 1
                        completeLocalBurstCapture(
                            session.id,
                            remaining,
                            frameErrors,
                            frameStartedAt
                        )
                        launch {
                            runCatching {
                                withContext(Dispatchers.IO) {
                                    MediaVault(this@MainActivity).addPlainMedia(
                                        plainFile = file,
                                        kind = MEDIA_PHOTO,
                                        camera = if (stream == Stream.FRONT) AppPrefs.MODE_FRONT else AppPrefs.MODE_BACK,
                                        groupId = active.groupId,
                                        folderId = FOLDER_IMAGES
                                    )
                                }
                            }.onSuccess {
                                localBurstSession?.takeIf { it.id == session.id }?.apply { savedCount += 1 }
                            }.onFailure { error ->
                                file.delete()
                                localBurstSession?.takeIf { it.id == session.id }?.errors?.add(
                                    error.message ?: "Échec du chiffrement photo"
                                )
                            }
                            localBurstSession?.takeIf { it.id == session.id }?.let {
                                it.pendingSaves = (it.pendingSaves - 1).coerceAtLeast(0)
                                maybeFinishLocalBurst(it.id)
                            }
                        }
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    synchronized(frameErrors) {
                        frameErrors += exception.message ?: "Échec photo"
                    }
                    file.delete()
                    lifecycleScope.launch {
                        completeLocalBurstCapture(
                            session.id,
                            remaining,
                            frameErrors,
                            frameStartedAt
                        )
                    }
                }
            }

            runCatching {
                capture.takePicture(
                    ImageCapture.OutputFileOptions.Builder(file).build(),
                    cameraExecutor,
                    callback
                )
            }.onFailure { error ->
                file.delete()
                synchronized(frameErrors) {
                    frameErrors += error.message ?: "Impossible de démarrer la capture photo"
                }
                lifecycleScope.launch {
                    completeLocalBurstCapture(
                        session.id,
                        remaining,
                        frameErrors,
                        frameStartedAt
                    )
                }
            }
        }
    }

    private fun completeLocalBurstCapture(
        sessionId: String,
        remaining: AtomicInteger,
        frameErrors: MutableList<String>,
        frameStartedAt: Long
    ) {
        if (remaining.decrementAndGet() != 0) return
        val session = localBurstSession?.takeIf { it.id == sessionId } ?: return
        synchronized(frameErrors) { session.errors += frameErrors }
        session.completedShots += 1

        if (session.completedShots < session.targetShots && !isFinishing && !isDestroyed) {
            binding.statusText.text =
                "Rafale ${session.completedShots}/${session.targetShots} — traitement en arrière-plan"
            val elapsed = android.os.SystemClock.elapsedRealtime() - frameStartedAt
            val remainingDelay = (session.intervalMs - elapsed).coerceAtLeast(0L)
            lifecycleScope.launch {
                delay(remainingDelay)
                if (localBurstSession?.id == sessionId) captureNextLocalBurstFrame()
            }
        } else {
            session.captureSequenceDone = true
            maybeFinishLocalBurst(sessionId)
        }
    }

    private fun maybeFinishLocalBurst(sessionId: String) {
        val session = localBurstSession?.takeIf { it.id == sessionId } ?: return
        if (session.captureSequenceDone && session.pendingSaves == 0) {
            finishLocalBurst(sessionId)
        }
    }

    private fun finishLocalBurst(sessionId: String, fatalError: String? = null) {
        val session = localBurstSession?.takeIf { it.id == sessionId } ?: return
        if (fatalError != null) session.errors += fatalError
        localBurstSession = null
        localPhotoPending = false

        if (session.savedCount > 0) {
            FeedbackController.confirm(this)
            binding.statusText.text = if (session.targetShots > 1) {
                "Rafale terminée — ${session.savedCount} photo(s) enregistrée(s)"
            } else if (session.savedCount == 2) {
                "Deux photos enregistrées"
            } else {
                "Photo enregistrée"
            }
            updateStorageText()
        }
        if (session.errors.isNotEmpty()) {
            val prefix = if (session.savedCount > 0) "Rafale partielle. " else "Capture échouée. "
            binding.statusText.text = prefix + session.errors.distinct().joinToString()
        }
        restorePreviewAfterCapture()
        if (!AppPrefs.serviceActive(this)) bindLocalPreview()
    }

    private fun observeState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                CaptureStateStore.state.collect { renderState(it) }
            }
        }
    }

    private fun observeEvents() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                CaptureEventStore.events.collect { event ->
                    when (event) {
                        is CaptureEvent.PhotoSaved -> {
                            binding.statusText.text = when {
                                event.count > 2 -> "Rafale terminée — ${event.count} photos privées enregistrées"
                                event.count == 2 -> "Deux photos privées enregistrées"
                                else -> "Photo privée enregistrée"
                            }
                            updateStorageText()
                            restorePreviewAfterCapture()
                        }
                        is CaptureEvent.VideoSaved -> {
                            binding.statusText.text = if (event.count == 2) {
                                "Segment ${event.segmentIndex} — deux vidéos enregistrées"
                            } else {
                                "Segment ${event.segmentIndex} enregistré"
                            }
                            updateStorageText()
                        }
                        is CaptureEvent.Error -> {
                            binding.statusText.text = event.message
                            if (CaptureStateStore.state.value !is CaptureState.Recording &&
                                CaptureStateStore.state.value !is CaptureState.Stopping
                            ) {
                                restorePreviewAfterCapture()
                            }
                        }
                    }
                }
            }
        }
    }

    private fun renderState(state: CaptureState) {
        suppressArmListener = true
        binding.armSwitch.isChecked = AppPrefs.serviceActive(this)
        suppressArmListener = false

        updateControlAvailability(state)
        binding.armSwitch.isEnabled = state !is CaptureState.Starting && state !is CaptureState.Stopping
        binding.discreetScreenButton.isEnabled = AppPrefs.serviceActive(this) &&
            state !is CaptureState.Starting && state !is CaptureState.Stopping
        binding.discreetScreenButton.alpha = if (binding.discreetScreenButton.isEnabled) 1f else 0.42f

        binding.statusText.text = when (state) {
            CaptureState.Idle -> "Prêt"
            CaptureState.Starting -> "Activation de Nova…"
            is CaptureState.Armed -> "Raccourcis externes actifs — ${if (AppPrefs.captureMode(this) == AppPrefs.CAPTURE_VIDEO) "vidéo" else "photo"}"
            is CaptureState.Recording -> {
                "Vidéo ${formatDuration(state.sessionDurationMs)} • segment ${state.segmentIndex} (${formatDuration(state.segmentDurationMs)}) • ${formatBytes(state.bytes)}"
            }
            CaptureState.Stopping -> "Finalisation et chiffrement…"
            is CaptureState.PhotoSaved -> "${state.count} photo(s) enregistrée(s)"
            is CaptureState.Error -> "Erreur : ${state.message}"
        }
        updateCaptureButton(state)

        when (state) {
            is CaptureState.Recording -> {
                suppressPreviewForCapture(
                    "Vidéo active\n${formatDuration(state.sessionDurationMs)} — segment ${state.segmentIndex}",
                    showProgress = false
                )
            }
            CaptureState.Starting -> suppressPreviewForCapture("Activation du service…", true)
            CaptureState.Stopping -> suppressPreviewForCapture("Finalisation de la vidéo…", true)
            is CaptureState.Armed -> restorePreviewAfterCapture()
            CaptureState.Idle -> {
                restorePreviewAfterCapture()
                if (!localPhotoPending) requestCameraPermissionForPreview()
            }
            else -> Unit
        }
    }

    private fun updateCaptureButton(state: CaptureState) {
        if (AppPrefs.captureMode(this) == AppPrefs.CAPTURE_VIDEO) {
            val recordingNow = state is CaptureState.Recording || state is CaptureState.Stopping ||
                AppPrefs.recordingActive(this)
            binding.captureButton.text = if (recordingNow) "Arrêter la vidéo" else "Démarrer la vidéo"
            binding.captureButton.backgroundTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this, if (recordingNow) R.color.nova_error else R.color.nova_green)
            )
        } else {
            val actionMode = AppPrefs.captureActionMode(this)
            val burstCount = if (actionMode == AppPrefs.ACTION_MODE_BURST) AppPrefs.burstCount(this) else 1
            binding.captureButton.text = when {
                delayedLocalActionJob?.isActive == true -> "Annuler le retardateur"
                actionMode == AppPrefs.ACTION_MODE_DELAYED -> "Prendre une photo retardée"
                burstCount > 1 -> "Prendre une rafale ($burstCount)"
                else -> "Prendre une photo"
            }
            binding.captureButton.backgroundTintList = ColorStateList.valueOf(
                ContextCompat.getColor(this, R.color.nova_green)
            )
        }
    }

    private fun configureZoomButtonsFromCamera(camera: Camera) {
        val zoomLiveData = camera.cameraInfo.zoomState
        val current = zoomLiveData.value
        if (current != null) {
            configureZoomButtons(current.minZoomRatio, current.maxZoomRatio)
            applyZoom(camera, AppPrefs.rearZoomRatio(this))
            return
        }

        binding.zoomCapabilityText.text = "Objectifs arrière : initialisation…"
        zoomLiveData.observe(this) { state ->
            if (state != null) {
                zoomLiveData.removeObservers(this)
                configureZoomButtons(state.minZoomRatio, state.maxZoomRatio)
                applyZoom(camera, AppPrefs.rearZoomRatio(this))
            }
        }
    }

    private fun configureZoomButtons(minZoom: Float, maxZoom: Float) {
        rearMinZoom = minZoom
        rearMaxZoom = maxZoom
        rearZoomCapabilitiesKnown = true

        fun supported(ratio: Float): Boolean =
            ratio >= rearMinZoom - 0.02f && ratio <= rearMaxZoom + 0.02f

        val available = buildList {
            if (supported(0.6f)) add("0,6×")
            if (supported(1f)) add("1×")
            if (supported(3f)) add("3×")
            if (supported(5f)) add("5×")
        }
        binding.zoomCapabilityText.text = if (available.isEmpty()) {
            "Plage de zoom exposée : %.1f× à %.1f×".format(Locale.FRANCE, minZoom, maxZoom)
        } else {
            "Objectifs/zooms disponibles : ${available.joinToString("  ")}"
        }

        val requested = AppPrefs.rearZoomRatio(this)
        if (!supported(requested)) {
            val fallback = when {
                supported(1f) -> 1f
                supported(0.6f) -> 0.6f
                supported(3f) -> 3f
                supported(5f) -> 5f
                else -> minZoom.coerceIn(minZoom, maxZoom)
            }
            AppPrefs.setRearZoomRatio(this, fallback)
            when (fallback) {
                0.6f -> binding.zoomToggle.check(R.id.zoom06Button)
                3f -> binding.zoomToggle.check(R.id.zoom3Button)
                5f -> binding.zoomToggle.check(R.id.zoom5Button)
                else -> binding.zoomToggle.check(R.id.zoom1Button)
            }
        }
        updateControlAvailability(CaptureStateStore.state.value)
    }

    private fun updateControlAvailability(state: CaptureState) {
        val configurable = state is CaptureState.Idle || state is CaptureState.Armed
        binding.cameraToggle.isEnabled = configurable
        binding.backButton.isEnabled = configurable
        binding.frontButton.isEnabled = configurable
        binding.dualButton.isEnabled = configurable && dualCameraAvailable
        binding.modeToggle.isEnabled = configurable
        binding.photoModeButton.isEnabled = configurable
        binding.videoModeButton.isEnabled = configurable

        val zoomConfigurable = configurable && selectedCameraMode() == AppPrefs.MODE_BACK
        fun supported(ratio: Float): Boolean = !rearZoomCapabilitiesKnown ||
            (ratio >= rearMinZoom - 0.02f && ratio <= rearMaxZoom + 0.02f)
        binding.zoomToggle.isEnabled = zoomConfigurable
        binding.zoom06Button.isEnabled = zoomConfigurable && supported(0.6f)
        binding.zoom1Button.isEnabled = zoomConfigurable && supported(1f)
        binding.zoom3Button.isEnabled = zoomConfigurable && supported(3f)
        binding.zoom5Button.isEnabled = zoomConfigurable && supported(5f)
    }

    private fun applyZoom(camera: Camera, requestedRatio: Float) {
        val zoomLiveData = camera.cameraInfo.zoomState
        val current = zoomLiveData.value
        if (current == null) {
            zoomLiveData.observe(this) { state ->
                if (state != null) {
                    zoomLiveData.removeObservers(this)
                    applyZoomWithRange(camera, requestedRatio, state.minZoomRatio, state.maxZoomRatio)
                }
            }
            return
        }
        applyZoomWithRange(camera, requestedRatio, current.minZoomRatio, current.maxZoomRatio)
    }

    private fun applyZoomWithRange(
        camera: Camera,
        requestedRatio: Float,
        minZoom: Float,
        maxZoom: Float
    ) {
        val ratio = requestedRatio.coerceIn(minZoom, maxZoom)
        camera.cameraControl.setZoomRatio(ratio).addListener({
            if (::binding.isInitialized && selectedCameraMode() == AppPrefs.MODE_BACK) {
                binding.previewBadge.text = "ARRIÈRE • %.1f×".format(Locale.FRANCE, ratio)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun updatePreviewLayout() {
        val mode = selectedCameraMode()
        binding.secondaryPreview.visibility = if (mode == AppPrefs.MODE_DUAL) View.VISIBLE else View.GONE
        binding.zoomSection.visibility = if (mode == AppPrefs.MODE_BACK) View.VISIBLE else View.GONE
        binding.previewBadge.text = when (mode) {
            AppPrefs.MODE_FRONT -> "AVANT"
            AppPrefs.MODE_DUAL -> "ARRIÈRE + AVANT"
            else -> "ARRIÈRE • %.1f×".format(Locale.FRANCE, AppPrefs.rearZoomRatio(this))
        }
        updateControlAvailability(CaptureStateStore.state.value)
        attachServicePreviewProviders()
    }

    private fun suppressPreviewForCapture(message: String, showProgress: Boolean) {
        previewSuppressed = true
        PreviewBridge.attachProviders(null, null)
        binding.previewCoverText.text = message
        binding.previewCoverProgress.visibility = if (showProgress) View.VISIBLE else View.GONE
        binding.previewCover.visibility = View.VISIBLE
        binding.previewBadge.visibility = View.GONE
    }

    private fun restorePreviewAfterCapture() {
        if (!::binding.isInitialized) return
        val state = CaptureStateStore.state.value
        if (state is CaptureState.Recording || state is CaptureState.Stopping || state is CaptureState.Starting) {
            return
        }
        previewSuppressed = false
        binding.previewCover.visibility = View.GONE
        binding.previewBadge.visibility = View.VISIBLE
        if (AppPrefs.serviceActive(this)) {
            attachServicePreviewProviders()
        }
    }

    private fun attachServicePreviewProviders() {
        if (!::binding.isInitialized || !AppPrefs.serviceActive(this) || previewSuppressed) return
        if (CaptureStateStore.state.value is CaptureState.Recording ||
            CaptureStateStore.state.value is CaptureState.Stopping
        ) return
        when (selectedCameraMode()) {
            AppPrefs.MODE_FRONT -> PreviewBridge.attachProviders(
                back = null,
                front = binding.mainPreview.surfaceProvider
            )
            AppPrefs.MODE_DUAL -> {
                PreviewBridge.attachProviders(
                    back = binding.mainPreview.surfaceProvider,
                    front = binding.secondaryPreview.surfaceProvider
                )
                scheduleDualPreviewHealthCheck()
            }
            else -> PreviewBridge.attachProviders(
                back = binding.mainPreview.surfaceProvider,
                front = null
            )
        }
    }

    private fun scheduleDualPreviewHealthCheck() {
        dualPreviewCheckJob?.cancel()
        if (selectedCameraMode() != AppPrefs.MODE_DUAL || previewSuppressed) return
        dualPreviewCheckJob = lifecycleScope.launch {
            delay(2_500L)
            if (!::binding.isInitialized || selectedCameraMode() != AppPrefs.MODE_DUAL || previewSuppressed) {
                return@launch
            }
            val backStreaming = binding.mainPreview.previewStreamState.value == PreviewView.StreamState.STREAMING
            val frontStreaming = binding.secondaryPreview.previewStreamState.value == PreviewView.StreamState.STREAMING
            if (backStreaming && frontStreaming) {
                dualPreviewRecoveryAttempts = 0
                return@launch
            }
            if (dualPreviewRecoveryAttempts >= 2) {
                binding.statusText.text = "Double aperçu instable — change de caméra puis reviens sur Double"
                return@launch
            }
            dualPreviewRecoveryAttempts += 1
            binding.statusText.text = "Relance du double aperçu…"
            PreviewBridge.attachProviders(null, null)
            delay(180L)
            if (AppPrefs.serviceActive(this@MainActivity)) {
                startCaptureService(CaptureService.ACTION_RECONFIGURE)
            } else {
                bindLocalPreview()
            }
        }
    }

    private fun updateStorageText() {
        val count = MediaVault(this).list().size
        binding.storageText.text = "$count média${if (count > 1) "s" else ""}"
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN &&
            event.action == KeyEvent.ACTION_DOWN &&
            event.repeatCount == 0 &&
            AppPrefs.serviceActive(this) &&
            CaptureStateStore.state.value !is CaptureState.Starting &&
            CaptureStateStore.state.value !is CaptureState.Stopping
        ) {
            triggerSelectedAction()
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun formatDuration(durationMs: Long): String {
        val totalSeconds = durationMs / 1_000
        val hours = totalSeconds / 3_600
        val minutes = (totalSeconds % 3_600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format(Locale.FRANCE, "%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.FRANCE, "%02d:%02d", minutes, seconds)
        }
    }

    private fun formatBytes(bytes: Long): String =
        String.format(Locale.FRANCE, "%.1f Mo", bytes / (1024.0 * 1024.0))

    override fun onDestroy() {
        localBurstSession = null
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}
