package fr.doudou.nova

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class NovaWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        appWidgetIds.forEach { id -> WidgetUpdater.update(context, appWidgetManager, id) }
    }

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        WidgetUpdater.updateAll(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action != ACTION_WIDGET_PRIMARY) return

        if (!AppPrefs.serviceActive(context)) {
            openQuickCapture(context)
            return
        }

        val serviceIntent = Intent(context, CaptureService::class.java).apply {
            action = when (AppPrefs.captureMode(context)) {
                AppPrefs.CAPTURE_VIDEO -> if (AppPrefs.recordingActive(context)) {
                    CaptureService.ACTION_STOP_RECORDING
                } else {
                    CaptureService.ACTION_START_RECORDING
                }
                else -> CaptureService.ACTION_TAKE_PHOTO
            }
        }
        runCatching { context.startService(serviceIntent) }
        WidgetUpdater.updateAll(context)
    }

    private fun openQuickCapture(context: Context) {
        val openIntent = Intent(context, GateActivity::class.java).apply {
            putExtra(GateActivity.EXTRA_DESTINATION, GateActivity.DESTINATION_QUICK)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            context,
            903,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        runCatching { pending.send() }
    }

    companion object {
        const val ACTION_WIDGET_PRIMARY = "fr.doudou.nova.action.WIDGET_PRIMARY"
    }
}

object WidgetUpdater {
    fun updateAll(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val component = ComponentName(context, NovaWidgetProvider::class.java)
        manager.getAppWidgetIds(component).forEach { update(context, manager, it) }
    }

    fun update(context: Context, manager: AppWidgetManager, widgetId: Int) {
        val active = AppPrefs.serviceActive(context)
        val videoMode = AppPrefs.captureMode(context) == AppPrefs.CAPTURE_VIDEO
        val views = RemoteViews(context.packageName, R.layout.widget_nova)

        // Le widget reste volontairement neutre : seulement P ou V et un point d’état.
        views.setTextViewText(R.id.widgetMode, if (videoMode) "V" else "P")
        views.setImageViewResource(
            R.id.widgetStateDot,
            if (active) R.drawable.widget_dot_active else R.drawable.widget_dot_inactive
        )

        val clickIntent = Intent(context, NovaWidgetProvider::class.java).apply {
            action = NovaWidgetProvider.ACTION_WIDGET_PRIMARY
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            7000 + widgetId,
            clickIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widgetRoot, pendingIntent)
        manager.updateAppWidget(widgetId, views)
    }
}
