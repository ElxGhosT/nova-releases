package fr.doudou.nova

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.FrameLayout
import kotlin.math.max
import kotlin.math.min

/**
 * Conteneur zoomable stable pour photos et PlayerView.
 * Une fois zoomé, le conteneur intercepte le geste dès ACTION_DOWN afin que
 * chaque nouveau déplacement reparte de la vraie position du doigt, sans saut
 * ni recentrage du média.
 */
class ZoomableFrameLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    private var scale = 1f
    private var translationXValue = 0f
    private var translationYValue = 0f
    private var lastX = 0f
    private var lastY = 0f

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val child = getChildAt(0) ?: return false
                val previous = scale
                val next = (previous * detector.scaleFactor).coerceIn(MIN_SCALE, MAX_SCALE)
                if (next == previous) return true

                // Conserve le point situé sous les doigts au même endroit à l'écran.
                val factor = next / previous
                translationXValue = detector.focusX - width / 2f +
                    (translationXValue - (detector.focusX - width / 2f)) * factor
                translationYValue = detector.focusY - height / 2f +
                    (translationYValue - (detector.focusY - height / 2f)) * factor
                scale = next
                applyTransform(child)
                return true
            }
        }
    )

    fun currentScale(): Float = scale

    fun isZoomed(): Boolean = scale > 1.02f

    fun resetZoom() {
        scale = 1f
        translationXValue = 0f
        translationYValue = 0f
        getChildAt(0)?.let(::applyTransform)
    }

    fun toggleDoubleTapZoom() {
        val child = getChildAt(0) ?: return
        if (isZoomed()) {
            resetZoom()
        } else {
            scale = 2f
            translationXValue = 0f
            translationYValue = 0f
            applyTransform(child)
        }
    }

    override fun onInterceptTouchEvent(event: MotionEvent): Boolean {
        // Nourrit le détecteur dès le premier doigt pour qu'un pincement commencé
        // à l'échelle 1 ne perde pas son ACTION_DOWN.
        scaleDetector.onTouchEvent(event)
        if (event.actionMasked == MotionEvent.ACTION_DOWN) {
            lastX = event.x
            lastY = event.y
        }
        return isZoomed() || event.pointerCount > 1 || scaleDetector.isInProgress
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val child = getChildAt(0) ?: return false
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                parent?.requestDisallowInterceptTouchEvent(isZoomed())
            }

            MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_POINTER_UP -> {
                lastX = centroidX(event)
                lastY = centroidY(event)
                parent?.requestDisallowInterceptTouchEvent(true)
            }

            MotionEvent.ACTION_MOVE -> {
                if (!scaleDetector.isInProgress && isZoomed() && event.pointerCount == 1) {
                    val dx = event.x - lastX
                    val dy = event.y - lastY
                    translationXValue += dx
                    translationYValue += dy
                    applyTransform(child)
                }
                lastX = if (event.pointerCount > 1) centroidX(event) else event.x
                lastY = if (event.pointerCount > 1) centroidY(event) else event.y
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }

    private fun centroidX(event: MotionEvent): Float {
        var sum = 0f
        for (index in 0 until event.pointerCount) sum += event.getX(index)
        return sum / event.pointerCount.coerceAtLeast(1)
    }

    private fun centroidY(event: MotionEvent): Float {
        var sum = 0f
        for (index in 0 until event.pointerCount) sum += event.getY(index)
        return sum / event.pointerCount.coerceAtLeast(1)
    }

    private fun applyTransform(child: android.view.View) {
        clampTranslations(child)
        child.pivotX = width / 2f
        child.pivotY = height / 2f
        child.scaleX = scale
        child.scaleY = scale
        child.translationX = translationXValue
        child.translationY = translationYValue
    }

    private fun clampTranslations(child: android.view.View) {
        val maxX = max(0f, (child.width * (scale - 1f)) / 2f)
        val maxY = max(0f, (child.height * (scale - 1f)) / 2f)
        translationXValue = min(max(translationXValue, -maxX), maxX)
        translationYValue = min(max(translationYValue, -maxY), maxY)
        if (!isZoomed()) {
            translationXValue = 0f
            translationYValue = 0f
        }
    }

    companion object {
        private const val MIN_SCALE = 1f
        private const val MAX_SCALE = 5f
    }
}
