# Contrôles effectués — Nova 0.9.0

- XML des deux projets analysés sans erreur de syntaxe.
- Références locales de couleurs, chaînes, drawables, layouts, mipmaps et XML vérifiées.
- Propriétés ViewBinding comparées aux identifiants des layouts.
- Délimiteurs Kotlin contrôlés sur tous les fichiers.
- `versionCode 17` et `versionName 0.9.0` vérifiés.
- Chiffrement du serveur Nova Camera et déchiffrement du client Nova testés ensemble sur une trame de 1 024 octets.
- Le serveur local et sa classe de chiffrement compilent avec le compilateur Kotlin/JVM.
- Test de bout en bout du serveur local : réponse 200 et déchiffrement correct avec le bon code ; réponse 401 avec un mauvais code.
- Aucun SDK Android n’est présent dans l’environnement de génération : la compilation APK et les tests CameraX restent à effectuer dans Android Studio.
