# Contrôles Nova v0.9.4

- Vérifier l’ouverture de **Réglages → Mises à jour GitHub**.
- Enregistrer une adresse GitHub Pages HTTPS.
- Vérifier le chargement de `nova.json` et `nova-support.json`.
- Vérifier le QR de Nova Support.
- Tester le téléchargement avec progression.
- Modifier volontairement le SHA-256 dans un JSON et confirmer le blocage.
- Tester un APK d’un autre package et confirmer le blocage.
- Tester un APK signé avec une autre clé et confirmer le blocage.
- Autoriser l’installation depuis Nova, puis confirmer que l’installateur Android s’ouvre.
- Vérifier que le fonctionnement caméra local reste inchangé.
