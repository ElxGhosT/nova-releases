# Contrôles Nova v0.9.3

## Contrôles structurels réalisés

- Validation XML de toutes les ressources Android.
- Vérification des IDs ViewBinding du lecteur et de l’écran Nova Support.
- Vérification de l’équilibre des blocs Kotlin modifiés.
- Version passée à `0.9.3` (`versionCode 20`).
- Aucun changement du protocole réseau Nova Support : compatibilité v0.2.0 conservée.

## Essais recommandés sur téléphone

1. Ouvrir un dossier contenant plusieurs médias et utiliser la bande de miniatures.
2. Vérifier que la miniature sélectionnée suit les swipes précédent/suivant.
3. Tourner une photo et une vidéo à `90°`, `180°`, `270°`, puis revenir à `0°`.
4. Tourner physiquement le téléphone avec l’orientation déverrouillée.
5. Verrouiller l’orientation actuelle, tourner le téléphone, puis déverrouiller.
6. Combiner rotation du média, zoom pincé et déplacement dans le média.
7. Connecter Nova Support v0.2.0, enregistrer une photo distante et vérifier le coffre.
8. Lancer une rafale distante et vérifier le regroupement et le nombre de photos.
9. Couper le Wi-Fi ou sortir du réseau local et vérifier que la connexion échoue sans accès extérieur.
