@echo off
setlocal
if "%~1"=="" (
  echo Utilisation : INTEGRER_NOVA_SUPPORT.cmd chemin\vers\Nova-Support.apk
  exit /b 1
)
if not exist "%~1" (
  echo APK introuvable : %~1
  exit /b 1
)
copy /Y "%~1" "%~dp0app\src\main\assets\nova-support.apk" >nul
if errorlevel 1 exit /b 1
echo APK Nova Support integre dans le projet Nova.
