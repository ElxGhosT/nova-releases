# Contrôles Nova Support v0.4.0

- Version 0.4.0 (versionCode 4).
- Dépendance CameraX Video ajoutée.
- Permissions microphone et service au premier plan déclarées.
- Protocole binaire v2 authentifié/chiffré.
- Transfert vidéo fractionné en blocs de 1 Mio.
- Ressources XML analysées.

Tests réels nécessaires : verrouillage écran, optimisation batterie, qualité FHD/HD, audio et segmentation.
