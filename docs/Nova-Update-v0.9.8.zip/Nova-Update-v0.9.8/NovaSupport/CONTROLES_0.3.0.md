# Contrôles Nova Support v0.3.0

- Ouvrir le bouton **Rechercher une mise à jour**.
- Enregistrer l’adresse GitHub Pages.
- Vérifier `nova-support.json`.
- Télécharger un APK valide et confirmer l’ouverture de l’installateur Android.
- Tester le blocage SHA-256, package et certificat.
- Vérifier que la caméra, le QR d’appairage et le protocole local fonctionnent comme en v0.2.0.
