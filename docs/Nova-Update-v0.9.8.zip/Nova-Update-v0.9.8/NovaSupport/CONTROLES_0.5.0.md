# Contrôles Nova Support v0.5.0

## Modifications

- Ajout du **Réseau direct Nova** via LocalOnlyHotspot.
- QR d’appairage v2 regroupant réseau Wi-Fi direct et secret Nova.
- Redémarrage du serveur local sur l’interface du point d’accès.
- Notification neutre : « Nova Support · service activé » / « Services Wi-Fi activés ».
- Masquage de l’aperçu local dès qu’un client Nova authentifié reçoit le flux.
- Réaffichage automatique de l’aperçu après déconnexion de Nova.
- Acceptation des clients IPv4 privés joignables, même sur un sous-réseau domestique différent.
- Ajout des autorisations Wi-Fi de proximité compatibles Android 13+.

## Tests recommandés

1. Créer puis arrêter le Réseau direct Nova.
2. Vérifier le SSID et le QR générés.
3. Connecter Nova et vérifier que l’aperçu disparaît du téléphone-support.
4. Déconnecter Nova et vérifier que l’aperçu local revient.
5. Verrouiller l’écran du téléphone-support après activation et tester photo/vidéo distante.
