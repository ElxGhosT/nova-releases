# Validation Nova Support 0.2.0

## Installation

- [ ] Compilation Android Studio sans erreur.
- [ ] Android affiche le nom **Nova Support** et la version `0.2.0`.
- [ ] Le package installé est `fr.doudou.novasupport`.
- [ ] Les autorisations Caméra et Notifications sont accordées.

## Caméra et QR

- [ ] Le bouton Démarrer lance une notification permanente.
- [ ] L’adresse locale utilise le port 8787.
- [ ] Le secret contient 20 caractères.
- [ ] Le QR code est net et scannable depuis Nova 0.9.1.
- [ ] Générer un nouveau code met immédiatement à jour le QR.
- [ ] L’aperçu arrière fonctionne.
- [ ] Le passage à la caméra avant fonctionne.
- [ ] Le flux continue lorsque l’activité passe en arrière-plan.
- [ ] L’arrêt depuis l’application et depuis la notification libère la caméra.

## Sécurité réseau

- [ ] Un navigateur ouvert sur l’adresse et le port ne reçoit aucune page Web.
- [ ] Le bon QR permet à Nova de recevoir les images.
- [ ] Un mauvais secret est refusé.
- [ ] Une requête provenant d’un autre sous-réseau est refusée.
- [ ] Le service ne démarre pas sans adresse Wi-Fi privée.
- [ ] La coupure puis le retour du Wi-Fi sont gérés sans plantage.
- [ ] Aucune redirection de port ni règle UPnP n’est créée.
