# Nova Support 0.2.0 — téléphone-support

Application séparée destinée au téléphone qui sert de caméra locale visible pour Nova.

## Fonctionnement

1. Installer Nova Support sur le téléphone-support.
2. Connecter les deux téléphones au même Wi-Fi privé.
3. Choisir la caméra arrière ou avant.
4. Appuyer sur **Démarrer**.
5. Dans Nova 0.9.1, ouvrir **Caméra support** puis **Scanner le QR code**.
6. Scanner le QR affiché par Nova Support.

La notification Android permanente et l’indicateur système de caméra restent visibles pendant l’utilisation.

## Sécurité

- aucun serveur HTTP ;
- aucune page Web accessible ;
- socket TCP lié uniquement à l’adresse IPv4 du Wi-Fi privé ;
- refus des clients hors du sous-réseau local ;
- secret d’appairage aléatoire de 20 caractères ;
- secret stocké via une clé non exportable de l’Android Keystore ;
- authentification HMAC-SHA-256 avec nonce aléatoire ;
- chiffrement AES-256-GCM de chaque image ;
- aucune activation automatique au démarrage ;
- aucune ouverture de port, aucun cloud et aucune connexion extérieure.

Le QR code contient le secret d’appairage. Il doit donc être scanné uniquement par le téléphone principal de confiance.

## Installation depuis Nova

Nova peut partager un APK signé de Nova Support via la feuille de partage Android, avec Partage à proximité, Bluetooth ou un autre moyen local. Un QR code seul ne peut pas transporter un APK complet sans pointer vers un serveur de téléchargement ; cette méthode n’est donc pas utilisée.

## Limites actuelles

- une seule caméra active à la fois ;
- environ trois images par seconde ;
- même Wi-Fi privé requis ;
- pas encore d’audio, de déclenchement photo distant ni de connexion de plusieurs téléphones-supports ;
- compilation et essais physiques nécessaires dans Android Studio.

## Réseau direct et widget (v0.5.1)

Quand le Réseau direct Nova est actif, Nova Support affiche maintenant le nom du réseau AndroidShare, le mot de passe, un bouton de copie et un QR Wi-Fi standard. Scanne d’abord ce QR avec l’appareil photo du téléphone principal, puis scanne le QR d’appairage dans Nova.

Le widget **Nova Support** peut être ajouté depuis le sélecteur de widgets Android. Il reste volontairement gris. Un appui coupe le point d’accès local et arrête tous les services Nova Support.

## Nova Support v0.5.2 — photos originales et autonomie

- Capture photo haute résolution à distance.
- Serveur local maintenu lors d’un changement avant/arrière.
- Vidéo autonome pendant une coupure de liaison avec Nova.
- Détection de mouvement simple sans pré-enregistrement.
- Arrêt complet ou relance réseau commandables depuis Nova.
