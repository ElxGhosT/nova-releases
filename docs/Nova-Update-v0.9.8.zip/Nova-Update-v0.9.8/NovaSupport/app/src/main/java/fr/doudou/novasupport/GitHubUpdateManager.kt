package fr.doudou.novasupport

import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Locale

data class GitHubUpdateInfo(
    val packageName: String,
    val versionCode: Long,
    val versionName: String,
    val apkUrl: String,
    val sha256: String,
    val certificateSha256: String,
    val mandatory: Boolean,
    val notes: List<String>,
    val pageUrl: String?
)

class GitHubUpdateManager(private val context: Context) {

    fun fetchInfo(url: String): GitHubUpdateInfo {
        requireHttps(url)
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 20_000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "Nova-Support-Update/${BuildConfig.VERSION_NAME}")
        }
        return try {
            require(connection.responseCode in 200..299) {
                "Serveur de mise à jour indisponible (${connection.responseCode})."
            }
            parseInfo(JSONObject(connection.inputStream.bufferedReader().use { it.readText() }))
        } finally {
            connection.disconnect()
        }
    }

    fun download(info: GitHubUpdateInfo, progress: (Long, Long) -> Unit): File {
        requireHttps(info.apkUrl)
        val targetDir = File(context.cacheDir, "nova_updates").apply { mkdirs() }
        val target = File(targetDir, "Nova-Support-${info.versionName}.apk")
        val partial = File(targetDir, "${target.name}.part")
        partial.delete()
        val connection = (URL(info.apkUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 60_000
            requestMethod = "GET"
            instanceFollowRedirects = true
            setRequestProperty("Accept", "application/vnd.android.package-archive,application/octet-stream")
            setRequestProperty("User-Agent", "Nova-Support-Update/${BuildConfig.VERSION_NAME}")
        }
        try {
            require(connection.responseCode in 200..299) {
                "Téléchargement refusé (${connection.responseCode})."
            }
            val total = connection.contentLengthLong
            connection.inputStream.use { input ->
                partial.outputStream().buffered().use { output ->
                    val buffer = ByteArray(128 * 1024)
                    var downloaded = 0L
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        output.write(buffer, 0, read)
                        downloaded += read
                        progress(downloaded, total)
                    }
                }
            }
            if (target.exists()) target.delete()
            require(partial.renameTo(target)) { "Impossible de finaliser le fichier téléchargé." }
            return target
        } catch (error: Throwable) {
            partial.delete()
            throw error
        } finally {
            connection.disconnect()
        }
    }

    fun verify(info: GitHubUpdateInfo, apk: File): File {
        require(sha256(apk).equals(normalize(info.sha256), ignoreCase = true)) {
            "L’empreinte SHA-256 de l’APK ne correspond pas."
        }
        val packageInfo = archivePackageInfo(apk) ?: error("Android ne reconnaît pas cet APK.")
        require(packageInfo.packageName == context.packageName && packageInfo.packageName == info.packageName) {
            "Package Nova Support inattendu."
        }
        require(packageInfo.longVersionCodeCompat() == info.versionCode) {
            "Numéro de version APK inattendu."
        }
        val expectedCertificate = normalize(info.certificateSha256)
        require(expectedCertificate.isNotBlank()) { "Certificat attendu absent du manifeste." }
        require(signingCertificateDigests(packageInfo).any { it.equals(expectedCertificate, true) }) {
            "La signature de l’APK ne correspond pas au certificat Nova."
        }
        return apk
    }

    fun installIntent(apk: File): Intent {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", apk)
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    private fun parseInfo(json: JSONObject): GitHubUpdateInfo {
        val notesJson = json.optJSONArray("releaseNotes")
        val notes = buildList {
            if (notesJson != null) {
                for (index in 0 until notesJson.length()) {
                    notesJson.optString(index).takeIf { it.isNotBlank() }?.let(::add)
                }
            }
        }
        return GitHubUpdateInfo(
            packageName = json.getString("packageName"),
            versionCode = json.getLong("versionCode"),
            versionName = json.getString("versionName"),
            apkUrl = json.getString("apkUrl"),
            sha256 = json.getString("sha256"),
            certificateSha256 = json.getString("certificateSha256"),
            mandatory = json.optBoolean("mandatory", false),
            notes = notes,
            pageUrl = json.optString("pageUrl").takeIf { it.isNotBlank() }
        )
    }

    private fun archivePackageInfo(apk: File): PackageInfo? = if (Build.VERSION.SDK_INT >= 33) {
        context.packageManager.getPackageArchiveInfo(
            apk.absolutePath,
            PackageManager.PackageInfoFlags.of(PackageManager.GET_SIGNING_CERTIFICATES.toLong())
        )
    } else {
        @Suppress("DEPRECATION")
        context.packageManager.getPackageArchiveInfo(apk.absolutePath, PackageManager.GET_SIGNING_CERTIFICATES)
    }

    private fun signingCertificateDigests(info: PackageInfo): List<String> {
        val signers = info.signingInfo?.apkContentsSigners?.toList().orEmpty()
        return signers.map { signature ->
            MessageDigest.getInstance("SHA-256").digest(signature.toByteArray())
                .joinToString("") { "%02x".format(Locale.ROOT, it) }
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(128 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(Locale.ROOT, it) }
    }

    private fun normalize(value: String): String = value.trim().replace(":", "").lowercase(Locale.ROOT)

    private fun requireHttps(value: String) {
        require(Uri.parse(value).scheme.equals("https", true)) {
            "Seules les adresses HTTPS sont autorisées."
        }
    }

    private fun PackageInfo.longVersionCodeCompat(): Long = if (Build.VERSION.SDK_INT >= 28) {
        longVersionCode
    } else {
        @Suppress("DEPRECATION")
        versionCode.toLong()
    }
}
