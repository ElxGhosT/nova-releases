package fr.doudou.novasupport

import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference

/**
 * Serveur binaire local : aucune route HTTP, aucune page Web et aucune écoute
 * sur l'interface mobile. Le socket est lié uniquement à l'adresse Wi-Fi privée.
 */
class LocalFrameServer(
    private val network: LocalNetworkInfo,
    private val codeProvider: () -> String,
    private val commandHandler: RemoteCommandHandler,
    private val onError: (String) -> Unit = {}
) {
    private val latestFrame = AtomicReference<ByteArray?>(null)
    private var clientExecutor = Executors.newFixedThreadPool(MAX_CLIENTS)
    private var acceptThread: Thread? = null
    @Volatile private var running = false
    @Volatile private var serverSocket: ServerSocket? = null

    fun start() {
        if (running) return
        if (clientExecutor.isShutdown) clientExecutor = Executors.newFixedThreadPool(MAX_CLIENTS)
        try {
            val socket = ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(network.address, PORT), 4)
            }
            serverSocket = socket
            running = true
            acceptThread = Thread({ acceptLoop(socket) }, "NovaSupport-LocalSocket").apply {
                isDaemon = true
                start()
            }
        } catch (error: Throwable) {
            running = false
            serverSocket = null
            onError(error.message ?: "Liaison locale indisponible")
        }
    }

    fun isRunning(): Boolean = running
    fun boundHostAddress(): String = network.hostAddress
    fun updateFrame(jpeg: ByteArray) = latestFrame.set(jpeg.copyOf())
    fun hasFrame(): Boolean = latestFrame.get() != null

    fun stop() {
        running = false
        runCatching { serverSocket?.close() }
        serverSocket = null
        acceptThread?.interrupt()
        acceptThread = null
        latestFrame.set(null)
        clientExecutor.shutdownNow()
        NodeClientStore.reset()
    }

    private fun acceptLoop(socket: ServerSocket) {
        try {
            socket.use { server ->
                while (running) {
                    val client = runCatching { server.accept() }.getOrNull() ?: break
                    clientExecutor.execute { handleClient(client) }
                }
            }
        } finally {
            serverSocket = null
            running = false
        }
    }

    private fun handleClient(socket: Socket) {
        socket.use { client ->
            client.soTimeout = 7_500
            if (!network.contains(client.inetAddress)) {
                writeResponse(client, NodeProtocol.STATUS_FORBIDDEN, ByteArray(0))
                return
            }
            val input = DataInputStream(client.getInputStream())
            val magic = runCatching { input.readInt() }.getOrNull()
            if (magic != NodeProtocol.MAGIC) {
                writeResponse(client, NodeProtocol.STATUS_BAD_REQUEST, ByteArray(0))
                return
            }
            val version = input.readUnsignedByte()
            val command = input.readUnsignedByte()
            val nonceLength = input.readUnsignedByte()
            if (version != NodeProtocol.VERSION || nonceLength != NodeProtocol.NONCE_BYTES) {
                writeResponse(client, NodeProtocol.STATUS_BAD_REQUEST, ByteArray(0))
                return
            }
            val nonce = ByteArray(nonceLength).also(input::readFully)
            val requestLength = input.readInt()
            if (requestLength !in 0..NodeProtocol.MAX_REQUEST_BYTES) {
                writeResponse(client, NodeProtocol.STATUS_BAD_REQUEST, ByteArray(0))
                return
            }
            val requestPayload = ByteArray(requestLength).also(input::readFully)
            val authLength = input.readUnsignedByte()
            if (authLength != NodeProtocol.AUTH_BYTES) {
                writeResponse(client, NodeProtocol.STATUS_UNAUTHORIZED, ByteArray(0))
                return
            }
            val suppliedAuth = ByteArray(authLength).also(input::readFully)
            val expectedAuth = NodeCrypto.authTag(codeProvider(), nonce, command, requestPayload)
            if (!NodeCrypto.constantTimeEquals(suppliedAuth, expectedAuth)) {
                Thread.sleep(180L)
                writeResponse(client, NodeProtocol.STATUS_UNAUTHORIZED, ByteArray(0))
                return
            }
            NodeClientStore.markAuthenticatedRequest()

            val response = if (command == NodeProtocol.COMMAND_FRAME) {
                val jpeg = latestFrame.get()
                if (jpeg == null) RemoteCommandResponse(NodeProtocol.STATUS_NOT_READY)
                else RemoteCommandResponse(payload = jpeg)
            } else {
                runCatching { commandHandler.handle(command, requestPayload) }
                    .getOrElse { RemoteCommandResponse(NodeProtocol.STATUS_ERROR, (it.message ?: "Erreur").toByteArray()) }
            }

            val protectedPayload = if (response.status == NodeProtocol.STATUS_OK) {
                NodeCrypto.encryptPayload(response.payload, codeProvider(), nonce, command)
            } else {
                response.payload
            }
            writeResponse(client, response.status, protectedPayload)
        }
    }

    private fun writeResponse(socket: Socket, status: Int, payload: ByteArray) {
        val safePayload = if (payload.size <= NodeProtocol.MAX_PAYLOAD_BYTES) payload else ByteArray(0)
        val output = DataOutputStream(socket.getOutputStream())
        output.writeInt(NodeProtocol.MAGIC)
        output.writeByte(NodeProtocol.VERSION)
        output.writeByte(status)
        output.writeInt(safePayload.size)
        output.write(safePayload)
        output.flush()
    }

    companion object {
        const val PORT = 8787
        private const val MAX_CLIENTS = 4
    }
}
