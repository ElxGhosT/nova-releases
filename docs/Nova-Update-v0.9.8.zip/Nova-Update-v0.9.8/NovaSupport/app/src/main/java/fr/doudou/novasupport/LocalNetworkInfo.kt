package fr.doudou.novasupport

import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface

data class LocalNetworkInfo(
    val address: Inet4Address,
    val prefixLength: Int
) {
    val hostAddress: String get() = address.hostAddress.orEmpty()

    fun contains(client: InetAddress): Boolean {
        // Le socket reste lié à une interface IPv4 privée. On accepte les autres
        // adresses privées joignables de la maison (répéteur/VLAN) ; le secret HMAC
        // reste obligatoire pour toute commande.
        return client is Inet4Address && client.isSiteLocalAddress && !client.isLoopbackAddress
    }

    companion object {
        fun find(preferHotspot: Boolean = DirectHotspotController.isActive()): LocalNetworkInfo? = runCatching {
            val candidates = NetworkInterface.getNetworkInterfaces().toList()
                .filter { it.isUp && !it.isLoopback }
                .flatMap { network ->
                    network.interfaceAddresses.mapNotNull { entry ->
                        val ipv4 = entry.address as? Inet4Address ?: return@mapNotNull null
                        if (ipv4.isLoopbackAddress || !ipv4.isSiteLocalAddress) return@mapNotNull null
                        Triple(network.name.lowercase(), ipv4, entry.networkPrefixLength.toInt())
                    }
                }
            val sorted = candidates.sortedWith(compareBy<Triple<String, Inet4Address, Int>> {
                val name = it.first
                val lastByte = it.second.address.last().toInt() and 0xFF
                when {
                    preferHotspot && (name.contains("ap") || name.contains("swlan")) -> 0
                    preferHotspot && lastByte == 1 -> 1
                    name.startsWith("wlan") -> 2
                    name.startsWith("wifi") -> 3
                    else -> 4
                }
            }.thenBy { it.first })
            sorted.firstOrNull()?.let { LocalNetworkInfo(it.second, it.third) }
        }.getOrNull()
    }
}
