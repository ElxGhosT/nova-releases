package fr.doudou.novasupport

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.os.BatteryManager
import android.os.StatFs
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.util.LinkedHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

class CameraNodeService : LifecycleService() {

    private data class CompletedSegment(
        val id: Long,
        val file: File,
        val durationMs: Long,
        val displayName: String
    )


    private data class CompletedPhoto(
        val id: Long,
        val file: File,
        val displayName: String,
        val lens: String
    )

    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var cameraProvider: ProcessCameraProvider? = null
    private var frameServer: LocalFrameServer? = null
    private var foregroundStarted = false
    private var bindingInProgress = false
    @Volatile private var rebindRequested = false
    private var currentLens = NodePrefs.LENS_BACK
    private var lastFrameAt = 0L
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    private var imageCapture: ImageCapture? = null
    private var activeCamera: androidx.camera.core.Camera? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null
    private var currentVideoFile: File? = null
    @Volatile private var recordingRequested = false
    @Volatile private var recordingActive = false
    private var rollRequested = false
    private var pendingStartAfterBind = false
    private var remoteQuality = NodeProtocol.QUALITY_FHD
    private var remoteAudio = true
    private var remoteVideoTorch = false
    private var segmentLimitMs = 5 * 60_000L
    @Volatile private var currentSegmentIndex = 0
    @Volatile private var currentSegmentDurationMs = 0L
    @Volatile private var lastVideoError = ""
    private val segmentIdCounter = AtomicLong(1L)
    private val completedSegments = LinkedHashMap<Long, CompletedSegment>()
    private val segmentLock = Any()
    private val photoIdCounter = AtomicLong(1L)
    private val completedPhotos = LinkedHashMap<Long, CompletedPhoto>()
    private val photoLock = Any()

    @Volatile private var motionEnabled = false
    @Volatile private var motionSensitivity = 55
    @Volatile private var motionDurationMs = 30_000L
    @Volatile private var motionRecording = false
    @Volatile private var motionStopDeadline = 0L
    private var previousMotionSample: ByteArray? = null
    private var lastMotionEvaluationAt = 0L
    private var motionStopJob: kotlinx.coroutines.Job? = null
    private var serverWatchdogJob: kotlinx.coroutines.Job? = null

    override fun onCreate() {
        super.onCreate()
        motionEnabled = NodePrefs.motionEnabled(this)
        motionSensitivity = NodePrefs.motionSensitivity(this)
        motionDurationMs = NodePrefs.motionDurationMs(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_STOP -> stopNode()
            ACTION_RESTART_NETWORK -> {
                ensureForeground()
                restartServer()
            }
            ACTION_RECONFIGURE -> {
                currentLens = intent.getStringExtra(EXTRA_LENS) ?: NodePrefs.lens(this)
                NodePrefs.setLens(this, currentLens)
                ensureForeground()
                if (recordingActive) {
                    NodeStateStore.update(NodeState.Error("Arrête d’abord la vidéo distante avant de changer de caméra."))
                } else {
                    bindCamera()
                }
            }
            else -> {
                currentLens = intent?.getStringExtra(EXTRA_LENS) ?: NodePrefs.lens(this)
                NodePrefs.setLens(this, currentLens)
                ensureForeground()
                startServer()
                bindCamera()
            }
        }
        return START_NOT_STICKY
    }

    private fun ensureForeground() {
        if (foregroundStarted) return
        NodeStateStore.update(NodeState.Starting)
        acquireLocks()
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(),
            foregroundTypes(includeMicrophone = hasAudioPermission())
        )
        foregroundStarted = true
        SupportWidgetProvider.updateState(this, stopped = false)
        startServerWatchdog()
    }

    private fun foregroundTypes(includeMicrophone: Boolean): Int {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return 0
        var value = ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            value = value or ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            if (includeMicrophone) value = value or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        }
        return value
    }

    private fun startServer() {
        if (frameServer?.isRunning() == true) return
        frameServer?.stop()
        frameServer = null
        val network = LocalNetworkInfo.find()
        if (network == null) {
            NodeStateStore.update(NodeState.Error("Active le Wi-Fi privé ou crée un Réseau direct Nova."))
            return
        }
        frameServer = LocalFrameServer(
            network = network,
            codeProvider = { NodePrefs.pairingCode(this) },
            commandHandler = RemoteCommandHandler { command, payload -> handleRemoteCommand(command, payload) },
            onError = { message -> NodeStateStore.update(NodeState.Error(message)) }
        ).also { it.start() }
    }

    private fun startServerWatchdog() {
        if (serverWatchdogJob?.isActive == true) return
        serverWatchdogJob = serviceScope.launch {
            while (foregroundStarted) {
                delay(3_000L)
                if (!foregroundStarted) break
                val currentNetwork = LocalNetworkInfo.find()
                val server = frameServer
                val networkChanged = currentNetwork != null &&
                    server?.boundHostAddress() != currentNetwork.hostAddress
                if (server?.isRunning() != true || networkChanged) {
                    if (networkChanged) restartServer() else startServer()
                }
            }
        }
    }

    private fun restartServer() {
        frameServer?.stop()
        frameServer = null
        NodeClientStore.reset()
        startServer()
        if (frameServer?.isRunning() == true) {
            NodeStateStore.update(NodeState.Active(currentLens, frameServer?.hasFrame() == true))
        }
    }

    private fun bindCamera() {
        if (bindingInProgress) {
            rebindRequested = true
            return
        }
        rebindRequested = false
        bindingInProgress = true
        NodeStateStore.update(NodeState.Starting)
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            runCatching {
                val provider = future.get()
                cameraProvider = provider
                provider.unbindAll()
                NodePreviewBridge.clear()

                val preview = Preview.Builder()
                    .setResolutionSelector(
                        ResolutionSelector.Builder()
                            .setResolutionStrategy(
                                ResolutionStrategy(
                                    Size(1280, 720),
                                    ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                                )
                            )
                            .build()
                    )
                    .build()

                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setResolutionSelector(
                        ResolutionSelector.Builder()
                            .setResolutionStrategy(
                                ResolutionStrategy(
                                    Size(640, 480),
                                    ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                                )
                            )
                            .build()
                    )
                    .build()
                    .also { useCase -> useCase.setAnalyzer(cameraExecutor, ::analyzeFrame) }

                val needVideo = recordingRequested || pendingStartAfterBind || recordingActive
                val remoteVideoCapture = if (needVideo) {
                    imageCapture = null
                    val quality = if (remoteQuality == NodeProtocol.QUALITY_HD) Quality.HD else Quality.FHD
                    val selector = QualitySelector.from(
                        quality,
                        FallbackStrategy.lowerQualityOrHigherThan(quality)
                    )
                    VideoCapture.withOutput(
                        Recorder.Builder().setQualitySelector(selector).build()
                    ).also { videoCapture = it }
                } else {
                    videoCapture = null
                    ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                        .setJpegQuality(96)
                        .build()
                        .also { imageCapture = it }
                    null
                }

                val cameraSelector = if (currentLens == NodePrefs.LENS_FRONT) {
                    CameraSelector.DEFAULT_FRONT_CAMERA
                } else {
                    CameraSelector.DEFAULT_BACK_CAMERA
                }
                activeCamera = if (remoteVideoCapture == null) {
                    val photo = imageCapture ?: error("Capture photo indisponible")
                    runCatching {
                        provider.bindToLifecycle(this, cameraSelector, preview, analysis, photo)
                    }.getOrElse {
                        provider.unbindAll()
                        imageCapture = null
                        provider.bindToLifecycle(this, cameraSelector, preview, analysis)
                    }
                } else {
                    runCatching {
                        provider.bindToLifecycle(this, cameraSelector, preview, analysis, remoteVideoCapture)
                    }.getOrElse {
                        provider.unbindAll()
                        // Certains appareils ne supportent pas Analyse + Vidéo simultanément.
                        // La vidéo reste prioritaire ; l'aperçu réseau conserve la dernière image.
                        provider.bindToLifecycle(this, cameraSelector, preview, remoteVideoCapture)
                    }
                }
                NodePreviewBridge.publish(preview)
                bindingInProgress = false
                if (rebindRequested) {
                    rebindRequested = false
                    serviceScope.launch {
                        delay(120L)
                        bindCamera()
                    }
                    return@runCatching
                }
                if (frameServer?.isRunning() == true) {
                    NodeStateStore.update(NodeState.Active(currentLens, frameServer?.hasFrame() == true))
                } else {
                    NodeStateStore.update(NodeState.Error("Liaison locale indisponible sur le port ${LocalFrameServer.PORT}"))
                }
                if (pendingStartAfterBind || recordingRequested) {
                    pendingStartAfterBind = false
                    serviceScope.launch {
                        delay(150L)
                        startVideoSegment()
                    }
                }
            }.onFailure { error ->
                bindingInProgress = false
                if (rebindRequested) {
                    rebindRequested = false
                    serviceScope.launch {
                        delay(250L)
                        bindCamera()
                    }
                }
                lastVideoError = error.message ?: "Caméra indisponible"
                NodeStateStore.update(NodeState.Error(lastVideoError))
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyzeFrame(image: ImageProxy) {
        try {
            val now = SystemClock.elapsedRealtime()
            if (motionEnabled && now - lastMotionEvaluationAt >= MOTION_ANALYSIS_INTERVAL_MS) {
                lastMotionEvaluationAt = now
                evaluateMotion(image, now)
            }
            if (now - lastFrameAt < FRAME_INTERVAL_MS) return
            lastFrameAt = now
            val jpeg = imageToJpeg(image) ?: return
            frameServer?.updateFrame(jpeg)
            NodeStateStore.update(NodeState.Active(currentLens, frameReady = true))
        } finally {
            image.close()
        }
    }

    private fun evaluateMotion(image: ImageProxy, now: Long) {
        val plane = image.planes.firstOrNull() ?: return
        val width = image.width
        val height = image.height
        if (width <= 0 || height <= 0) return
        val pixelStride = plane.pixelStride.coerceAtLeast(4)
        val rowStride = plane.rowStride
        val buffer = plane.buffer.duplicate()
        val sample = ByteArray(MOTION_SAMPLE_COLUMNS * MOTION_SAMPLE_ROWS)
        var index = 0
        for (row in 0 until MOTION_SAMPLE_ROWS) {
            val y = (row * height / MOTION_SAMPLE_ROWS).coerceIn(0, height - 1)
            for (column in 0 until MOTION_SAMPLE_COLUMNS) {
                val x = (column * width / MOTION_SAMPLE_COLUMNS).coerceIn(0, width - 1)
                val offset = y * rowStride + x * pixelStride
                if (offset + 2 >= buffer.limit()) {
                    sample[index++] = 0
                    continue
                }
                val red = buffer.get(offset).toInt() and 0xFF
                val green = buffer.get(offset + 1).toInt() and 0xFF
                val blue = buffer.get(offset + 2).toInt() and 0xFF
                sample[index++] = ((red * 3 + green * 6 + blue) / 10).toByte()
            }
        }

        val previous = previousMotionSample
        previousMotionSample = sample
        if (previous == null || previous.size != sample.size) return

        var changed = 0
        for (i in sample.indices) {
            val delta = kotlin.math.abs((sample[i].toInt() and 0xFF) - (previous[i].toInt() and 0xFF))
            if (delta >= MOTION_LUMA_DELTA) changed += 1
        }
        val changedRatio = changed.toFloat() / sample.size.toFloat()
        val threshold = (0.30f - motionSensitivity * 0.0024f).coerceIn(0.06f, 0.28f)
        if (changedRatio >= threshold) onMotionDetected(now)
    }

    private fun onMotionDetected(now: Long) {
        motionStopDeadline = now + motionDurationMs
        if (!motionRecording && !recordingRequested && !recordingActive) {
            motionRecording = true
            remoteQuality = NodeProtocol.QUALITY_HD
            remoteAudio = hasAudioPermission()
            segmentLimitMs = motionDurationMs.coerceAtLeast(10_000L)
            recordingRequested = true
            lastVideoError = "Mouvement détecté : enregistrement automatique."
            serviceScope.launch {
                pendingStartAfterBind = true
                bindCamera()
                if (!bindingInProgress && videoCapture != null) startVideoSegment()
            }
        }
        scheduleMotionStop()
    }

    private fun scheduleMotionStop() {
        if (!motionRecording) return
        motionStopJob?.cancel()
        motionStopJob = serviceScope.launch {
            while (motionRecording) {
                val remaining = motionStopDeadline - SystemClock.elapsedRealtime()
                if (remaining <= 0L) break
                delay(remaining.coerceAtMost(1_000L))
            }
            if (motionRecording && SystemClock.elapsedRealtime() >= motionStopDeadline) {
                motionRecording = false
                recordingRequested = false
                pendingStartAfterBind = false
                activeRecording?.stop()
                lastVideoError = "Détection de mouvement active — en attente."
            }
        }
    }

    private fun imageToJpeg(image: ImageProxy): ByteArray? {
        val plane = image.planes.firstOrNull() ?: return null
        val width = image.width
        val height = image.height
        val pixelStride = plane.pixelStride.coerceAtLeast(4)
        val rowStride = plane.rowStride
        val paddedWidth = width + ((rowStride - pixelStride * width).coerceAtLeast(0) / pixelStride)
        val padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
        plane.buffer.rewind()
        padded.copyPixelsFromBuffer(plane.buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, width, height)
        if (cropped !== padded) padded.recycle()

        val rotation = image.imageInfo.rotationDegrees
        val rotated = if (rotation == 0) cropped else Bitmap.createBitmap(
            cropped,
            0,
            0,
            cropped.width,
            cropped.height,
            Matrix().apply { postRotate(rotation.toFloat()) },
            true
        ).also { if (it !== cropped) cropped.recycle() }

        return ByteArrayOutputStream().use { output ->
            val success = rotated.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, output)
            rotated.recycle()
            if (success) output.toByteArray() else null
        }
    }

    private fun handleRemoteCommand(command: Int, payload: ByteArray): RemoteCommandResponse = when (command) {
        NodeProtocol.COMMAND_VIDEO_START -> handleStartVideo(payload)
        NodeProtocol.COMMAND_VIDEO_STOP -> handleStopVideo()
        NodeProtocol.COMMAND_VIDEO_STATUS -> RemoteCommandResponse(payload = buildVideoStatus())
        NodeProtocol.COMMAND_SEGMENT_INFO -> RemoteCommandResponse(payload = buildSegmentInfo())
        NodeProtocol.COMMAND_SEGMENT_CHUNK -> handleSegmentChunk(payload)
        NodeProtocol.COMMAND_SEGMENT_DELETE -> handleSegmentDelete(payload)
        NodeProtocol.COMMAND_PHOTO_CAPTURE -> handleCapturePhoto(payload)
        NodeProtocol.COMMAND_PHOTO_CHUNK -> handlePhotoChunk(payload)
        NodeProtocol.COMMAND_PHOTO_DELETE -> handlePhotoDelete(payload)
        NodeProtocol.COMMAND_CAPABILITIES -> RemoteCommandResponse(payload = buildCapabilities())
        NodeProtocol.COMMAND_CAMERA_SET -> handleSetCamera(payload)
        NodeProtocol.COMMAND_SERVICE_STOP -> handleRemoteServiceStop()
        NodeProtocol.COMMAND_NETWORK_RESTART -> handleRemoteNetworkRestart()
        NodeProtocol.COMMAND_MOTION_CONFIG -> handleMotionConfig(payload)
        NodeProtocol.COMMAND_MOTION_STATUS -> RemoteCommandResponse(payload = buildMotionStatus())
        else -> RemoteCommandResponse(NodeProtocol.STATUS_BAD_REQUEST)
    }

    private fun handleCapturePhoto(payload: ByteArray): RemoteCommandResponse {
        if (recordingActive || recordingRequested || bindingInProgress) {
            return RemoteCommandResponse(NodeProtocol.STATUS_BUSY, "Caméra occupée par la vidéo.".toByteArray())
        }
        val capture = imageCapture ?: return RemoteCommandResponse(
            NodeProtocol.STATUS_NOT_READY,
            "Capture haute qualité en cours de préparation.".toByteArray()
        )
        val requestedFlash = payload.firstOrNull()?.toInt() ?: NodeProtocol.FLASH_OFF
        capture.flashMode = if (activeCamera?.cameraInfo?.hasFlashUnit() != true) {
            ImageCapture.FLASH_MODE_OFF
        } else {
            when (requestedFlash) {
                NodeProtocol.FLASH_AUTO -> ImageCapture.FLASH_MODE_AUTO
                NodeProtocol.FLASH_ON -> ImageCapture.FLASH_MODE_ON
                else -> ImageCapture.FLASH_MODE_OFF
            }
        }
        val directory = File(cacheDir, "nova_remote_photo").apply { mkdirs() }
        val file = File(directory, "NOVA_SUPPORT_${System.currentTimeMillis()}_${currentLens}.jpg")
        val latch = CountDownLatch(1)
        var completed: CompletedPhoto? = null
        var failure: String? = null

        ContextCompat.getMainExecutor(this).execute {
            runCatching {
                capture.takePicture(
                    ImageCapture.OutputFileOptions.Builder(file).build(),
                    cameraExecutor,
                    object : ImageCapture.OnImageSavedCallback {
                        override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                            val id = photoIdCounter.getAndIncrement()
                            completed = CompletedPhoto(id, file, file.name, currentLens)
                            latch.countDown()
                        }

                        override fun onError(exception: ImageCaptureException) {
                            failure = exception.message ?: "Capture photo impossible"
                            file.delete()
                            latch.countDown()
                        }
                    }
                )
            }.onFailure {
                failure = it.message ?: "Capture photo impossible"
                file.delete()
                latch.countDown()
            }
        }

        if (!latch.await(PHOTO_CAPTURE_TIMEOUT_SECONDS, TimeUnit.SECONDS)) {
            file.delete()
            return RemoteCommandResponse(NodeProtocol.STATUS_ERROR, "Délai de capture dépassé.".toByteArray())
        }
        val photo = completed ?: return RemoteCommandResponse(
            NodeProtocol.STATUS_ERROR,
            (failure ?: "Photo indisponible").toByteArray()
        )
        synchronized(photoLock) { completedPhotos[photo.id] = photo }
        return RemoteCommandResponse(payload = ByteArrayOutputStream().use { bytes ->
            DataOutputStream(bytes).use { output ->
                output.writeLong(photo.id)
                output.writeLong(photo.file.length())
                output.writeUTF(photo.displayName)
                output.writeUTF(photo.lens)
            }
            bytes.toByteArray()
        })
    }

    private fun handlePhotoChunk(payload: ByteArray): RemoteCommandResponse {
        val input = DataInputStream(ByteArrayInputStream(payload))
        val id = input.readLong()
        val offset = input.readLong()
        val requested = input.readInt().coerceIn(1, NodeProtocol.PHOTO_CHUNK_BYTES)
        val photo = synchronized(photoLock) { completedPhotos[id] }
            ?: return RemoteCommandResponse(NodeProtocol.STATUS_NOT_READY)
        if (offset !in 0..photo.file.length()) return RemoteCommandResponse(NodeProtocol.STATUS_BAD_REQUEST)
        val remaining = photo.file.length() - offset
        val length = minOf(requested.toLong(), remaining).toInt()
        val chunk = ByteArray(length)
        RandomAccessFile(photo.file, "r").use { source ->
            source.seek(offset)
            source.readFully(chunk)
        }
        return RemoteCommandResponse(payload = ByteArrayOutputStream().use { bytes ->
            DataOutputStream(bytes).use { output ->
                output.writeLong(id)
                output.writeLong(offset)
                output.writeInt(chunk.size)
                output.write(chunk)
            }
            bytes.toByteArray()
        })
    }

    private fun handlePhotoDelete(payload: ByteArray): RemoteCommandResponse {
        val id = DataInputStream(ByteArrayInputStream(payload)).readLong()
        val removed = synchronized(photoLock) { completedPhotos.remove(id) }
        removed?.file?.delete()
        return RemoteCommandResponse(payload = byteArrayOf(if (removed != null) 1 else 0))
    }

    private fun buildCapabilities(): ByteArray = ByteArrayOutputStream().use { bytes ->
        DataOutputStream(bytes).use { output ->
            output.writeUTF(currentLens)
            output.writeBoolean(packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA))
            output.writeBoolean(packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT))
            output.writeBoolean(activeCamera?.cameraInfo?.hasFlashUnit() == true)
            output.writeBoolean(recordingRequested || recordingActive)
            output.writeBoolean(frameServer?.isRunning() == true)
            output.writeBoolean(motionEnabled)
            output.writeInt(motionSensitivity)
            output.writeLong(motionDurationMs)
            val battery = getSystemService(BatteryManager::class.java)
                ?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
            output.writeInt(battery)
            val stats = StatFs(filesDir.absolutePath)
            output.writeLong(stats.availableBytes)
        }
        bytes.toByteArray()
    }

    private fun handleSetCamera(payload: ByteArray): RemoteCommandResponse {
        if (recordingActive || recordingRequested) {
            return RemoteCommandResponse(NodeProtocol.STATUS_BUSY, "Arrête d’abord la vidéo.".toByteArray())
        }
        val lens = when (payload.firstOrNull()?.toInt()) {
            NodeProtocol.LENS_FRONT -> NodePrefs.LENS_FRONT
            NodeProtocol.LENS_BACK -> NodePrefs.LENS_BACK
            else -> return RemoteCommandResponse(NodeProtocol.STATUS_BAD_REQUEST)
        }
        if (lens == NodePrefs.LENS_FRONT &&
            !packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT)
        ) {
            return RemoteCommandResponse(NodeProtocol.STATUS_NOT_READY, "Caméra avant absente.".toByteArray())
        }
        currentLens = lens
        NodePrefs.setLens(this, lens)
        previousMotionSample = null
        rebindRequested = true
        ContextCompat.getMainExecutor(this).execute { bindCamera() }
        return RemoteCommandResponse(payload = lens.toByteArray())
    }

    private fun handleRemoteServiceStop(): RemoteCommandResponse {
        serviceScope.launch {
            delay(250L)
            DirectHotspotController.stop()
            stopNode()
        }
        return RemoteCommandResponse(payload = "Arrêt demandé".toByteArray())
    }

    private fun handleRemoteNetworkRestart(): RemoteCommandResponse {
        serviceScope.launch {
            delay(150L)
            restartServer()
        }
        return RemoteCommandResponse(payload = "Redémarrage réseau demandé".toByteArray())
    }

    private fun handleMotionConfig(payload: ByteArray): RemoteCommandResponse {
        val input = DataInputStream(ByteArrayInputStream(payload))
        val enabled = input.readBoolean()
        val sensitivity = input.readInt().coerceIn(10, 95)
        val duration = input.readLong().coerceIn(10_000L, 300_000L)
        motionEnabled = enabled
        motionSensitivity = sensitivity
        motionDurationMs = duration
        previousMotionSample = null
        NodePrefs.setMotionEnabled(this, enabled)
        NodePrefs.setMotionSensitivity(this, sensitivity)
        NodePrefs.setMotionDurationMs(this, duration)
        if (!enabled && motionRecording) {
            motionRecording = false
            motionStopJob?.cancel()
            recordingRequested = false
            activeRecording?.stop()
        }
        return RemoteCommandResponse(payload = buildMotionStatus())
    }

    private fun buildMotionStatus(): ByteArray = ByteArrayOutputStream().use { bytes ->
        DataOutputStream(bytes).use { output ->
            output.writeBoolean(motionEnabled)
            output.writeInt(motionSensitivity)
            output.writeLong(motionDurationMs)
            output.writeBoolean(motionRecording)
            output.writeLong(motionStopDeadline)
        }
        bytes.toByteArray()
    }

    private fun handleStartVideo(payload: ByteArray): RemoteCommandResponse {
        val input = DataInputStream(ByteArrayInputStream(payload))
        val quality = input.readUnsignedByte()
        val audio = input.readBoolean()
        val requestedSegmentMs = input.readLong().coerceIn(10_000L, 30 * 60_000L)
        val torch = if (input.available() > 0) input.readBoolean() else false
        if (quality !in setOf(NodeProtocol.QUALITY_HD, NodeProtocol.QUALITY_FHD)) {
            return RemoteCommandResponse(NodeProtocol.STATUS_BAD_REQUEST)
        }
        motionRecording = false
        motionStopJob?.cancel()
        remoteQuality = quality
        remoteAudio = audio && hasAudioPermission()
        remoteVideoTorch = torch
        segmentLimitMs = requestedSegmentMs
        recordingRequested = true
        lastVideoError = if (audio && !remoteAudio) "Microphone non autorisé : vidéo sans son." else ""
        ContextCompat.getMainExecutor(this).execute {
            if (!recordingActive) {
                pendingStartAfterBind = true
                bindCamera()
                if (!bindingInProgress && videoCapture != null) startVideoSegment()
            }
        }
        return RemoteCommandResponse(payload = buildVideoStatus())
    }

    private fun handleStopVideo(): RemoteCommandResponse {
        motionRecording = false
        motionStopJob?.cancel()
        recordingRequested = false
        pendingStartAfterBind = false
        remoteVideoTorch = false
        ContextCompat.getMainExecutor(this).execute {
            runCatching { activeCamera?.cameraControl?.enableTorch(false) }
            activeRecording?.stop()
        }
        return RemoteCommandResponse(payload = buildVideoStatus())
    }

    private fun startVideoSegment() {
        if (!recordingRequested || recordingActive || bindingInProgress) return
        val capture = videoCapture ?: run {
            pendingStartAfterBind = true
            bindCamera()
            return
        }
        val dir = File(cacheDir, "nova_remote_video").apply { mkdirs() }
        val file = File(dir, "NOVA_SUPPORT_${System.currentTimeMillis()}_${currentSegmentIndex + 1}.mp4")
        currentVideoFile = file
        currentSegmentDurationMs = 0L
        rollRequested = false
        currentSegmentIndex += 1

        var pending = capture.output.prepareRecording(this, FileOutputOptions.Builder(file).build())
        if (remoteAudio && hasAudioPermission()) pending = pending.withAudioEnabled()
        if (remoteAudio) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                buildNotification(),
                foregroundTypes(includeMicrophone = hasAudioPermission())
            )
        }
        recordingActive = true
        if (remoteVideoTorch && activeCamera?.cameraInfo?.hasFlashUnit() == true) {
            runCatching { activeCamera?.cameraControl?.enableTorch(true) }
        }
        updateNotification()
        activeRecording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Status -> {
                    currentSegmentDurationMs = event.recordingStats.recordedDurationNanos / 1_000_000L
                    if (currentSegmentDurationMs >= segmentLimitMs && !rollRequested) {
                        rollRequested = true
                        activeRecording?.stop()
                    }
                }
                is VideoRecordEvent.Finalize -> finalizeVideoSegment(file, event)
            }
        }
    }

    private fun finalizeVideoSegment(file: File, event: VideoRecordEvent.Finalize) {
        val duration = readVideoDuration(file).takeIf { it > 0L } ?: currentSegmentDurationMs
        val usable = file.exists() && file.length() > MIN_VIDEO_BYTES && duration >= MIN_VIDEO_DURATION_MS
        if (usable) {
            val id = segmentIdCounter.getAndIncrement()
            synchronized(segmentLock) {
                completedSegments[id] = CompletedSegment(id, file, duration, file.name)
            }
        } else {
            file.delete()
            if (event.hasError()) lastVideoError = "Segment vidéo non exploitable (${event.error})."
        }
        activeRecording = null
        currentVideoFile = null
        recordingActive = false
        currentSegmentDurationMs = 0L
        if (!recordingRequested) {
            remoteVideoTorch = false
            runCatching { activeCamera?.cameraControl?.enableTorch(false) }
        }
        updateNotification()
        if (recordingRequested) {
            serviceScope.launch {
                delay(180L)
                startVideoSegment()
            }
        } else {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                buildNotification(),
                foregroundTypes(includeMicrophone = hasAudioPermission())
            )
            serviceScope.launch {
                delay(200L)
                if (!recordingRequested && !recordingActive) bindCamera()
            }
        }
    }

    private fun buildVideoStatus(): ByteArray = ByteArrayOutputStream().use { bytes ->
        DataOutputStream(bytes).use { output ->
            output.writeBoolean(recordingRequested || recordingActive)
            output.writeBoolean(recordingActive)
            output.writeInt(currentSegmentIndex)
            output.writeLong(currentSegmentDurationMs)
            output.writeInt(synchronized(segmentLock) { completedSegments.size })
            val statusMessage = when {
                motionRecording -> "Mouvement détecté : enregistrement automatique."
                motionEnabled && lastVideoError.isBlank() -> "Détection de mouvement active."
                else -> lastVideoError
            }
            output.writeUTF(statusMessage.take(500))
        }
        bytes.toByteArray()
    }

    private fun buildSegmentInfo(): ByteArray = ByteArrayOutputStream().use { bytes ->
        DataOutputStream(bytes).use { output ->
            val segment = synchronized(segmentLock) { completedSegments.values.firstOrNull() }
            output.writeBoolean(segment != null)
            if (segment != null) {
                output.writeLong(segment.id)
                output.writeLong(segment.file.length())
                output.writeLong(segment.durationMs)
                output.writeUTF(segment.displayName)
            }
        }
        bytes.toByteArray()
    }

    private fun handleSegmentChunk(payload: ByteArray): RemoteCommandResponse {
        val input = DataInputStream(ByteArrayInputStream(payload))
        val id = input.readLong()
        val offset = input.readLong()
        val requested = input.readInt().coerceIn(1, NodeProtocol.VIDEO_CHUNK_BYTES)
        val segment = synchronized(segmentLock) { completedSegments[id] }
            ?: return RemoteCommandResponse(NodeProtocol.STATUS_NOT_READY)
        if (offset !in 0..segment.file.length()) return RemoteCommandResponse(NodeProtocol.STATUS_BAD_REQUEST)
        val remaining = segment.file.length() - offset
        val length = minOf(requested.toLong(), remaining).toInt()
        val chunk = ByteArray(length)
        RandomAccessFile(segment.file, "r").use { source ->
            source.seek(offset)
            source.readFully(chunk)
        }
        return RemoteCommandResponse(payload = ByteArrayOutputStream().use { bytes ->
            DataOutputStream(bytes).use { output ->
                output.writeLong(id)
                output.writeLong(offset)
                output.writeInt(chunk.size)
                output.write(chunk)
            }
            bytes.toByteArray()
        })
    }

    private fun handleSegmentDelete(payload: ByteArray): RemoteCommandResponse {
        val id = DataInputStream(ByteArrayInputStream(payload)).readLong()
        val removed = synchronized(segmentLock) { completedSegments.remove(id) }
        removed?.file?.delete()
        return RemoteCommandResponse(payload = byteArrayOf(if (removed != null) 1 else 0))
    }

    private fun hasAudioPermission(): Boolean = ContextCompat.checkSelfPermission(
        this,
        Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    private fun readVideoDuration(file: File): Long = runCatching {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(file.absolutePath)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally {
            retriever.release()
        }
    }.getOrDefault(0L)

    private fun stopNode() {
        recordingRequested = false
        remoteVideoTorch = false
        runCatching { activeCamera?.cameraControl?.enableTorch(false) }
        activeRecording?.stop()
        activeRecording = null
        recordingActive = false
        cameraProvider?.unbindAll()
        cameraProvider = null
        imageCapture = null
        activeCamera = null
        NodePreviewBridge.clear()
        frameServer?.stop()
        frameServer = null
        bindingInProgress = false
        synchronized(segmentLock) {
            completedSegments.values.forEach { it.file.delete() }
            completedSegments.clear()
        }
        synchronized(photoLock) {
            completedPhotos.values.forEach { it.file.delete() }
            completedPhotos.clear()
        }
        motionStopJob?.cancel()
        motionStopJob = null
        serverWatchdogJob?.cancel()
        serverWatchdogJob = null
        currentVideoFile?.delete()
        currentVideoFile = null
        NodeStateStore.update(NodeState.Stopped)
        releaseLocks()
        if (foregroundStarted) stopForeground(STOP_FOREGROUND_REMOVE)
        foregroundStarted = false
        SupportWidgetProvider.updateState(this, stopped = true)
        stopSelf()
    }

    private fun buildNotification(): android.app.Notification = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(R.drawable.ic_nova_status)
        .setContentTitle(getString(R.string.notification_title))
        .setContentText(
            when {
                motionRecording -> "Service mouvement actif · ${formatDuration(currentSegmentDurationMs)}"
                recordingRequested || recordingActive -> "Service vidéo actif · segment $currentSegmentIndex · ${formatDuration(currentSegmentDurationMs)}"
                motionEnabled -> "Services Wi-Fi activés · détection active"
                else -> getString(R.string.notification_text)
            }
        )
        .setContentIntent(openAppPendingIntent())
        .addAction(R.drawable.ic_nova_status, getString(R.string.notification_stop), stopPendingIntent())
        .setCategory(NotificationCompat.CATEGORY_SERVICE)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setSilent(true)
        .setPriority(NotificationCompat.PRIORITY_LOW)
        .build()

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification())
    }

    private fun formatDuration(durationMs: Long): String {
        val total = durationMs / 1000L
        return "%02d:%02d".format(total / 60L, total % 60L)
    }

    private fun openAppPendingIntent(): PendingIntent = PendingIntent.getActivity(
        this,
        100,
        Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun stopPendingIntent(): PendingIntent = PendingIntent.getService(
        this,
        101,
        Intent(this, CameraNodeService::class.java).apply { action = ACTION_STOP },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            setSound(null, null)
            enableVibration(false)
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    @SuppressLint("WakelockTimeout", "WifiManagerPotentialLeak")
    private fun acquireLocks() {
        if (wakeLock?.isHeld != true) {
            wakeLock = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "NovaSupport:Node")
                .apply {
                    setReferenceCounted(false)
                    acquire()
                }
        }
        if (wifiLock?.isHeld != true) {
            val manager = applicationContext.getSystemService(WifiManager::class.java)
            wifiLock = manager.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "NovaSupport:Wifi")
                .apply {
                    setReferenceCounted(false)
                    acquire()
                }
        }
    }

    private fun releaseLocks() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        wifiLock?.let { if (it.isHeld) it.release() }
        wifiLock = null
    }

    override fun onDestroy() {
        recordingRequested = false
        activeRecording?.stop()
        activeRecording = null
        cameraProvider?.unbindAll()
        imageCapture = null
        activeCamera = null
        NodePreviewBridge.clear()
        frameServer?.stop()
        frameServer = null
        motionStopJob?.cancel()
        serverWatchdogJob?.cancel()
        cameraExecutor.shutdownNow()
        serviceScope.cancel()
        releaseLocks()
        NodeStateStore.update(NodeState.Stopped)
        SupportWidgetProvider.updateState(this, stopped = true)
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "fr.doudou.novasupport.action.START"
        const val ACTION_RECONFIGURE = "fr.doudou.novasupport.action.RECONFIGURE"
        const val ACTION_RESTART_NETWORK = "fr.doudou.novasupport.action.RESTART_NETWORK"
        const val ACTION_STOP = "fr.doudou.novasupport.action.STOP"
        const val EXTRA_LENS = "lens"

        private const val CHANNEL_ID = "nova_camera_node"
        private const val NOTIFICATION_ID = 1907
        private const val FRAME_INTERVAL_MS = 300L
        private const val JPEG_QUALITY = 72
        private const val MIN_VIDEO_BYTES = 32 * 1024L
        private const val MIN_VIDEO_DURATION_MS = 500L
        private const val PHOTO_CAPTURE_TIMEOUT_SECONDS = 15L
        private const val MOTION_ANALYSIS_INTERVAL_MS = 500L
        private const val MOTION_SAMPLE_COLUMNS = 24
        private const val MOTION_SAMPLE_ROWS = 18
        private const val MOTION_LUMA_DELTA = 28
    }
}
