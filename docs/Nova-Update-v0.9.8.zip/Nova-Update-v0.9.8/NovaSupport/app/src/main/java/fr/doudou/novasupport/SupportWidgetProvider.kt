package fr.doudou.novasupport

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import android.widget.Toast

class SupportWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { manager.updateAppWidget(it, buildViews(context, stopped = false)) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action != ACTION_STOP_ALL) return

        DirectHotspotController.stop()
        runCatching {
            context.startService(
                Intent(context, CameraNodeService::class.java).apply {
                    action = CameraNodeService.ACTION_STOP
                }
            )
        }.onFailure {
            context.stopService(Intent(context, CameraNodeService::class.java))
        }
        NodeClientStore.reset()
        NodeStateStore.update(NodeState.Stopped)
        updateState(context, stopped = true)
        Toast.makeText(context, "Nova Support : réseau et services arrêtés.", Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val ACTION_STOP_ALL = "fr.doudou.novasupport.action.WIDGET_STOP_ALL"

        fun updateState(context: Context, stopped: Boolean) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, SupportWidgetProvider::class.java)
            manager.getAppWidgetIds(component).forEach {
                manager.updateAppWidget(it, buildViews(context, stopped))
            }
        }

        private fun buildViews(context: Context, stopped: Boolean): RemoteViews {
            val intent = Intent(context, SupportWidgetProvider::class.java).apply {
                action = ACTION_STOP_ALL
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                501,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            return RemoteViews(context.packageName, R.layout.widget_nova_support).apply {
                setOnClickPendingIntent(R.id.supportWidgetRoot, pendingIntent)
                setTextViewText(
                    R.id.supportWidgetSubtitle,
                    if (stopped) "Services arrêtés" else "Appuyer pour tout arrêter"
                )
            }
        }
    }
}
