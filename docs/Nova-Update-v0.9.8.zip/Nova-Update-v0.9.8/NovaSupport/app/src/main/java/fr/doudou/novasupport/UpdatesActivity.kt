package fr.doudou.novasupport

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import fr.doudou.novasupport.databinding.ActivityUpdatesBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class UpdatesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUpdatesBinding
    private lateinit var manager: GitHubUpdateManager
    private var updateInfo: GitHubUpdateInfo? = null
    private var pendingInstall: File? = null

    private val unknownSourcesLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        val pending = pendingInstall
        if (pending != null && packageManager.canRequestPackageInstalls()) {
            startActivity(manager.installIntent(pending))
            pendingInstall = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        binding = ActivityUpdatesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        manager = GitHubUpdateManager(this)
        binding.currentVersionText.text = "Installée : ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})"
        binding.updateBaseUrlInput.setText(UpdatePrefs.baseUrl(this))
        binding.periodicCheckSwitch.isChecked = UpdatePrefs.autoCheck(this)

        binding.updatesBackButton.setOnClickListener { finish() }
        binding.periodicCheckSwitch.setOnCheckedChangeListener { _, checked ->
            UpdatePrefs.setAutoCheck(this, checked)
        }
        binding.saveUpdateUrlButton.setOnClickListener {
            val value = binding.updateBaseUrlInput.text.toString().trim().trimEnd('/')
            if (!value.startsWith("https://")) {
                showStatus("L’adresse doit commencer par https://")
            } else {
                UpdatePrefs.setBaseUrl(this, value)
                updateInfo = null
                binding.installUpdateButton.isEnabled = false
                showStatus("Adresse GitHub Pages enregistrée.")
            }
        }
        binding.checkUpdateButton.setOnClickListener { checkUpdate() }
        binding.installUpdateButton.setOnClickListener { updateInfo?.let(::downloadAndInstall) }
    }

    private fun checkUpdate() {
        val base = UpdatePrefs.baseUrl(this)
        if (!base.startsWith("https://")) {
            showStatus("Configure d’abord l’adresse HTTPS de GitHub Pages.")
            return
        }
        setBusy(true, "Recherche de mise à jour…")
        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    manager.fetchInfo("$base/nova-support.json")
                }
            }
            setBusy(false)
            result.onSuccess { info ->
                updateInfo = info
                val newer = info.versionCode > BuildConfig.VERSION_CODE.toLong()
                binding.currentVersionText.text = "Installée : ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})\nDisponible : ${info.versionName} (${info.versionCode})"
                binding.updateNotesText.text = if (info.notes.isEmpty()) {
                    if (newer) "Mise à jour disponible." else "Nova Support est à jour."
                } else {
                    info.notes.joinToString("\n") { "• $it" }
                }
                binding.installUpdateButton.isEnabled = newer
                binding.installUpdateButton.text = if (newer) "Télécharger ${info.versionName}" else "Nova Support est à jour"
                showStatus("Fichier de version vérifié.")
            }.onFailure { error -> showStatus("Recherche impossible : ${error.message}") }
        }
    }

    private fun downloadAndInstall(info: GitHubUpdateInfo) {
        setBusy(true, "Téléchargement de ${info.versionName}…")
        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val apk = manager.download(info) { downloaded, total ->
                        if (total > 0L) {
                            val percent = ((downloaded * 100L) / total).toInt().coerceIn(0, 100)
                            runOnUiThread {
                                binding.updateProgress.isIndeterminate = false
                                binding.updateProgress.progress = percent
                                showStatus("Téléchargement : $percent %")
                            }
                        }
                    }
                    manager.verify(info, apk)
                }
            }
            setBusy(false)
            result.onSuccess { apk ->
                showStatus("APK vérifié. Ouverture de l’installateur Android…")
                requestInstall(apk)
            }.onFailure { error -> showStatus("Installation bloquée : ${error.message}") }
        }
    }

    private fun requestInstall(apk: File) {
        if (packageManager.canRequestPackageInstalls()) {
            startActivity(manager.installIntent(apk))
        } else {
            pendingInstall = apk
            AlertDialog.Builder(this)
                .setTitle("Autoriser cette source")
                .setMessage("Active « Autoriser depuis cette source », puis reviens dans Nova Support.")
                .setNegativeButton("Annuler") { _, _ -> pendingInstall = null }
                .setPositiveButton("Ouvrir les réglages") { _, _ ->
                    unknownSourcesLauncher.launch(
                        Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                            data = Uri.parse("package:$packageName")
                        }
                    )
                }
                .show()
        }
    }

    private fun setBusy(busy: Boolean, message: String? = null) {
        binding.checkUpdateButton.isEnabled = !busy
        binding.saveUpdateUrlButton.isEnabled = !busy
        binding.installUpdateButton.isEnabled = !busy && updateInfo?.versionCode?.let {
            it > BuildConfig.VERSION_CODE.toLong()
        } == true
        binding.updateProgress.visibility = if (busy) View.VISIBLE else View.GONE
        binding.updateProgress.isIndeterminate = busy
        if (message != null) showStatus(message)
    }

    private fun showStatus(message: String) {
        binding.updateStatusText.text = message
    }
}
