package fr.doudou.novasupport

object NodeProtocol {
    const val MAGIC = 0x4E4F5641 // NOVA
    const val VERSION = 3

    const val COMMAND_FRAME = 1
    const val COMMAND_VIDEO_START = 2
    const val COMMAND_VIDEO_STOP = 3
    const val COMMAND_VIDEO_STATUS = 4
    const val COMMAND_SEGMENT_INFO = 5
    const val COMMAND_SEGMENT_CHUNK = 6
    const val COMMAND_SEGMENT_DELETE = 7
    const val COMMAND_PHOTO_CAPTURE = 8
    const val COMMAND_PHOTO_CHUNK = 9
    const val COMMAND_PHOTO_DELETE = 10
    const val COMMAND_CAPABILITIES = 11
    const val COMMAND_CAMERA_SET = 12
    const val COMMAND_SERVICE_STOP = 13
    const val COMMAND_NETWORK_RESTART = 14
    const val COMMAND_MOTION_CONFIG = 15
    const val COMMAND_MOTION_STATUS = 16

    const val STATUS_OK = 0
    const val STATUS_UNAUTHORIZED = 1
    const val STATUS_NOT_READY = 2
    const val STATUS_FORBIDDEN = 3
    const val STATUS_BAD_REQUEST = 4
    const val STATUS_BUSY = 5
    const val STATUS_ERROR = 6

    const val QUALITY_HD = 1
    const val QUALITY_FHD = 2

    const val NONCE_BYTES = 16
    const val AUTH_BYTES = 32
    const val MAX_REQUEST_BYTES = 64 * 1024
    const val MAX_PAYLOAD_BYTES = 4 * 1024 * 1024
    const val VIDEO_CHUNK_BYTES = 1024 * 1024
    const val PHOTO_CHUNK_BYTES = 1024 * 1024

    const val LENS_BACK = 1
    const val LENS_FRONT = 2

    const val FLASH_OFF = 0
    const val FLASH_AUTO = 1
    const val FLASH_ON = 2
}
