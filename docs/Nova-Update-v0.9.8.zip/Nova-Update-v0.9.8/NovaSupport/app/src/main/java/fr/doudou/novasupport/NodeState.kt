package fr.doudou.novasupport

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.camera.core.Preview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface NodeState {
    data object Stopped : NodeState
    data object Starting : NodeState
    data class Active(val lens: String, val frameReady: Boolean) : NodeState
    data class Error(val message: String) : NodeState
}

object NodeStateStore {
    private val mutableState = MutableStateFlow<NodeState>(NodeState.Stopped)
    val state = mutableState.asStateFlow()

    fun update(value: NodeState) {
        mutableState.value = value
    }
}

object NodeClientStore {
    private val handler = Handler(Looper.getMainLooper())
    private val mutableConnected = MutableStateFlow(false)
    val connected = mutableConnected.asStateFlow()
    @Volatile private var lastSeenAt = 0L

    private val timeoutRunnable = Runnable {
        if (SystemClock.elapsedRealtime() - lastSeenAt >= CLIENT_TIMEOUT_MS) {
            mutableConnected.value = false
        }
    }

    fun markAuthenticatedRequest() {
        lastSeenAt = SystemClock.elapsedRealtime()
        mutableConnected.value = true
        handler.removeCallbacks(timeoutRunnable)
        handler.postDelayed(timeoutRunnable, CLIENT_TIMEOUT_MS)
    }

    fun reset() {
        lastSeenAt = 0L
        handler.removeCallbacks(timeoutRunnable)
        mutableConnected.value = false
    }

    private const val CLIENT_TIMEOUT_MS = 1_800L
}

object NodePreviewBridge {
    private var preview: Preview? = null
    private var provider: Preview.SurfaceProvider? = null

    @Synchronized
    fun attach(surfaceProvider: Preview.SurfaceProvider?) {
        provider = surfaceProvider
        preview?.setSurfaceProvider(provider)
    }

    @Synchronized
    fun publish(value: Preview?) {
        preview = value
        preview?.setSurfaceProvider(provider)
    }

    @Synchronized
    fun clear() {
        preview?.setSurfaceProvider(null)
        preview = null
    }
}
