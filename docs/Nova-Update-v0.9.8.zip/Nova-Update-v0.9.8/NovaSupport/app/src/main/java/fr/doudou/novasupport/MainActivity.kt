package fr.doudou.novasupport

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import fr.doudou.novasupport.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var pendingStart = false
    private var activityStarted = false
    private var clientConnected = false
    private var passwordVisible = false

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val denied = result.filterValues { !it }.keys
        val blocking = denied.filterNot { it == Manifest.permission.RECORD_AUDIO }
        if (blocking.isEmpty() && pendingStart) {
            startNode()
            if (Manifest.permission.RECORD_AUDIO in denied) {
                binding.statusText.text = "Service actif. Les vidéos distantes seront enregistrées sans son."
            }
        } else if (blocking.isNotEmpty()) {
            binding.statusText.text = "Autorisation requise : ${blocking.joinToString()}"
        }
        pendingStart = false
    }

    private val hotspotPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            DirectHotspotController.start(this)
        } else {
            binding.directNetworkStatusText.text = "Autorisation Wi-Fi refusée : réseau direct indisponible."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        restoreLens()
        refreshConnectionInfo()
        setupActions()
        observeState()
        binding.frontButton.isEnabled = packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT)
        maybeCheckForUpdates()
    }

    override fun onStart() {
        super.onStart()
        activityStarted = true
        updatePreviewVisibility(clientConnected)
        refreshConnectionInfo()
    }

    override fun onStop() {
        activityStarted = false
        NodePreviewBridge.attach(null)
        super.onStop()
    }

    private fun maybeCheckForUpdates() {
        if (!UpdatePrefs.shouldAutoCheck(this)) return
        UpdatePrefs.markAutoCheck(this)
        val base = UpdatePrefs.baseUrl(this)
        lifecycleScope.launch {
            val info = runCatching {
                withContext(Dispatchers.IO) {
                    GitHubUpdateManager(this@MainActivity).fetchInfo("$base/nova-support.json")
                }
            }.getOrNull() ?: return@launch
            if (info.versionCode <= BuildConfig.VERSION_CODE.toLong()) return@launch
            if (UpdatePrefs.lastNotifiedVersion(this@MainActivity) >= info.versionCode) return@launch
            UpdatePrefs.markNotifiedVersion(this@MainActivity, info.versionCode)
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Mise à jour Nova Support")
                .setMessage("Version ${info.versionName} disponible.${if (info.notes.isEmpty()) "" else "\n\n" + info.notes.joinToString("\n") { "• $it" }}")
                .setNegativeButton("Plus tard", null)
                .setPositiveButton("Ouvrir") { _, _ ->
                    startActivity(Intent(this@MainActivity, UpdatesActivity::class.java))
                }
                .show()
        }
    }

    private fun restoreLens() {
        if (NodePrefs.lens(this) == NodePrefs.LENS_FRONT) {
            binding.lensToggle.check(R.id.frontButton)
        } else {
            binding.lensToggle.check(R.id.backButton)
        }
        updateLensLabel()
    }

    private fun setupActions() {
        binding.lensToggle.addOnButtonCheckedListener { _, checkedId, checked ->
            if (!checked) return@addOnButtonCheckedListener
            val lens = if (checkedId == R.id.frontButton) NodePrefs.LENS_FRONT else NodePrefs.LENS_BACK
            NodePrefs.setLens(this, lens)
            updateLensLabel()
            if (NodeStateStore.state.value !is NodeState.Stopped) {
                ContextCompat.startForegroundService(
                    this,
                    Intent(this, CameraNodeService::class.java).apply {
                        action = CameraNodeService.ACTION_RECONFIGURE
                        putExtra(CameraNodeService.EXTRA_LENS, lens)
                    }
                )
            }
        }
        binding.startButton.setOnClickListener { requestPermissionsAndStart() }
        binding.stopButton.setOnClickListener {
            startService(Intent(this, CameraNodeService::class.java).apply {
                action = CameraNodeService.ACTION_STOP
            })
        }
        binding.startDirectNetworkButton.setOnClickListener { requestDirectHotspot() }
        binding.showPasswordButton.setOnClickListener {
            passwordVisible = !passwordVisible
            renderDirectCredentials(DirectHotspotController.state.value as? DirectHotspotState.Active)
        }
        binding.copyPasswordButton.setOnClickListener { copyDirectPassword() }
        binding.stopDirectNetworkButton.setOnClickListener {
            DirectHotspotController.stop()
            lifecycleScope.launch {
                delay(700L)
                restartNetworkBinding()
                refreshConnectionInfo()
            }
        }
        binding.regenerateCodeButton.setOnClickListener {
            NodePrefs.regeneratePairingCode(this)
            refreshConnectionInfo()
            binding.statusText.text = "Nouveau QR code actif — rescane-le dans Nova"
        }
        binding.updatesButton.setOnClickListener {
            startActivity(Intent(this, UpdatesActivity::class.java))
        }
    }

    private fun requestPermissionsAndStart() {
        val permissions = buildList {
            add(Manifest.permission.CAMERA)
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            startNode()
        } else {
            pendingStart = true
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun requestDirectHotspot() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.NEARBY_WIFI_DEVICES
        } else {
            Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            DirectHotspotController.start(this)
        } else {
            hotspotPermissionLauncher.launch(permission)
        }
    }

    private fun startNode() {
        ContextCompat.startForegroundService(
            this,
            Intent(this, CameraNodeService::class.java).apply {
                action = CameraNodeService.ACTION_START
                putExtra(CameraNodeService.EXTRA_LENS, NodePrefs.lens(this@MainActivity))
            }
        )
    }

    private fun restartNetworkBinding() {
        if (NodeStateStore.state.value is NodeState.Stopped) return
        ContextCompat.startForegroundService(
            this,
            Intent(this, CameraNodeService::class.java).apply {
                action = CameraNodeService.ACTION_RESTART_NETWORK
            }
        )
    }

    private fun observeState() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    NodeStateStore.state.collect { state ->
                        binding.statusText.text = when (state) {
                            NodeState.Stopped -> "Service arrêté"
                            NodeState.Starting -> "Démarrage du service et de la liaison locale…"
                            is NodeState.Active -> if (state.frameReady) {
                                if (clientConnected) "Connectée à Nova" else "Active — prête pour Nova"
                            } else {
                                "Active — préparation de la liaison…"
                            }
                            is NodeState.Error -> "Erreur : ${state.message}"
                        }
                        binding.startButton.isEnabled = state is NodeState.Stopped || state is NodeState.Error
                        binding.stopButton.isEnabled = state !is NodeState.Stopped
                    }
                }
                launch {
                    DirectHotspotController.state.collect { state ->
                        when (state) {
                            DirectHotspotState.Stopped -> {
                                passwordVisible = false
                                binding.directNetworkStatusText.text = "Wi-Fi domestique ou Réseau direct Nova"
                                binding.startDirectNetworkButton.visibility = View.VISIBLE
                                binding.stopDirectNetworkButton.visibility = View.GONE
                                renderDirectCredentials(null)
                            }
                            DirectHotspotState.Starting -> {
                                binding.directNetworkStatusText.text = "Création du Réseau direct Nova…"
                                binding.startDirectNetworkButton.isEnabled = false
                                renderDirectCredentials(null)
                            }
                            is DirectHotspotState.Active -> {
                                binding.startDirectNetworkButton.isEnabled = true
                                binding.startDirectNetworkButton.visibility = View.GONE
                                binding.stopDirectNetworkButton.visibility = View.VISIBLE
                                binding.directNetworkStatusText.text = "Réseau direct actif : ${state.ssid}"
                                renderDirectCredentials(state)
                                delay(700L)
                                if (NodeStateStore.state.value is NodeState.Stopped) {
                                    requestPermissionsAndStart()
                                } else {
                                    restartNetworkBinding()
                                }
                                refreshConnectionInfo()
                            }
                            is DirectHotspotState.Error -> {
                                binding.startDirectNetworkButton.isEnabled = true
                                binding.startDirectNetworkButton.visibility = View.VISIBLE
                                binding.stopDirectNetworkButton.visibility = View.GONE
                                binding.directNetworkStatusText.text = "Erreur : ${state.message}"
                                renderDirectCredentials(null)
                            }
                        }
                    }
                }
                launch {
                    NodeClientStore.connected.collect { connected ->
                        clientConnected = connected
                        updatePreviewVisibility(connected)
                        val state = NodeStateStore.state.value
                        if (connected && state is NodeState.Active) {
                            binding.statusText.text = "Connectée à Nova · aperçu transféré"
                        }
                    }
                }
            }
        }
    }

    private fun updatePreviewVisibility(connected: Boolean) {
        binding.previewView.visibility = if (connected) View.INVISIBLE else View.VISIBLE
        binding.previewLabel.visibility = if (connected) View.GONE else View.VISIBLE
        binding.previewTransferredText.visibility = if (connected) View.VISIBLE else View.GONE
        if (activityStarted && !connected) {
            NodePreviewBridge.attach(binding.previewView.surfaceProvider)
        } else {
            NodePreviewBridge.attach(null)
        }
    }

    private fun refreshConnectionInfo() {
        val network = LocalNetworkInfo.find()
        val secret = NodePrefs.pairingCode(this)
        binding.pairingCodeText.text = NodePrefs.displayPairingCode(this)
        binding.addressText.text = if (network == null) {
            "Active le Wi-Fi ou crée un Réseau direct Nova"
        } else {
            "${network.hostAddress}:${LocalFrameServer.PORT}"
        }
        val pairPayload = network?.let { buildPairingPayload(it.hostAddress, secret) }
        if (pairPayload == null) {
            binding.pairingQrImage.setImageDrawable(null)
            binding.pairingQrImage.contentDescription = "QR code indisponible sans réseau local"
        } else {
            binding.pairingQrImage.setImageBitmap(createQrBitmap(pairPayload, 720))
            binding.pairingQrImage.contentDescription = "QR code d’appairage Nova Support"
        }
    }

    private fun buildPairingPayload(host: String, secret: String): String {
        return Uri.Builder()
            .scheme("nova-support")
            .authority("pair")
            .appendQueryParameter("v", "3")
            .appendQueryParameter("host", host)
            .appendQueryParameter("port", LocalFrameServer.PORT.toString())
            .appendQueryParameter("secret", secret)
            .appendQueryParameter(
                "network",
                if (DirectHotspotController.isActive()) "direct" else "wifi"
            )
            .build()
            .toString()
    }

    private fun renderDirectCredentials(state: DirectHotspotState.Active?) {
        if (state == null) {
            binding.directCredentialsContainer.visibility = View.GONE
            binding.wifiQrImage.setImageDrawable(null)
            return
        }
        binding.directCredentialsContainer.visibility = View.VISIBLE
        binding.directSsidText.text = state.ssid
        binding.directSecurityText.text = "Sécurité ${state.security}"
        binding.directPasswordText.text = when {
            state.password.isBlank() -> "Réseau ouvert"
            passwordVisible -> state.password
            else -> "•".repeat(state.password.length.coerceAtLeast(8))
        }
        binding.showPasswordButton.text = if (passwordVisible) "Masquer" else "Afficher"
        binding.copyPasswordButton.isEnabled = state.password.isNotBlank()
        val qrPayload = buildWifiQrPayload(state)
        binding.wifiQrImage.setImageBitmap(createQrBitmap(qrPayload, 640))
    }

    private fun copyDirectPassword() {
        val active = DirectHotspotController.state.value as? DirectHotspotState.Active
        val password = active?.password.orEmpty()
        if (password.isBlank()) {
            Toast.makeText(this, "Ce réseau ne demande pas de mot de passe.", Toast.LENGTH_SHORT).show()
            return
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Mot de passe Nova Support", password))
        Toast.makeText(this, "Mot de passe Wi-Fi copié.", Toast.LENGTH_SHORT).show()
    }

    private fun buildWifiQrPayload(state: DirectHotspotState.Active): String {
        val type = if (state.password.isBlank()) "nopass" else "WPA"
        return "WIFI:T:$type;S:${escapeWifiQr(state.ssid)};P:${escapeWifiQr(state.password)};;"
    }

    private fun escapeWifiQr(value: String): String = buildString {
        value.forEach { character ->
            if (character in charArrayOf('\\', ';', ',', ':', '"')) append('\\')
            append(character)
        }
    }

    private fun createQrBitmap(content: String, size: Int): Bitmap {
        val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size)
        val pixels = IntArray(size * size)
        for (y in 0 until size) {
            for (x in 0 until size) {
                pixels[y * size + x] = if (matrix[x, y]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
            }
        }
        return Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).apply {
            setPixels(pixels, 0, size, 0, 0, size, size)
        }
    }

    private fun updateLensLabel() {
        binding.previewLabel.text = if (NodePrefs.lens(this) == NodePrefs.LENS_FRONT) "AVANT" else "ARRIÈRE"
    }
}
