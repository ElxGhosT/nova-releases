package fr.doudou.novasupport

import android.annotation.SuppressLint
import android.content.Context
import android.net.wifi.SoftApConfiguration
import android.net.wifi.WifiConfiguration
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface DirectHotspotState {
    data object Stopped : DirectHotspotState
    data object Starting : DirectHotspotState
    data class Active(
        val ssid: String,
        val password: String,
        val security: String = "WPA2"
    ) : DirectHotspotState
    data class Error(val message: String) : DirectHotspotState
}

object DirectHotspotController {
    private val mutableState = MutableStateFlow<DirectHotspotState>(DirectHotspotState.Stopped)
    val state = mutableState.asStateFlow()

    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null

    fun isActive(): Boolean = mutableState.value is DirectHotspotState.Active

    @SuppressLint("MissingPermission")
    fun start(context: Context) {
        if (mutableState.value is DirectHotspotState.Active || mutableState.value is DirectHotspotState.Starting) return
        mutableState.value = DirectHotspotState.Starting
        val manager = context.applicationContext.getSystemService(WifiManager::class.java)
        runCatching {
            manager.startLocalOnlyHotspot(
                object : WifiManager.LocalOnlyHotspotCallback() {
                    override fun onStarted(value: WifiManager.LocalOnlyHotspotReservation) {
                        reservation?.close()
                        reservation = value
                        val credentials = readCredentials(value)
                        if (credentials == null) {
                            value.close()
                            reservation = null
                            mutableState.value = DirectHotspotState.Error("Android n’a pas fourni les identifiants du réseau direct.")
                        } else {
                            mutableState.value = credentials
                        }
                    }

                    override fun onStopped() {
                        reservation = null
                        mutableState.value = DirectHotspotState.Stopped
                    }

                    override fun onFailed(reason: Int) {
                        reservation = null
                        mutableState.value = DirectHotspotState.Error(failureMessage(reason))
                    }
                },
                Handler(Looper.getMainLooper())
            )
        }.onFailure {
            mutableState.value = DirectHotspotState.Error(it.message ?: "Impossible de créer le réseau direct.")
        }
    }

    fun stop() {
        reservation?.close()
        reservation = null
        mutableState.value = DirectHotspotState.Stopped
    }

    @Suppress("DEPRECATION")
    private fun readCredentials(value: WifiManager.LocalOnlyHotspotReservation): DirectHotspotState.Active? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val config = value.softApConfiguration
            val ssid = config.ssid.orEmpty()
            val password = config.passphrase.orEmpty()
            if (ssid.isBlank()) null else DirectHotspotState.Active(
                ssid = ssid,
                password = password,
                security = securityLabel(config.securityType, password)
            )
        } else {
            val config: WifiConfiguration = value.wifiConfiguration ?: return null
            val ssid = config.SSID.orEmpty().trim('"')
            val password = config.preSharedKey.orEmpty().trim('"')
            if (ssid.isBlank()) null else DirectHotspotState.Active(
                ssid = ssid,
                password = password,
                security = if (password.isBlank()) "OPEN" else "WPA2"
            )
        }
    }

    private fun securityLabel(type: Int, password: String): String {
        if (password.isBlank()) return "OPEN"
        return when (type) {
            SoftApConfiguration.SECURITY_TYPE_WPA3_SAE,
            SoftApConfiguration.SECURITY_TYPE_WPA3_SAE_TRANSITION -> "WPA3"
            SoftApConfiguration.SECURITY_TYPE_WPA2_PSK -> "WPA2"
            SoftApConfiguration.SECURITY_TYPE_OPEN -> "OPEN"
            else -> "WPA2"
        }
    }

    private fun failureMessage(reason: Int): String = when (reason) {
        WifiManager.LocalOnlyHotspotCallback.ERROR_NO_CHANNEL -> "Aucun canal Wi-Fi disponible pour le réseau direct."
        WifiManager.LocalOnlyHotspotCallback.ERROR_GENERIC -> "Android a refusé la création du réseau direct."
        WifiManager.LocalOnlyHotspotCallback.ERROR_INCOMPATIBLE_MODE -> "Désactive le partage de connexion ou un autre point d’accès déjà actif."
        4 -> "Le téléphone interdit actuellement la création d’un point d’accès local."
        else -> "Création du réseau direct impossible (code $reason)."
    }
}
