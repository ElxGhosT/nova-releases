package fr.doudou.novasupport

data class RemoteCommandResponse(
    val status: Int = NodeProtocol.STATUS_OK,
    val payload: ByteArray = ByteArray(0)
)

fun interface RemoteCommandHandler {
    fun handle(command: Int, payload: ByteArray): RemoteCommandResponse
}
