package fr.doudou.novasupport

import android.content.Context
import java.security.SecureRandom

object NodePrefs {
    const val LENS_BACK = "BACK"
    const val LENS_FRONT = "FRONT"

    private const val FILE = "nova_support_preferences"
    private const val CODE_KEY = "pairing_code"
    private val random = SecureRandom()
    private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

    private fun prefs(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun lens(context: Context): String =
        prefs(context).getString("lens", LENS_BACK) ?: LENS_BACK

    fun setLens(context: Context, value: String) {
        val normalized = if (value == LENS_FRONT) LENS_FRONT else LENS_BACK
        prefs(context).edit().putString("lens", normalized).apply()
    }

    fun pairingCode(context: Context): String {
        PairingSecretStore.read(context).takeIf { it.isNotBlank() }?.let { return it }
        return regeneratePairingCode(context)
    }

    fun regeneratePairingCode(context: Context): String {
        val value = buildString {
            repeat(20) { append(ALPHABET[random.nextInt(ALPHABET.length)]) }
        }
        PairingSecretStore.write(context, value)
        prefs(context).edit().remove(CODE_KEY).apply()
        return value
    }


    fun motionEnabled(context: Context): Boolean =
        prefs(context).getBoolean("motion_enabled", false)

    fun setMotionEnabled(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean("motion_enabled", value).apply()
    }

    fun motionSensitivity(context: Context): Int =
        prefs(context).getInt("motion_sensitivity", 55).coerceIn(10, 95)

    fun setMotionSensitivity(context: Context, value: Int) {
        prefs(context).edit().putInt("motion_sensitivity", value.coerceIn(10, 95)).apply()
    }

    fun motionDurationMs(context: Context): Long =
        prefs(context).getLong("motion_duration_ms", 30_000L).coerceIn(10_000L, 300_000L)

    fun setMotionDurationMs(context: Context, value: Long) {
        prefs(context).edit().putLong("motion_duration_ms", value.coerceIn(10_000L, 300_000L)).apply()
    }

    fun displayPairingCode(context: Context): String = pairingCode(context)
        .chunked(4)
        .joinToString("-")
}
