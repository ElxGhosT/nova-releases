package fr.doudou.novasupport

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object NodeCrypto {
    private const val PAYLOAD_VERSION: Byte = 3
    private const val IV_LENGTH = 12
    private val secureRandom = SecureRandom()

    fun normalizeCode(value: String): String = value
        .uppercase()
        .filter { it.isLetterOrDigit() }

    fun authTag(code: String, requestNonce: ByteArray, command: Int, payload: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(deriveKey(code, "auth-v2"), "HmacSHA256"))
        mac.update("NOVA_SUPPORT_REQUEST_V2".toByteArray(Charsets.US_ASCII))
        mac.update(requestNonce)
        mac.update(command.toByte())
        mac.update(payload)
        return mac.doFinal()
    }

    fun encryptPayload(payload: ByteArray, code: String, requestNonce: ByteArray, command: Int): ByteArray {
        val iv = ByteArray(IV_LENGTH).also(secureRandom::nextBytes)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(
            Cipher.ENCRYPT_MODE,
            SecretKeySpec(deriveKey(code, "payload-v2"), "AES"),
            GCMParameterSpec(128, iv)
        )
        cipher.updateAAD(requestNonce)
        cipher.updateAAD(command.toByte().let { byteArrayOf(it) })
        val encrypted = cipher.doFinal(payload)
        return ByteArray(1 + iv.size + encrypted.size).also { output ->
            output[0] = PAYLOAD_VERSION
            iv.copyInto(output, destinationOffset = 1)
            encrypted.copyInto(output, destinationOffset = 1 + iv.size)
        }
    }

    fun constantTimeEquals(left: ByteArray, right: ByteArray): Boolean =
        MessageDigest.isEqual(left, right)

    private fun deriveKey(code: String, purpose: String): ByteArray =
        MessageDigest.getInstance("SHA-256")
            .digest("nova-support-$purpose:${normalizeCode(code)}".toByteArray(Charsets.UTF_8))
}
