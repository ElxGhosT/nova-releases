plugins {
    id("com.android.application")
}

android {
    namespace = "fr.doudou.novasupport"
    compileSdk = 36

    defaultConfig {
        applicationId = "fr.doudou.novasupport"
        minSdk = 28
        targetSdk = 36
        versionCode = 7
        versionName = "0.5.2"
        val updateBaseUrl = System.getenv("NOVA_UPDATE_BASE_URL").orEmpty().trimEnd('/')
        buildConfigField("String", "NOVA_UPDATE_BASE_URL", "\"$updateBaseUrl\"")
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    val releaseKeystorePath = System.getenv("NOVA_KEYSTORE_PATH")
    val releaseStorePassword = System.getenv("NOVA_KEYSTORE_PASSWORD")
    val releaseKeyAlias = System.getenv("NOVA_KEY_ALIAS")
    val releaseKeyPassword = System.getenv("NOVA_KEY_PASSWORD")

    signingConfigs {
        if (!releaseKeystorePath.isNullOrBlank() &&
            !releaseStorePassword.isNullOrBlank() &&
            !releaseKeyAlias.isNullOrBlank() &&
            !releaseKeyPassword.isNullOrBlank()
        ) {
            create("novaRelease") {
                storeFile = file(releaseKeystorePath)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    val novaReleaseSigning = signingConfigs.findByName("novaRelease")

    buildTypes {
        release {
            isMinifyEnabled = false
            if (novaReleaseSigning != null) signingConfig = novaReleaseSigning
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

dependencies {
    val cameraXVersion = "1.6.1"

    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.2")
    implementation("androidx.lifecycle:lifecycle-service:2.9.2")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.zxing:core:3.5.3")

    implementation("androidx.camera:camera-core:$cameraXVersion")
    implementation("androidx.camera:camera-camera2:$cameraXVersion")
    implementation("androidx.camera:camera-lifecycle:$cameraXVersion")
    implementation("androidx.camera:camera-view:$cameraXVersion")
    implementation("androidx.camera:camera-video:$cameraXVersion")
}
