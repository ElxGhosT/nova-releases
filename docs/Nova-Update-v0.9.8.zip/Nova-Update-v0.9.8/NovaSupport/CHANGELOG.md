# Nova Support v0.5.2

- Nouveau protocole local v3 commun avec Nova v0.9.8.
- Vraie capture photo haute résolution et transfert par blocs chiffrés.
- Serveur local indépendant de la session CameraX et surveillé automatiquement.
- Changement caméra avant/arrière à distance sans perte durable de l’appairage.
- Relance réseau et arrêt complet des services à distance.
- Vidéo persistante pendant une déconnexion de Nova, avec file de segments récupérée à la reconnexion.
- Flash photo distant et torche vidéo selon les réglages de Nova.
- Détection de mouvement légère avec sensibilité et durée réglables, sans pré-enregistrement.
- Remontée des capacités, batterie et stockage libre vers Nova.

## Historique v0.5.1

- Affichage du nom du Réseau direct Nova et de son mot de passe Wi-Fi.
- Boutons **Afficher/Masquer** et **Copier** pour le mot de passe.
- QR Wi-Fi standard séparé du QR d’appairage Nova.
- Détection du type de sécurité WPA2/WPA3 fourni par Android.
- QR d’appairage v3 ne contenant plus le mot de passe Wi-Fi.
- Ajout d’un widget Nova Support grisé sur l’écran d’accueil.
- Un appui sur le widget arrête le Réseau direct Nova, le service caméra, le serveur local et la vidéo en cours.
- Le widget indique lorsque les services ont été arrêtés.

## Historique v0.5.0

- Création d’un Réseau direct Nova sans box ni accès cloud.
- QR unique pour connecter le téléphone principal et effectuer l’appairage.
- Notification rendue plus neutre.
- Aperçu local masqué pendant la visualisation depuis Nova.
- Compatibilité avec plusieurs sous-réseaux privés domestiques.

## Historique v0.4.0

- Enregistrement vidéo distant et transfert chiffré vers Nova.
- Interface sombre modernisée.
