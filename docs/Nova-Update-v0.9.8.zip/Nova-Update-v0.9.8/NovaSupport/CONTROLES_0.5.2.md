# Contrôles Nova Support v0.5.2

- Ressources XML valides.
- Serveur local maintenu indépendamment des rebinding CameraX.
- Watchdog serveur actif.
- Capture photo haute résolution, transfert par blocs et suppression après accusé de réception.
- Changement de caméra distant sans arrêt du service.
- Enregistrement vidéo autonome et file locale de segments.
- Détection de mouvement sans pré-enregistrement.
- Arrêt distant et arrêt par widget conservés.
