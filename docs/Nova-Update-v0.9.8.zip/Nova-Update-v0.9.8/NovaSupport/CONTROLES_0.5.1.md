# Contrôles Nova Support v0.5.1

## Vérifications réalisées

- Version passée à `0.5.1` (`versionCode 6`).
- Ajout des identifiants visibles du réseau direct et du QR Wi-Fi standard.
- Séparation des données Wi-Fi et du QR d’appairage.
- Ajout du widget `SupportWidgetProvider` et de sa déclaration Android.
- Le widget envoie l’action d’arrêt au service puis ferme la réservation LocalOnlyHotspot.
- Vérification syntaxique des XML et des références ViewBinding ajoutées.

## Essais recommandés

1. Créer un réseau direct et vérifier l’affichage du SSID, du mot de passe et du type de sécurité.
2. Scanner le QR Wi-Fi avec l’appareil photo Android et rejoindre le réseau.
3. Scanner ensuite le QR d’appairage dans Nova.
4. Ajouter le widget Nova Support depuis le sélecteur de widgets Android.
5. Démarrer Nova Support et le réseau direct, puis appuyer sur le widget.
6. Vérifier la disparition du réseau AndroidShare, de la notification et de l’indicateur caméra.
